var e = Object.create,
    t = Object.defineProperty,
    n = Object.getOwnPropertyDescriptor,
    r = Object.getOwnPropertyNames,
    i = Object.getPrototypeOf,
    a = Object.prototype.hasOwnProperty,
    o = (e, t) => () => (t || (e((t = {
        exports: {}
    }).exports, t), e = null), t.exports),
    s = (e, i, o, s) => {
        if (i && typeof i == `object` || typeof i == `function`)
            for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
                get: (e => i[e]).bind(null, d),
                enumerable: !(s = n(i, d)) || s.enumerable
            });
        return e
    },
    c = (n, r, a) => (a = n == null ? {} : e(i(n)), s(r || !n || !n.__esModule ? t(a, `default`, {
        value: n,
        enumerable: !0
    }) : a, n)),
    l = o((e => {
        var t = Symbol.for(`react.transitional.element`),
            n = Symbol.for(`react.portal`),
            r = Symbol.for(`react.fragment`),
            i = Symbol.for(`react.strict_mode`),
            a = Symbol.for(`react.profiler`),
            o = Symbol.for(`react.consumer`),
            s = Symbol.for(`react.context`),
            c = Symbol.for(`react.forward_ref`),
            l = Symbol.for(`react.suspense`),
            u = Symbol.for(`react.memo`),
            d = Symbol.for(`react.lazy`),
            f = Symbol.for(`react.activity`),
            p = Symbol.iterator;

        function m(e) {
            return typeof e != `object` || !e ? null : (e = p && e[p] || e[`@@iterator`], typeof e == `function` ? e : null)
        }
        var h = {
                isMounted: function() {
                    return !1
                },
                enqueueForceUpdate: function() {},
                enqueueReplaceState: function() {},
                enqueueSetState: function() {}
            },
            g = Object.assign,
            _ = {};

        function v(e, t, n) {
            this.props = e, this.context = t, this.refs = _, this.updater = n || h
        }
        v.prototype.isReactComponent = {}, v.prototype.setState = function(e, t) {
            if (typeof e != `object` && typeof e != `function` && e != null) throw Error(`takes an object of state variables to update or a function which returns an object of state variables.`);
            this.updater.enqueueSetState(this, e, t, `setState`)
        }, v.prototype.forceUpdate = function(e) {
            this.updater.enqueueForceUpdate(this, e, `forceUpdate`)
        };

        function y() {}
        y.prototype = v.prototype;

        function b(e, t, n) {
            this.props = e, this.context = t, this.refs = _, this.updater = n || h
        }
        var x = b.prototype = new y;
        x.constructor = b, g(x, v.prototype), x.isPureReactComponent = !0;
        var ee = Array.isArray;

        function S() {}
        var C = {
                H: null,
                A: null,
                T: null,
                S: null
            },
            te = Object.prototype.hasOwnProperty;

        function ne(e, n, r) {
            var i = r.ref;
            return {
                $$typeof: t,
                type: e,
                key: n,
                ref: i === void 0 ? null : i,
                props: r
            }
        }

        function re(e, t) {
            return ne(e.type, t, e.props)
        }

        function ie(e) {
            return typeof e == `object` && !!e && e.$$typeof === t
        }

        function ae(e) {
            var t = {
                "=": `=0`,
                ":": `=2`
            };
            return `$` + e.replace(/[=:]/g, function(e) {
                return t[e]
            })
        }
        var oe = /\/+/g;

        function se(e, t) {
            return typeof e == `object` && e && e.key != null ? ae(`` + e.key) : t.toString(36)
        }

        function ce(e) {
            switch (e.status) {
                case `fulfilled`:
                    return e.value;
                case `rejected`:
                    throw e.reason;
                default:
                    switch (typeof e.status == `string` ? e.then(S, S) : (e.status = `pending`, e.then(function(t) {
                        e.status === `pending` && (e.status = `fulfilled`, e.value = t)
                    }, function(t) {
                        e.status === `pending` && (e.status = `rejected`, e.reason = t)
                    })), e.status) {
                        case `fulfilled`:
                            return e.value;
                        case `rejected`:
                            throw e.reason
                    }
            }
            throw e
        }

        function le(e, r, i, a, o) {
            var s = typeof e;
            (s === `undefined` || s === `boolean`) && (e = null);
            var c = !1;
            if (e === null) c = !0;
            else switch (s) {
                case `bigint`:
                case `string`:
                case `number`:
                    c = !0;
                    break;
                case `object`:
                    switch (e.$$typeof) {
                        case t:
                        case n:
                            c = !0;
                            break;
                        case d:
                            return c = e._init, le(c(e._payload), r, i, a, o)
                    }
            }
            if (c) return o = o(e), c = a === `` ? `.` + se(e, 0) : a, ee(o) ? (i = ``, c != null && (i = c.replace(oe, `$&/`) + `/`), le(o, r, i, ``, function(e) {
                return e
            })) : o != null && (ie(o) && (o = re(o, i + (o.key == null || e && e.key === o.key ? `` : (`` + o.key).replace(oe, `$&/`) + `/`) + c)), r.push(o)), 1;
            c = 0;
            var l = a === `` ? `.` : a + `:`;
            if (ee(e))
                for (var u = 0; u < e.length; u++) a = e[u], s = l + se(a, u), c += le(a, r, i, s, o);
            else if (u = m(e), typeof u == `function`)
                for (e = u.call(e), u = 0; !(a = e.next()).done;) a = a.value, s = l + se(a, u++), c += le(a, r, i, s, o);
            else if (s === `object`) {
                if (typeof e.then == `function`) return le(ce(e), r, i, a, o);
                throw r = String(e), Error(`Objects are not valid as a React child (found: ` + (r === `[object Object]` ? `object with keys {` + Object.keys(e).join(`, `) + `}` : r) + `). If you meant to render a collection of children, use an array instead.`)
            }
            return c
        }

        function ue(e, t, n) {
            if (e == null) return e;
            var r = [],
                i = 0;
            return le(e, r, ``, ``, function(e) {
                return t.call(n, e, i++)
            }), r
        }

        function de(e) {
            if (e._status === -1) {
                var t = e._result;
                t = t(), t.then(function(t) {
                    (e._status === 0 || e._status === -1) && (e._status = 1, e._result = t)
                }, function(t) {
                    (e._status === 0 || e._status === -1) && (e._status = 2, e._result = t)
                }), e._status === -1 && (e._status = 0, e._result = t)
            }
            if (e._status === 1) return e._result.default;
            throw e._result
        }
        var w = typeof reportError == `function` ? reportError : function(e) {
                if (typeof window == `object` && typeof window.ErrorEvent == `function`) {
                    var t = new window.ErrorEvent(`error`, {
                        bubbles: !0,
                        cancelable: !0,
                        message: typeof e == `object` && e && typeof e.message == `string` ? String(e.message) : String(e),
                        error: e
                    });
                    if (!window.dispatchEvent(t)) return
                } else if (typeof process == `object` && typeof process.emit == `function`) {
                    process.emit(`uncaughtException`, e);
                    return
                }
                console.error(e)
            },
            E = {
                map: ue,
                forEach: function(e, t, n) {
                    ue(e, function() {
                        t.apply(this, arguments)
                    }, n)
                },
                count: function(e) {
                    var t = 0;
                    return ue(e, function() {
                        t++
                    }), t
                },
                toArray: function(e) {
                    return ue(e, function(e) {
                        return e
                    }) || []
                },
                only: function(e) {
                    if (!ie(e)) throw Error(`React.Children.only expected to receive a single React element child.`);
                    return e
                }
            };
        e.Activity = f, e.Children = E, e.Component = v, e.Fragment = r, e.Profiler = a, e.PureComponent = b, e.StrictMode = i, e.Suspense = l, e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = C, e.__COMPILER_RUNTIME = {
            __proto__: null,
            c: function(e) {
                return C.H.useMemoCache(e)
            }
        }, e.cache = function(e) {
            return function() {
                return e.apply(null, arguments)
            }
        }, e.cacheSignal = function() {
            return null
        }, e.cloneElement = function(e, t, n) {
            if (e == null) throw Error(`The argument must be a React element, but you passed ` + e + `.`);
            var r = g({}, e.props),
                i = e.key;
            if (t != null)
                for (a in t.key !== void 0 && (i = `` + t.key), t) !te.call(t, a) || a === `key` || a === `__self` || a === `__source` || a === `ref` && t.ref === void 0 || (r[a] = t[a]);
            var a = arguments.length - 2;
            if (a === 1) r.children = n;
            else if (1 < a) {
                for (var o = Array(a), s = 0; s < a; s++) o[s] = arguments[s + 2];
                r.children = o
            }
            return ne(e.type, i, r)
        }, e.createContext = function(e) {
            return e = {
                $$typeof: s,
                _currentValue: e,
                _currentValue2: e,
                _threadCount: 0,
                Provider: null,
                Consumer: null
            }, e.Provider = e, e.Consumer = {
                $$typeof: o,
                _context: e
            }, e
        }, e.createElement = function(e, t, n) {
            var r, i = {},
                a = null;
            if (t != null)
                for (r in t.key !== void 0 && (a = `` + t.key), t) te.call(t, r) && r !== `key` && r !== `__self` && r !== `__source` && (i[r] = t[r]);
            var o = arguments.length - 2;
            if (o === 1) i.children = n;
            else if (1 < o) {
                for (var s = Array(o), c = 0; c < o; c++) s[c] = arguments[c + 2];
                i.children = s
            }
            if (e && e.defaultProps)
                for (r in o = e.defaultProps, o) i[r] === void 0 && (i[r] = o[r]);
            return ne(e, a, i)
        }, e.createRef = function() {
            return {
                current: null
            }
        }, e.forwardRef = function(e) {
            return {
                $$typeof: c,
                render: e
            }
        }, e.isValidElement = ie, e.lazy = function(e) {
            return {
                $$typeof: d,
                _payload: {
                    _status: -1,
                    _result: e
                },
                _init: de
            }
        }, e.memo = function(e, t) {
            return {
                $$typeof: u,
                type: e,
                compare: t === void 0 ? null : t
            }
        }, e.startTransition = function(e) {
            var t = C.T,
                n = {};
            C.T = n;
            try {
                var r = e(),
                    i = C.S;
                i !== null && i(n, r), typeof r == `object` && r && typeof r.then == `function` && r.then(S, w)
            } catch (e) {
                w(e)
            } finally {
                t !== null && n.types !== null && (t.types = n.types), C.T = t
            }
        }, e.unstable_useCacheRefresh = function() {
            return C.H.useCacheRefresh()
        }, e.use = function(e) {
            return C.H.use(e)
        }, e.useActionState = function(e, t, n) {
            return C.H.useActionState(e, t, n)
        }, e.useCallback = function(e, t) {
            return C.H.useCallback(e, t)
        }, e.useContext = function(e) {
            return C.H.useContext(e)
        }, e.useDebugValue = function() {}, e.useDeferredValue = function(e, t) {
            return C.H.useDeferredValue(e, t)
        }, e.useEffect = function(e, t) {
            return C.H.useEffect(e, t)
        }, e.useEffectEvent = function(e) {
            return C.H.useEffectEvent(e)
        }, e.useId = function() {
            return C.H.useId()
        }, e.useImperativeHandle = function(e, t, n) {
            return C.H.useImperativeHandle(e, t, n)
        }, e.useInsertionEffect = function(e, t) {
            return C.H.useInsertionEffect(e, t)
        }, e.useLayoutEffect = function(e, t) {
            return C.H.useLayoutEffect(e, t)
        }, e.useMemo = function(e, t) {
            return C.H.useMemo(e, t)
        }, e.useOptimistic = function(e, t) {
            return C.H.useOptimistic(e, t)
        }, e.useReducer = function(e, t, n) {
            return C.H.useReducer(e, t, n)
        }, e.useRef = function(e) {
            return C.H.useRef(e)
        }, e.useState = function(e) {
            return C.H.useState(e)
        }, e.useSyncExternalStore = function(e, t, n) {
            return C.H.useSyncExternalStore(e, t, n)
        }, e.useTransition = function() {
            return C.H.useTransition()
        }, e.version = `19.2.5`
    })),
    u = o(((e, t) => {
        t.exports = l()
    })),
    d = o((e => {
        function t(e, t) {
            var n = e.length;
            e.push(t);
            a: for (; 0 < n;) {
                var r = n - 1 >>> 1,
                    a = e[r];
                if (0 < i(a, t)) e[r] = t, e[n] = a, n = r;
                else break a
            }
        }

        function n(e) {
            return e.length === 0 ? null : e[0]
        }

        function r(e) {
            if (e.length === 0) return null;
            var t = e[0],
                n = e.pop();
            if (n !== t) {
                e[0] = n;
                a: for (var r = 0, a = e.length, o = a >>> 1; r < o;) {
                    var s = 2 * (r + 1) - 1,
                        c = e[s],
                        l = s + 1,
                        u = e[l];
                    if (0 > i(c, n)) l < a && 0 > i(u, c) ? (e[r] = u, e[l] = n, r = l) : (e[r] = c, e[s] = n, r = s);
                    else if (l < a && 0 > i(u, n)) e[r] = u, e[l] = n, r = l;
                    else break a
                }
            }
            return t
        }

        function i(e, t) {
            var n = e.sortIndex - t.sortIndex;
            return n === 0 ? e.id - t.id : n
        }
        if (e.unstable_now = void 0, typeof performance == `object` && typeof performance.now == `function`) {
            var a = performance;
            e.unstable_now = function() {
                return a.now()
            }
        } else {
            var o = Date,
                s = o.now();
            e.unstable_now = function() {
                return o.now() - s
            }
        }
        var c = [],
            l = [],
            u = 1,
            d = null,
            f = 3,
            p = !1,
            m = !1,
            h = !1,
            g = !1,
            _ = typeof setTimeout == `function` ? setTimeout : null,
            v = typeof clearTimeout == `function` ? clearTimeout : null,
            y = typeof setImmediate < `u` ? setImmediate : null;

        function b(e) {
            for (var i = n(l); i !== null;) {
                if (i.callback === null) r(l);
                else if (i.startTime <= e) r(l), i.sortIndex = i.expirationTime, t(c, i);
                else break;
                i = n(l)
            }
        }

        function x(e) {
            if (h = !1, b(e), !m)
                if (n(c) !== null) m = !0, ee || (ee = !0, ie());
                else {
                    var t = n(l);
                    t !== null && se(x, t.startTime - e)
                }
        }
        var ee = !1,
            S = -1,
            C = 5,
            te = -1;

        function ne() {
            return g ? !0 : !(e.unstable_now() - te < C)
        }

        function re() {
            if (g = !1, ee) {
                var t = e.unstable_now();
                te = t;
                var i = !0;
                try {
                    a: {
                        m = !1,
                        h && (h = !1, v(S), S = -1),
                        p = !0;
                        var a = f;
                        try {
                            b: {
                                for (b(t), d = n(c); d !== null && !(d.expirationTime > t && ne());) {
                                    var o = d.callback;
                                    if (typeof o == `function`) {
                                        d.callback = null, f = d.priorityLevel;
                                        var s = o(d.expirationTime <= t);
                                        if (t = e.unstable_now(), typeof s == `function`) {
                                            d.callback = s, b(t), i = !0;
                                            break b
                                        }
                                        d === n(c) && r(c), b(t)
                                    } else r(c);
                                    d = n(c)
                                }
                                if (d !== null) i = !0;
                                else {
                                    var u = n(l);
                                    u !== null && se(x, u.startTime - t), i = !1
                                }
                            }
                            break a
                        }
                        finally {
                            d = null, f = a, p = !1
                        }
                        i = void 0
                    }
                }
                finally {
                    i ? ie() : ee = !1
                }
            }
        }
        var ie;
        if (typeof y == `function`) ie = function() {
            y(re)
        };
        else if (typeof MessageChannel < `u`) {
            var ae = new MessageChannel,
                oe = ae.port2;
            ae.port1.onmessage = re, ie = function() {
                oe.postMessage(null)
            }
        } else ie = function() {
            _(re, 0)
        };

        function se(t, n) {
            S = _(function() {
                t(e.unstable_now())
            }, n)
        }
        e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(e) {
            e.callback = null
        }, e.unstable_forceFrameRate = function(e) {
            0 > e || 125 < e ? console.error(`forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`) : C = 0 < e ? Math.floor(1e3 / e) : 5
        }, e.unstable_getCurrentPriorityLevel = function() {
            return f
        }, e.unstable_next = function(e) {
            switch (f) {
                case 1:
                case 2:
                case 3:
                    var t = 3;
                    break;
                default:
                    t = f
            }
            var n = f;
            f = t;
            try {
                return e()
            } finally {
                f = n
            }
        }, e.unstable_requestPaint = function() {
            g = !0
        }, e.unstable_runWithPriority = function(e, t) {
            switch (e) {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    break;
                default:
                    e = 3
            }
            var n = f;
            f = e;
            try {
                return t()
            } finally {
                f = n
            }
        }, e.unstable_scheduleCallback = function(r, i, a) {
            var o = e.unstable_now();
            switch (typeof a == `object` && a ? (a = a.delay, a = typeof a == `number` && 0 < a ? o + a : o) : a = o, r) {
                case 1:
                    var s = -1;
                    break;
                case 2:
                    s = 250;
                    break;
                case 5:
                    s = 1073741823;
                    break;
                case 4:
                    s = 1e4;
                    break;
                default:
                    s = 5e3
            }
            return s = a + s, r = {
                id: u++,
                callback: i,
                priorityLevel: r,
                startTime: a,
                expirationTime: s,
                sortIndex: -1
            }, a > o ? (r.sortIndex = a, t(l, r), n(c) === null && r === n(l) && (h ? (v(S), S = -1) : h = !0, se(x, a - o))) : (r.sortIndex = s, t(c, r), m || p || (m = !0, ee || (ee = !0, ie()))), r
        }, e.unstable_shouldYield = ne, e.unstable_wrapCallback = function(e) {
            var t = f;
            return function() {
                var n = f;
                f = t;
                try {
                    return e.apply(this, arguments)
                } finally {
                    f = n
                }
            }
        }
    })),
    f = o(((e, t) => {
        t.exports = d()
    })),
    p = o((e => {
        var t = u();

        function n(e) {
            var t = `https://react.dev/errors/` + e;
            if (1 < arguments.length) {
                t += `?args[]=` + encodeURIComponent(arguments[1]);
                for (var n = 2; n < arguments.length; n++) t += `&args[]=` + encodeURIComponent(arguments[n])
            }
            return `Minified React error #` + e + `; visit ` + t + ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`
        }

        function r() {}
        var i = {
                d: {
                    f: r,
                    r: function() {
                        throw Error(n(522))
                    },
                    D: r,
                    C: r,
                    L: r,
                    m: r,
                    X: r,
                    S: r,
                    M: r
                },
                p: 0,
                findDOMNode: null
            },
            a = Symbol.for(`react.portal`);

        function o(e, t, n) {
            var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
            return {
                $$typeof: a,
                key: r == null ? null : `` + r,
                children: e,
                containerInfo: t,
                implementation: n
            }
        }
        var s = t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;

        function c(e, t) {
            if (e === `font`) return ``;
            if (typeof t == `string`) return t === `use-credentials` ? t : ``
        }
        e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = i, e.createPortal = function(e, t) {
            var r = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
            if (!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11) throw Error(n(299));
            return o(e, t, null, r)
        }, e.flushSync = function(e) {
            var t = s.T,
                n = i.p;
            try {
                if (s.T = null, i.p = 2, e) return e()
            } finally {
                s.T = t, i.p = n, i.d.f()
            }
        }, e.preconnect = function(e, t) {
            typeof e == `string` && (t ? (t = t.crossOrigin, t = typeof t == `string` ? t === `use-credentials` ? t : `` : void 0) : t = null, i.d.C(e, t))
        }, e.prefetchDNS = function(e) {
            typeof e == `string` && i.d.D(e)
        }, e.preinit = function(e, t) {
            if (typeof e == `string` && t && typeof t.as == `string`) {
                var n = t.as,
                    r = c(n, t.crossOrigin),
                    a = typeof t.integrity == `string` ? t.integrity : void 0,
                    o = typeof t.fetchPriority == `string` ? t.fetchPriority : void 0;
                n === `style` ? i.d.S(e, typeof t.precedence == `string` ? t.precedence : void 0, {
                    crossOrigin: r,
                    integrity: a,
                    fetchPriority: o
                }) : n === `script` && i.d.X(e, {
                    crossOrigin: r,
                    integrity: a,
                    fetchPriority: o,
                    nonce: typeof t.nonce == `string` ? t.nonce : void 0
                })
            }
        }, e.preinitModule = function(e, t) {
            if (typeof e == `string`)
                if (typeof t == `object` && t) {
                    if (t.as == null || t.as === `script`) {
                        var n = c(t.as, t.crossOrigin);
                        i.d.M(e, {
                            crossOrigin: n,
                            integrity: typeof t.integrity == `string` ? t.integrity : void 0,
                            nonce: typeof t.nonce == `string` ? t.nonce : void 0
                        })
                    }
                } else t ? ? i.d.M(e)
        }, e.preload = function(e, t) {
            if (typeof e == `string` && typeof t == `object` && t && typeof t.as == `string`) {
                var n = t.as,
                    r = c(n, t.crossOrigin);
                i.d.L(e, n, {
                    crossOrigin: r,
                    integrity: typeof t.integrity == `string` ? t.integrity : void 0,
                    nonce: typeof t.nonce == `string` ? t.nonce : void 0,
                    type: typeof t.type == `string` ? t.type : void 0,
                    fetchPriority: typeof t.fetchPriority == `string` ? t.fetchPriority : void 0,
                    referrerPolicy: typeof t.referrerPolicy == `string` ? t.referrerPolicy : void 0,
                    imageSrcSet: typeof t.imageSrcSet == `string` ? t.imageSrcSet : void 0,
                    imageSizes: typeof t.imageSizes == `string` ? t.imageSizes : void 0,
                    media: typeof t.media == `string` ? t.media : void 0
                })
            }
        }, e.preloadModule = function(e, t) {
            if (typeof e == `string`)
                if (t) {
                    var n = c(t.as, t.crossOrigin);
                    i.d.m(e, {
                        as: typeof t.as == `string` && t.as !== `script` ? t.as : void 0,
                        crossOrigin: n,
                        integrity: typeof t.integrity == `string` ? t.integrity : void 0
                    })
                } else i.d.m(e)
        }, e.requestFormReset = function(e) {
            i.d.r(e)
        }, e.unstable_batchedUpdates = function(e, t) {
            return e(t)
        }, e.useFormState = function(e, t, n) {
            return s.H.useFormState(e, t, n)
        }, e.useFormStatus = function() {
            return s.H.useHostTransitionStatus()
        }, e.version = `19.2.5`
    })),
    m = o(((e, t) => {
        function n() {
            if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > `u` || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != `function`)) try {
                __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)
            } catch (e) {
                console.error(e)
            }
        }
        n(), t.exports = p()
    })),
    h = o((e => {
        var t = f(),
            n = u(),
            r = m();

        function i(e) {
            var t = `https://react.dev/errors/` + e;
            if (1 < arguments.length) {
                t += `?args[]=` + encodeURIComponent(arguments[1]);
                for (var n = 2; n < arguments.length; n++) t += `&args[]=` + encodeURIComponent(arguments[n])
            }
            return `Minified React error #` + e + `; visit ` + t + ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`
        }

        function a(e) {
            return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
        }

        function o(e) {
            var t = e,
                n = e;
            if (e.alternate)
                for (; t.return;) t = t.return;
            else {
                e = t;
                do t = e, t.flags & 4098 && (n = t.return), e = t.return; while (e)
            }
            return t.tag === 3 ? n : null
        }

        function s(e) {
            if (e.tag === 13) {
                var t = e.memoizedState;
                if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
            }
            return null
        }

        function c(e) {
            if (e.tag === 31) {
                var t = e.memoizedState;
                if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
            }
            return null
        }

        function l(e) {
            if (o(e) !== e) throw Error(i(188))
        }

        function d(e) {
            var t = e.alternate;
            if (!t) {
                if (t = o(e), t === null) throw Error(i(188));
                return t === e ? e : null
            }
            for (var n = e, r = t;;) {
                var a = n.return;
                if (a === null) break;
                var s = a.alternate;
                if (s === null) {
                    if (r = a.return, r !== null) {
                        n = r;
                        continue
                    }
                    break
                }
                if (a.child === s.child) {
                    for (s = a.child; s;) {
                        if (s === n) return l(a), e;
                        if (s === r) return l(a), t;
                        s = s.sibling
                    }
                    throw Error(i(188))
                }
                if (n.return !== r.return) n = a, r = s;
                else {
                    for (var c = !1, u = a.child; u;) {
                        if (u === n) {
                            c = !0, n = a, r = s;
                            break
                        }
                        if (u === r) {
                            c = !0, r = a, n = s;
                            break
                        }
                        u = u.sibling
                    }
                    if (!c) {
                        for (u = s.child; u;) {
                            if (u === n) {
                                c = !0, n = s, r = a;
                                break
                            }
                            if (u === r) {
                                c = !0, r = s, n = a;
                                break
                            }
                            u = u.sibling
                        }
                        if (!c) throw Error(i(189))
                    }
                }
                if (n.alternate !== r) throw Error(i(190))
            }
            if (n.tag !== 3) throw Error(i(188));
            return n.stateNode.current === n ? e : t
        }

        function p(e) {
            var t = e.tag;
            if (t === 5 || t === 26 || t === 27 || t === 6) return e;
            for (e = e.child; e !== null;) {
                if (t = p(e), t !== null) return t;
                e = e.sibling
            }
            return null
        }
        var h = Object.assign,
            g = Symbol.for(`react.element`),
            _ = Symbol.for(`react.transitional.element`),
            v = Symbol.for(`react.portal`),
            y = Symbol.for(`react.fragment`),
            b = Symbol.for(`react.strict_mode`),
            x = Symbol.for(`react.profiler`),
            ee = Symbol.for(`react.consumer`),
            S = Symbol.for(`react.context`),
            C = Symbol.for(`react.forward_ref`),
            te = Symbol.for(`react.suspense`),
            ne = Symbol.for(`react.suspense_list`),
            re = Symbol.for(`react.memo`),
            ie = Symbol.for(`react.lazy`),
            ae = Symbol.for(`react.activity`),
            oe = Symbol.for(`react.memo_cache_sentinel`),
            se = Symbol.iterator;

        function ce(e) {
            return typeof e != `object` || !e ? null : (e = se && e[se] || e[`@@iterator`], typeof e == `function` ? e : null)
        }
        var le = Symbol.for(`react.client.reference`);

        function ue(e) {
            if (e == null) return null;
            if (typeof e == `function`) return e.$$typeof === le ? null : e.displayName || e.name || null;
            if (typeof e == `string`) return e;
            switch (e) {
                case y:
                    return `Fragment`;
                case x:
                    return `Profiler`;
                case b:
                    return `StrictMode`;
                case te:
                    return `Suspense`;
                case ne:
                    return `SuspenseList`;
                case ae:
                    return `Activity`
            }
            if (typeof e == `object`) switch (e.$$typeof) {
                case v:
                    return `Portal`;
                case S:
                    return e.displayName || `Context`;
                case ee:
                    return (e._context.displayName || `Context`) + `.Consumer`;
                case C:
                    var t = e.render;
                    return e = e.displayName, e || = (e = t.displayName || t.name || ``, e === `` ? `ForwardRef` : `ForwardRef(` + e + `)`), e;
                case re:
                    return t = e.displayName || null, t === null ? ue(e.type) || `Memo` : t;
                case ie:
                    t = e._payload, e = e._init;
                    try {
                        return ue(e(t))
                    } catch {}
            }
            return null
        }
        var de = Array.isArray,
            w = n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
            E = r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
            fe = {
                pending: !1,
                data: null,
                method: null,
                action: null
            },
            pe = [],
            me = -1;

        function he(e) {
            return {
                current: e
            }
        }

        function D(e) {
            0 > me || (e.current = pe[me], pe[me] = null, me--)
        }

        function O(e, t) {
            me++, pe[me] = e.current, e.current = t
        }
        var ge = he(null),
            _e = he(null),
            ve = he(null),
            ye = he(null);

        function be(e, t) {
            switch (O(ve, t), O(_e, e), O(ge, null), t.nodeType) {
                case 9:
                case 11:
                    e = (e = t.documentElement) && (e = e.namespaceURI) ? Hd(e) : 0;
                    break;
                default:
                    if (e = t.tagName, t = t.namespaceURI) t = Hd(t), e = Ud(t, e);
                    else switch (e) {
                        case `svg`:
                            e = 1;
                            break;
                        case `math`:
                            e = 2;
                            break;
                        default:
                            e = 0
                    }
            }
            D(ge), O(ge, e)
        }

        function xe() {
            D(ge), D(_e), D(ve)
        }

        function Se(e) {
            e.memoizedState !== null && O(ye, e);
            var t = ge.current,
                n = Ud(t, e.type);
            t !== n && (O(_e, e), O(ge, n))
        }

        function Ce(e) {
            _e.current === e && (D(ge), D(_e)), ye.current === e && (D(ye), $f._currentValue = fe)
        }
        var we, Te;

        function Ee(e) {
            if (we === void 0) try {
                throw Error()
            } catch (e) {
                var t = e.stack.trim().match(/\n( *(at )?)/);
                we = t && t[1] || ``, Te = -1 < e.stack.indexOf(`
    at`) ? ` (<anonymous>)` : -1 < e.stack.indexOf(`@`) ? `@unknown:0:0` : ``
            }
            return `
` + we + e + Te
        }
        var De = !1;

        function Oe(e, t) {
            if (!e || De) return ``;
            De = !0;
            var n = Error.prepareStackTrace;
            Error.prepareStackTrace = void 0;
            try {
                var r = {
                    DetermineComponentFrameRoot: function() {
                        try {
                            if (t) {
                                var n = function() {
                                    throw Error()
                                };
                                if (Object.defineProperty(n.prototype, "props", {
                                        set: function() {
                                            throw Error()
                                        }
                                    }), typeof Reflect == `object` && Reflect.construct) {
                                    try {
                                        Reflect.construct(n, [])
                                    } catch (e) {
                                        var r = e
                                    }
                                    Reflect.construct(e, [], n)
                                } else {
                                    try {
                                        n.call()
                                    } catch (e) {
                                        r = e
                                    }
                                    e.call(n.prototype)
                                }
                            } else {
                                try {
                                    throw Error()
                                } catch (e) {
                                    r = e
                                }(n = e()) && typeof n.catch == `function` && n.catch(function() {})
                            }
                        } catch (e) {
                            if (e && r && typeof e.stack == `string`) return [e.stack, r.stack]
                        }
                        return [null, null]
                    }
                };
                r.DetermineComponentFrameRoot.displayName = `DetermineComponentFrameRoot`;
                var i = Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot, `name`);
                i && i.configurable && Object.defineProperty(r.DetermineComponentFrameRoot, "name", {
                    value: `DetermineComponentFrameRoot`
                });
                var a = r.DetermineComponentFrameRoot(),
                    o = a[0],
                    s = a[1];
                if (o && s) {
                    var c = o.split(`
`),
                        l = s.split(`
`);
                    for (i = r = 0; r < c.length && !c[r].includes(`DetermineComponentFrameRoot`);) r++;
                    for (; i < l.length && !l[i].includes(`DetermineComponentFrameRoot`);) i++;
                    if (r === c.length || i === l.length)
                        for (r = c.length - 1, i = l.length - 1; 1 <= r && 0 <= i && c[r] !== l[i];) i--;
                    for (; 1 <= r && 0 <= i; r--, i--)
                        if (c[r] !== l[i]) {
                            if (r !== 1 || i !== 1)
                                do
                                    if (r--, i--, 0 > i || c[r] !== l[i]) {
                                        var u = `
` + c[r].replace(` at new `, ` at `);
                                        return e.displayName && u.includes(`<anonymous>`) && (u = u.replace(`<anonymous>`, e.displayName)), u
                                    }
                            while (1 <= r && 0 <= i);
                            break
                        }
                }
            } finally {
                De = !1, Error.prepareStackTrace = n
            }
            return (n = e ? e.displayName || e.name : ``) ? Ee(n) : ``
        }

        function ke(e, t) {
            switch (e.tag) {
                case 26:
                case 27:
                case 5:
                    return Ee(e.type);
                case 16:
                    return Ee(`Lazy`);
                case 13:
                    return e.child !== t && t !== null ? Ee(`Suspense Fallback`) : Ee(`Suspense`);
                case 19:
                    return Ee(`SuspenseList`);
                case 0:
                case 15:
                    return Oe(e.type, !1);
                case 11:
                    return Oe(e.type.render, !1);
                case 1:
                    return Oe(e.type, !0);
                case 31:
                    return Ee(`Activity`);
                default:
                    return ``
            }
        }

        function Ae(e) {
            try {
                var t = ``,
                    n = null;
                do t += ke(e, n), n = e, e = e.return; while (e);
                return t
            } catch (e) {
                return `
Error generating stack: ` + e.message + `
` + e.stack
            }
        }
        var je = Object.prototype.hasOwnProperty,
            Me = t.unstable_scheduleCallback,
            Ne = t.unstable_cancelCallback,
            Pe = t.unstable_shouldYield,
            Fe = t.unstable_requestPaint,
            Ie = t.unstable_now,
            Le = t.unstable_getCurrentPriorityLevel,
            Re = t.unstable_ImmediatePriority,
            ze = t.unstable_UserBlockingPriority,
            Be = t.unstable_NormalPriority,
            Ve = t.unstable_LowPriority,
            He = t.unstable_IdlePriority,
            Ue = t.log,
            We = t.unstable_setDisableYieldValue,
            Ge = null,
            Ke = null;

        function qe(e) {
            if (typeof Ue == `function` && We(e), Ke && typeof Ke.setStrictMode == `function`) try {
                Ke.setStrictMode(Ge, e)
            } catch {}
        }
        var Je = Math.clz32 ? Math.clz32 : Ze,
            Ye = Math.log,
            Xe = Math.LN2;

        function Ze(e) {
            return e >>>= 0, e === 0 ? 32 : 31 - (Ye(e) / Xe | 0) | 0
        }
        var Qe = 256,
            $e = 262144,
            et = 4194304;

        function tt(e) {
            var t = e & 42;
            if (t !== 0) return t;
            switch (e & -e) {
                case 1:
                    return 1;
                case 2:
                    return 2;
                case 4:
                    return 4;
                case 8:
                    return 8;
                case 16:
                    return 16;
                case 32:
                    return 32;
                case 64:
                    return 64;
                case 128:
                    return 128;
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                    return e & 261888;
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                    return e & 3932160;
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                    return e & 62914560;
                case 67108864:
                    return 67108864;
                case 134217728:
                    return 134217728;
                case 268435456:
                    return 268435456;
                case 536870912:
                    return 536870912;
                case 1073741824:
                    return 0;
                default:
                    return e
            }
        }

        function nt(e, t, n) {
            var r = e.pendingLanes;
            if (r === 0) return 0;
            var i = 0,
                a = e.suspendedLanes,
                o = e.pingedLanes;
            e = e.warmLanes;
            var s = r & 134217727;
            return s === 0 ? (s = r & ~a, s === 0 ? o === 0 ? n || (n = r & ~e, n !== 0 && (i = tt(n))) : i = tt(o) : i = tt(s)) : (r = s & ~a, r === 0 ? (o &= s, o === 0 ? n || (n = s & ~e, n !== 0 && (i = tt(n))) : i = tt(o)) : i = tt(r)), i === 0 ? 0 : t !== 0 && t !== i && (t & a) === 0 && (a = i & -i, n = t & -t, a >= n || a === 32 && n & 4194048) ? t : i
        }

        function rt(e, t) {
            return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0
        }

        function it(e, t) {
            switch (e) {
                case 1:
                case 2:
                case 4:
                case 8:
                case 64:
                    return t + 250;
                case 16:
                case 32:
                case 128:
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                    return t + 5e3;
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                    return -1;
                case 67108864:
                case 134217728:
                case 268435456:
                case 536870912:
                case 1073741824:
                    return -1;
                default:
                    return -1
            }
        }

        function at() {
            var e = et;
            return et <<= 1, !(et & 62914560) && (et = 4194304), e
        }

        function ot(e) {
            for (var t = [], n = 0; 31 > n; n++) t.push(e);
            return t
        }

        function st(e, t) {
            e.pendingLanes |= t, t !== 268435456 && (e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0)
        }

        function ct(e, t, n, r, i, a) {
            var o = e.pendingLanes;
            e.pendingLanes = n, e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0, e.expiredLanes &= n, e.entangledLanes &= n, e.errorRecoveryDisabledLanes &= n, e.shellSuspendCounter = 0;
            var s = e.entanglements,
                c = e.expirationTimes,
                l = e.hiddenUpdates;
            for (n = o & ~n; 0 < n;) {
                var u = 31 - Je(n),
                    d = 1 << u;
                s[u] = 0, c[u] = -1;
                var f = l[u];
                if (f !== null)
                    for (l[u] = null, u = 0; u < f.length; u++) {
                        var p = f[u];
                        p !== null && (p.lane &= -536870913)
                    }
                n &= ~d
            }
            r !== 0 && lt(e, r, 0), a !== 0 && i === 0 && e.tag !== 0 && (e.suspendedLanes |= a & ~(o & ~t))
        }

        function lt(e, t, n) {
            e.pendingLanes |= t, e.suspendedLanes &= ~t;
            var r = 31 - Je(t);
            e.entangledLanes |= t, e.entanglements[r] = e.entanglements[r] | 1073741824 | n & 261930
        }

        function ut(e, t) {
            var n = e.entangledLanes |= t;
            for (e = e.entanglements; n;) {
                var r = 31 - Je(n),
                    i = 1 << r;
                i & t | e[r] & t && (e[r] |= t), n &= ~i
            }
        }

        function dt(e, t) {
            var n = t & -t;
            return n = n & 42 ? 1 : ft(n), (n & (e.suspendedLanes | t)) === 0 ? n : 0
        }

        function ft(e) {
            switch (e) {
                case 2:
                    e = 1;
                    break;
                case 8:
                    e = 4;
                    break;
                case 32:
                    e = 16;
                    break;
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                    e = 128;
                    break;
                case 268435456:
                    e = 134217728;
                    break;
                default:
                    e = 0
            }
            return e
        }

        function pt(e) {
            return e &= -e, 2 < e ? 8 < e ? e & 134217727 ? 32 : 268435456 : 8 : 2
        }

        function mt() {
            var e = E.p;
            return e === 0 ? (e = window.event, e === void 0 ? 32 : hp(e.type)) : e
        }

        function ht(e, t) {
            var n = E.p;
            try {
                return E.p = e, t()
            } finally {
                E.p = n
            }
        }
        var gt = Math.random().toString(36).slice(2),
            _t = `__reactFiber$` + gt,
            k = `__reactProps$` + gt,
            vt = `__reactContainer$` + gt,
            yt = `__reactEvents$` + gt,
            bt = `__reactListeners$` + gt,
            xt = `__reactHandles$` + gt,
            St = `__reactResources$` + gt,
            Ct = `__reactMarker$` + gt;

        function wt(e) {
            delete e[_t], delete e[k], delete e[yt], delete e[bt], delete e[xt]
        }

        function Tt(e) {
            var t = e[_t];
            if (t) return t;
            for (var n = e.parentNode; n;) {
                if (t = n[vt] || n[_t]) {
                    if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
                        for (e = ff(e); e !== null;) {
                            if (n = e[_t]) return n;
                            e = ff(e)
                        }
                    return t
                }
                e = n, n = e.parentNode
            }
            return null
        }

        function Et(e) {
            if (e = e[_t] || e[vt]) {
                var t = e.tag;
                if (t === 5 || t === 6 || t === 13 || t === 31 || t === 26 || t === 27 || t === 3) return e
            }
            return null
        }

        function Dt(e) {
            var t = e.tag;
            if (t === 5 || t === 26 || t === 27 || t === 6) return e.stateNode;
            throw Error(i(33))
        }

        function Ot(e) {
            var t = e[St];
            return t || = e[St] = {
                hoistableStyles: new Map,
                hoistableScripts: new Map
            }, t
        }

        function kt(e) {
            e[Ct] = !0
        }
        var At = new Set,
            jt = {};

        function Mt(e, t) {
            Nt(e, t), Nt(e + `Capture`, t)
        }

        function Nt(e, t) {
            for (jt[e] = t, e = 0; e < t.length; e++) At.add(t[e])
        }
        var Pt = RegExp(`^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`),
            Ft = {},
            It = {};

        function Lt(e) {
            return je.call(It, e) ? !0 : je.call(Ft, e) ? !1 : Pt.test(e) ? It[e] = !0 : (Ft[e] = !0, !1)
        }

        function Rt(e, t, n) {
            if (Lt(t))
                if (n === null) e.removeAttribute(t);
                else {
                    switch (typeof n) {
                        case `undefined`:
                        case `function`:
                        case `symbol`:
                            e.removeAttribute(t);
                            return;
                        case `boolean`:
                            var r = t.toLowerCase().slice(0, 5);
                            if (r !== `data-` && r !== `aria-`) {
                                e.removeAttribute(t);
                                return
                            }
                    }
                    e.setAttribute(t, `` + n)
                }
        }

        function zt(e, t, n) {
            if (n === null) e.removeAttribute(t);
            else {
                switch (typeof n) {
                    case `undefined`:
                    case `function`:
                    case `symbol`:
                    case `boolean`:
                        e.removeAttribute(t);
                        return
                }
                e.setAttribute(t, `` + n)
            }
        }

        function Bt(e, t, n, r) {
            if (r === null) e.removeAttribute(n);
            else {
                switch (typeof r) {
                    case `undefined`:
                    case `function`:
                    case `symbol`:
                    case `boolean`:
                        e.removeAttribute(n);
                        return
                }
                e.setAttributeNS(t, n, `` + r)
            }
        }

        function Vt(e) {
            switch (typeof e) {
                case `bigint`:
                case `boolean`:
                case `number`:
                case `string`:
                case `undefined`:
                    return e;
                case `object`:
                    return e;
                default:
                    return ``
            }
        }

        function Ht(e) {
            var t = e.type;
            return (e = e.nodeName) && e.toLowerCase() === `input` && (t === `checkbox` || t === `radio`)
        }

        function Ut(e, t, n) {
            var r = Object.getOwnPropertyDescriptor(e.constructor.prototype, t);
            if (!e.hasOwnProperty(t) && r !== void 0 && typeof r.get == `function` && typeof r.set == `function`) {
                var i = r.get,
                    a = r.set;
                return Object.defineProperty(e, t, {
                    configurable: !0,
                    get: function() {
                        return i.call(this)
                    },
                    set: function(e) {
                        n = `` + e, a.call(this, e)
                    }
                }), Object.defineProperty(e, t, {
                    enumerable: r.enumerable
                }), {
                    getValue: function() {
                        return n
                    },
                    setValue: function(e) {
                        n = `` + e
                    },
                    stopTracking: function() {
                        e._valueTracker = null, delete e[t]
                    }
                }
            }
        }

        function Wt(e) {
            if (!e._valueTracker) {
                var t = Ht(e) ? `checked` : `value`;
                e._valueTracker = Ut(e, t, `` + e[t])
            }
        }

        function Gt(e) {
            if (!e) return !1;
            var t = e._valueTracker;
            if (!t) return !0;
            var n = t.getValue(),
                r = ``;
            return e && (r = Ht(e) ? e.checked ? `true` : `false` : e.value), e = r, e === n ? !1 : (t.setValue(e), !0)
        }

        function Kt(e) {
            if (e || = typeof document < `u` ? document : void 0, e === void 0) return null;
            try {
                return e.activeElement || e.body
            } catch {
                return e.body
            }
        }
        var qt = /[\n"\\]/g;

        function Jt(e) {
            return e.replace(qt, function(e) {
                return `\\` + e.charCodeAt(0).toString(16) + ` `
            })
        }

        function Yt(e, t, n, r, i, a, o, s) {
            e.name = ``, o != null && typeof o != `function` && typeof o != `symbol` && typeof o != `boolean` ? e.type = o : e.removeAttribute(`type`), t == null ? o !== `submit` && o !== `reset` || e.removeAttribute(`value`) : o === `number` ? (t === 0 && e.value === `` || e.value != t) && (e.value = `` + Vt(t)) : e.value !== `` + Vt(t) && (e.value = `` + Vt(t)), t == null ? n == null ? r != null && e.removeAttribute(`value`) : Zt(e, o, Vt(n)) : Zt(e, o, Vt(t)), i == null && a != null && (e.defaultChecked = !!a), i != null && (e.checked = i && typeof i != `function` && typeof i != `symbol`), s != null && typeof s != `function` && typeof s != `symbol` && typeof s != `boolean` ? e.name = `` + Vt(s) : e.removeAttribute(`name`)
        }

        function Xt(e, t, n, r, i, a, o, s) {
            if (a != null && typeof a != `function` && typeof a != `symbol` && typeof a != `boolean` && (e.type = a), t != null || n != null) {
                if (!(a !== `submit` && a !== `reset` || t != null)) {
                    Wt(e);
                    return
                }
                n = n == null ? `` : `` + Vt(n), t = t == null ? n : `` + Vt(t), s || t === e.value || (e.value = t), e.defaultValue = t
            }
            r ? ? = i, r = typeof r != `function` && typeof r != `symbol` && !!r, e.checked = s ? e.checked : !!r, e.defaultChecked = !!r, o != null && typeof o != `function` && typeof o != `symbol` && typeof o != `boolean` && (e.name = o), Wt(e)
        }

        function Zt(e, t, n) {
            t === `number` && Kt(e.ownerDocument) === e || e.defaultValue === `` + n || (e.defaultValue = `` + n)
        }

        function Qt(e, t, n, r) {
            if (e = e.options, t) {
                t = {};
                for (var i = 0; i < n.length; i++) t[`$` + n[i]] = !0;
                for (n = 0; n < e.length; n++) i = t.hasOwnProperty(`$` + e[n].value), e[n].selected !== i && (e[n].selected = i), i && r && (e[n].defaultSelected = !0)
            } else {
                for (n = `` + Vt(n), t = null, i = 0; i < e.length; i++) {
                    if (e[i].value === n) {
                        e[i].selected = !0, r && (e[i].defaultSelected = !0);
                        return
                    }
                    t !== null || e[i].disabled || (t = e[i])
                }
                t !== null && (t.selected = !0)
            }
        }

        function $t(e, t, n) {
            if (t != null && (t = `` + Vt(t), t !== e.value && (e.value = t), n == null)) {
                e.defaultValue !== t && (e.defaultValue = t);
                return
            }
            e.defaultValue = n == null ? `` : `` + Vt(n)
        }

        function en(e, t, n, r) {
            if (t == null) {
                if (r != null) {
                    if (n != null) throw Error(i(92));
                    if (de(r)) {
                        if (1 < r.length) throw Error(i(93));
                        r = r[0]
                    }
                    n = r
                }
                n ? ? = ``, t = n
            }
            n = Vt(t), e.defaultValue = n, r = e.textContent, r === n && r !== `` && r !== null && (e.value = r), Wt(e)
        }

        function tn(e, t) {
            if (t) {
                var n = e.firstChild;
                if (n && n === e.lastChild && n.nodeType === 3) {
                    n.nodeValue = t;
                    return
                }
            }
            e.textContent = t
        }
        var nn = new Set(`animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp`.split(` `));

        function rn(e, t, n) {
            var r = t.indexOf(`--`) === 0;
            n == null || typeof n == `boolean` || n === `` ? r ? e.setProperty(t, ``) : t === `float` ? e.cssFloat = `` : e[t] = `` : r ? e.setProperty(t, n) : typeof n != `number` || n === 0 || nn.has(t) ? t === `float` ? e.cssFloat = n : e[t] = (`` + n).trim() : e[t] = n + `px`
        }

        function an(e, t, n) {
            if (t != null && typeof t != `object`) throw Error(i(62));
            if (e = e.style, n != null) {
                for (var r in n) !n.hasOwnProperty(r) || t != null && t.hasOwnProperty(r) || (r.indexOf(`--`) === 0 ? e.setProperty(r, ``) : r === `float` ? e.cssFloat = `` : e[r] = ``);
                for (var a in t) r = t[a], t.hasOwnProperty(a) && n[a] !== r && rn(e, a, r)
            } else
                for (var o in t) t.hasOwnProperty(o) && rn(e, o, t[o])
        }

        function on(e) {
            if (e.indexOf(`-`) === -1) return !1;
            switch (e) {
                case `annotation-xml`:
                case `color-profile`:
                case `font-face`:
                case `font-face-src`:
                case `font-face-uri`:
                case `font-face-format`:
                case `font-face-name`:
                case `missing-glyph`:
                    return !1;
                default:
                    return !0
            }
        }
        var sn = new Map([
                [`acceptCharset`, `accept-charset`],
                [`htmlFor`, `for`],
                [`httpEquiv`, `http-equiv`],
                [`crossOrigin`, `crossorigin`],
                [`accentHeight`, `accent-height`],
                [`alignmentBaseline`, `alignment-baseline`],
                [`arabicForm`, `arabic-form`],
                [`baselineShift`, `baseline-shift`],
                [`capHeight`, `cap-height`],
                [`clipPath`, `clip-path`],
                [`clipRule`, `clip-rule`],
                [`colorInterpolation`, `color-interpolation`],
                [`colorInterpolationFilters`, `color-interpolation-filters`],
                [`colorProfile`, `color-profile`],
                [`colorRendering`, `color-rendering`],
                [`dominantBaseline`, `dominant-baseline`],
                [`enableBackground`, `enable-background`],
                [`fillOpacity`, `fill-opacity`],
                [`fillRule`, `fill-rule`],
                [`floodColor`, `flood-color`],
                [`floodOpacity`, `flood-opacity`],
                [`fontFamily`, `font-family`],
                [`fontSize`, `font-size`],
                [`fontSizeAdjust`, `font-size-adjust`],
                [`fontStretch`, `font-stretch`],
                [`fontStyle`, `font-style`],
                [`fontVariant`, `font-variant`],
                [`fontWeight`, `font-weight`],
                [`glyphName`, `glyph-name`],
                [`glyphOrientationHorizontal`, `glyph-orientation-horizontal`],
                [`glyphOrientationVertical`, `glyph-orientation-vertical`],
                [`horizAdvX`, `horiz-adv-x`],
                [`horizOriginX`, `horiz-origin-x`],
                [`imageRendering`, `image-rendering`],
                [`letterSpacing`, `letter-spacing`],
                [`lightingColor`, `lighting-color`],
                [`markerEnd`, `marker-end`],
                [`markerMid`, `marker-mid`],
                [`markerStart`, `marker-start`],
                [`overlinePosition`, `overline-position`],
                [`overlineThickness`, `overline-thickness`],
                [`paintOrder`, `paint-order`],
                [`panose-1`, `panose-1`],
                [`pointerEvents`, `pointer-events`],
                [`renderingIntent`, `rendering-intent`],
                [`shapeRendering`, `shape-rendering`],
                [`stopColor`, `stop-color`],
                [`stopOpacity`, `stop-opacity`],
                [`strikethroughPosition`, `strikethrough-position`],
                [`strikethroughThickness`, `strikethrough-thickness`],
                [`strokeDasharray`, `stroke-dasharray`],
                [`strokeDashoffset`, `stroke-dashoffset`],
                [`strokeLinecap`, `stroke-linecap`],
                [`strokeLinejoin`, `stroke-linejoin`],
                [`strokeMiterlimit`, `stroke-miterlimit`],
                [`strokeOpacity`, `stroke-opacity`],
                [`strokeWidth`, `stroke-width`],
                [`textAnchor`, `text-anchor`],
                [`textDecoration`, `text-decoration`],
                [`textRendering`, `text-rendering`],
                [`transformOrigin`, `transform-origin`],
                [`underlinePosition`, `underline-position`],
                [`underlineThickness`, `underline-thickness`],
                [`unicodeBidi`, `unicode-bidi`],
                [`unicodeRange`, `unicode-range`],
                [`unitsPerEm`, `units-per-em`],
                [`vAlphabetic`, `v-alphabetic`],
                [`vHanging`, `v-hanging`],
                [`vIdeographic`, `v-ideographic`],
                [`vMathematical`, `v-mathematical`],
                [`vectorEffect`, `vector-effect`],
                [`vertAdvY`, `vert-adv-y`],
                [`vertOriginX`, `vert-origin-x`],
                [`vertOriginY`, `vert-origin-y`],
                [`wordSpacing`, `word-spacing`],
                [`writingMode`, `writing-mode`],
                [`xmlnsXlink`, `xmlns:xlink`],
                [`xHeight`, `x-height`]
            ]),
            cn = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;

        function ln(e) {
            return cn.test(`` + e) ? `javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')` : e
        }

        function un() {}
        var dn = null;

        function fn(e) {
            return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e
        }
        var pn = null,
            mn = null;

        function hn(e) {
            var t = Et(e);
            if (t && (e = t.stateNode)) {
                var n = e[k] || null;
                a: switch (e = t.stateNode, t.type) {
                    case `input`:
                        if (Yt(e, n.value, n.defaultValue, n.defaultValue, n.checked, n.defaultChecked, n.type, n.name), t = n.name, n.type === `radio` && t != null) {
                            for (n = e; n.parentNode;) n = n.parentNode;
                            for (n = n.querySelectorAll(`input[name="` + Jt(`` + t) + `"][type="radio"]`), t = 0; t < n.length; t++) {
                                var r = n[t];
                                if (r !== e && r.form === e.form) {
                                    var a = r[k] || null;
                                    if (!a) throw Error(i(90));
                                    Yt(r, a.value, a.defaultValue, a.defaultValue, a.checked, a.defaultChecked, a.type, a.name)
                                }
                            }
                            for (t = 0; t < n.length; t++) r = n[t], r.form === e.form && Gt(r)
                        }
                        break a;
                    case `textarea`:
                        $t(e, n.value, n.defaultValue);
                        break a;
                    case `select`:
                        t = n.value, t != null && Qt(e, !!n.multiple, t, !1)
                }
            }
        }
        var gn = !1;

        function _n(e, t, n) {
            if (gn) return e(t, n);
            gn = !0;
            try {
                return e(t)
            } finally {
                if (gn = !1, (pn !== null || mn !== null) && (xu(), pn && (t = pn, e = mn, mn = pn = null, hn(t), e)))
                    for (t = 0; t < e.length; t++) hn(e[t])
            }
        }

        function vn(e, t) {
            var n = e.stateNode;
            if (n === null) return null;
            var r = n[k] || null;
            if (r === null) return null;
            n = r[t];
            a: switch (t) {
                case `onClick`:
                case `onClickCapture`:
                case `onDoubleClick`:
                case `onDoubleClickCapture`:
                case `onMouseDown`:
                case `onMouseDownCapture`:
                case `onMouseMove`:
                case `onMouseMoveCapture`:
                case `onMouseUp`:
                case `onMouseUpCapture`:
                case `onMouseEnter`:
                    (r = !r.disabled) || (e = e.type, r = !(e === `button` || e === `input` || e === `select` || e === `textarea`)), e = !r;
                    break a;
                default:
                    e = !1
            }
            if (e) return null;
            if (n && typeof n != `function`) throw Error(i(231, t, typeof n));
            return n
        }
        var yn = !(typeof window > `u` || window.document === void 0 || window.document.createElement === void 0),
            bn = !1;
        if (yn) try {
            var xn = {};
            Object.defineProperty(xn, "passive", {
                get: function() {
                    bn = !0
                }
            }), window.addEventListener(`test`, xn, xn), window.removeEventListener(`test`, xn, xn)
        } catch {
            bn = !1
        }
        var Sn = null,
            Cn = null,
            wn = null;

        function Tn() {
            if (wn) return wn;
            var e, t = Cn,
                n = t.length,
                r, i = `value` in Sn ? Sn.value : Sn.textContent,
                a = i.length;
            for (e = 0; e < n && t[e] === i[e]; e++);
            var o = n - e;
            for (r = 1; r <= o && t[n - r] === i[a - r]; r++);
            return wn = i.slice(e, 1 < r ? 1 - r : void 0)
        }

        function En(e) {
            var t = e.keyCode;
            return `charCode` in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0
        }

        function Dn() {
            return !0
        }

        function On() {
            return !1
        }

        function kn(e) {
            function t(t, n, r, i, a) {
                for (var o in this._reactName = t, this._targetInst = r, this.type = n, this.nativeEvent = i, this.target = a, this.currentTarget = null, e) e.hasOwnProperty(o) && (t = e[o], this[o] = t ? t(i) : i[o]);
                return this.isDefaultPrevented = (i.defaultPrevented == null ? !1 === i.returnValue : i.defaultPrevented) ? Dn : On, this.isPropagationStopped = On, this
            }
            return h(t.prototype, {
                preventDefault: function() {
                    this.defaultPrevented = !0;
                    var e = this.nativeEvent;
                    e && (e.preventDefault ? e.preventDefault() : typeof e.returnValue != `unknown` && (e.returnValue = !1), this.isDefaultPrevented = Dn)
                },
                stopPropagation: function() {
                    var e = this.nativeEvent;
                    e && (e.stopPropagation ? e.stopPropagation() : typeof e.cancelBubble != `unknown` && (e.cancelBubble = !0), this.isPropagationStopped = Dn)
                },
                persist: function() {},
                isPersistent: Dn
            }), t
        }
        var An = {
                eventPhase: 0,
                bubbles: 0,
                cancelable: 0,
                timeStamp: function(e) {
                    return e.timeStamp || Date.now()
                },
                defaultPrevented: 0,
                isTrusted: 0
            },
            jn = kn(An),
            Mn = h({}, An, {
                view: 0,
                detail: 0
            }),
            Nn = kn(Mn),
            Pn, Fn, In, Ln = h({}, Mn, {
                screenX: 0,
                screenY: 0,
                clientX: 0,
                clientY: 0,
                pageX: 0,
                pageY: 0,
                ctrlKey: 0,
                shiftKey: 0,
                altKey: 0,
                metaKey: 0,
                getModifierState: Jn,
                button: 0,
                buttons: 0,
                relatedTarget: function(e) {
                    return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
                },
                movementX: function(e) {
                    return `movementX` in e ? e.movementX : (e !== In && (In && e.type === `mousemove` ? (Pn = e.screenX - In.screenX, Fn = e.screenY - In.screenY) : Fn = Pn = 0, In = e), Pn)
                },
                movementY: function(e) {
                    return `movementY` in e ? e.movementY : Fn
                }
            }),
            Rn = kn(Ln),
            zn = kn(h({}, Ln, {
                dataTransfer: 0
            })),
            Bn = kn(h({}, Mn, {
                relatedTarget: 0
            })),
            Vn = kn(h({}, An, {
                animationName: 0,
                elapsedTime: 0,
                pseudoElement: 0
            })),
            Hn = kn(h({}, An, {
                clipboardData: function(e) {
                    return `clipboardData` in e ? e.clipboardData : window.clipboardData
                }
            })),
            Un = kn(h({}, An, {
                data: 0
            })),
            Wn = {
                Esc: `Escape`,
                Spacebar: ` `,
                Left: `ArrowLeft`,
                Up: `ArrowUp`,
                Right: `ArrowRight`,
                Down: `ArrowDown`,
                Del: `Delete`,
                Win: `OS`,
                Menu: `ContextMenu`,
                Apps: `ContextMenu`,
                Scroll: `ScrollLock`,
                MozPrintableKey: `Unidentified`
            },
            Gn = {
                8: `Backspace`,
                9: `Tab`,
                12: `Clear`,
                13: `Enter`,
                16: `Shift`,
                17: `Control`,
                18: `Alt`,
                19: `Pause`,
                20: `CapsLock`,
                27: `Escape`,
                32: ` `,
                33: `PageUp`,
                34: `PageDown`,
                35: `End`,
                36: `Home`,
                37: `ArrowLeft`,
                38: `ArrowUp`,
                39: `ArrowRight`,
                40: `ArrowDown`,
                45: `Insert`,
                46: `Delete`,
                112: `F1`,
                113: `F2`,
                114: `F3`,
                115: `F4`,
                116: `F5`,
                117: `F6`,
                118: `F7`,
                119: `F8`,
                120: `F9`,
                121: `F10`,
                122: `F11`,
                123: `F12`,
                144: `NumLock`,
                145: `ScrollLock`,
                224: `Meta`
            },
            Kn = {
                Alt: `altKey`,
                Control: `ctrlKey`,
                Meta: `metaKey`,
                Shift: `shiftKey`
            };

        function qn(e) {
            var t = this.nativeEvent;
            return t.getModifierState ? t.getModifierState(e) : (e = Kn[e]) ? !!t[e] : !1
        }

        function Jn() {
            return qn
        }
        var Yn = kn(h({}, Mn, {
                key: function(e) {
                    if (e.key) {
                        var t = Wn[e.key] || e.key;
                        if (t !== `Unidentified`) return t
                    }
                    return e.type === `keypress` ? (e = En(e), e === 13 ? `Enter` : String.fromCharCode(e)) : e.type === `keydown` || e.type === `keyup` ? Gn[e.keyCode] || `Unidentified` : ``
                },
                code: 0,
                location: 0,
                ctrlKey: 0,
                shiftKey: 0,
                altKey: 0,
                metaKey: 0,
                repeat: 0,
                locale: 0,
                getModifierState: Jn,
                charCode: function(e) {
                    return e.type === `keypress` ? En(e) : 0
                },
                keyCode: function(e) {
                    return e.type === `keydown` || e.type === `keyup` ? e.keyCode : 0
                },
                which: function(e) {
                    return e.type === `keypress` ? En(e) : e.type === `keydown` || e.type === `keyup` ? e.keyCode : 0
                }
            })),
            Xn = kn(h({}, Ln, {
                pointerId: 0,
                width: 0,
                height: 0,
                pressure: 0,
                tangentialPressure: 0,
                tiltX: 0,
                tiltY: 0,
                twist: 0,
                pointerType: 0,
                isPrimary: 0
            })),
            Zn = kn(h({}, Mn, {
                touches: 0,
                targetTouches: 0,
                changedTouches: 0,
                altKey: 0,
                metaKey: 0,
                ctrlKey: 0,
                shiftKey: 0,
                getModifierState: Jn
            })),
            Qn = kn(h({}, An, {
                propertyName: 0,
                elapsedTime: 0,
                pseudoElement: 0
            })),
            $n = kn(h({}, Ln, {
                deltaX: function(e) {
                    return `deltaX` in e ? e.deltaX : `wheelDeltaX` in e ? -e.wheelDeltaX : 0
                },
                deltaY: function(e) {
                    return `deltaY` in e ? e.deltaY : `wheelDeltaY` in e ? -e.wheelDeltaY : `wheelDelta` in e ? -e.wheelDelta : 0
                },
                deltaZ: 0,
                deltaMode: 0
            })),
            er = kn(h({}, An, {
                newState: 0,
                oldState: 0
            })),
            tr = [9, 13, 27, 32],
            nr = yn && `CompositionEvent` in window,
            rr = null;
        yn && `documentMode` in document && (rr = document.documentMode);
        var A = yn && `TextEvent` in window && !rr,
            ir = yn && (!nr || rr && 8 < rr && 11 >= rr),
            ar = ` `,
            or = !1;

        function j(e, t) {
            switch (e) {
                case `keyup`:
                    return tr.indexOf(t.keyCode) !== -1;
                case `keydown`:
                    return t.keyCode !== 229;
                case `keypress`:
                case `mousedown`:
                case `focusout`:
                    return !0;
                default:
                    return !1
            }
        }

        function sr(e) {
            return e = e.detail, typeof e == `object` && `data` in e ? e.data : null
        }
        var cr = !1;

        function lr(e, t) {
            switch (e) {
                case `compositionend`:
                    return sr(t);
                case `keypress`:
                    return t.which === 32 ? (or = !0, ar) : null;
                case `textInput`:
                    return e = t.data, e === ar && or ? null : e;
                default:
                    return null
            }
        }

        function ur(e, t) {
            if (cr) return e === `compositionend` || !nr && j(e, t) ? (e = Tn(), wn = Cn = Sn = null, cr = !1, e) : null;
            switch (e) {
                case `paste`:
                    return null;
                case `keypress`:
                    if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                        if (t.char && 1 < t.char.length) return t.char;
                        if (t.which) return String.fromCharCode(t.which)
                    }
                    return null;
                case `compositionend`:
                    return ir && t.locale !== `ko` ? null : t.data;
                default:
                    return null
            }
        }
        var dr = {
            color: !0,
            date: !0,
            datetime: !0,
            "datetime-local": !0,
            email: !0,
            month: !0,
            number: !0,
            password: !0,
            range: !0,
            search: !0,
            tel: !0,
            text: !0,
            time: !0,
            url: !0,
            week: !0
        };

        function fr(e) {
            var t = e && e.nodeName && e.nodeName.toLowerCase();
            return t === `input` ? !!dr[e.type] : t === `textarea`
        }

        function pr(e, t, n, r) {
            pn ? mn ? mn.push(r) : mn = [r] : pn = r, t = Dd(t, `onChange`), 0 < t.length && (n = new jn(`onChange`, `change`, null, n, r), e.push({
                event: n,
                listeners: t
            }))
        }
        var mr = null,
            hr = null;

        function gr(e) {
            bd(e, 0)
        }

        function _r(e) {
            if (Gt(Dt(e))) return e
        }

        function vr(e, t) {
            if (e === `change`) return t
        }
        var yr = !1;
        if (yn) {
            var br;
            if (yn) {
                var xr = `oninput` in document;
                if (!xr) {
                    var Sr = document.createElement(`div`);
                    Sr.setAttribute(`oninput`, `return;`), xr = typeof Sr.oninput == `function`
                }
                br = xr
            } else br = !1;
            yr = br && (!document.documentMode || 9 < document.documentMode)
        }

        function Cr() {
            mr && (mr.detachEvent(`onpropertychange`, wr), hr = mr = null)
        }

        function wr(e) {
            if (e.propertyName === `value` && _r(hr)) {
                var t = [];
                pr(t, hr, e, fn(e)), _n(gr, t)
            }
        }

        function Tr(e, t, n) {
            e === `focusin` ? (Cr(), mr = t, hr = n, mr.attachEvent(`onpropertychange`, wr)) : e === `focusout` && Cr()
        }

        function Er(e) {
            if (e === `selectionchange` || e === `keyup` || e === `keydown`) return _r(hr)
        }

        function Dr(e, t) {
            if (e === `click`) return _r(t)
        }

        function Or(e, t) {
            if (e === `input` || e === `change`) return _r(t)
        }

        function kr(e, t) {
            return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t
        }
        var Ar = typeof Object.is == `function` ? Object.is : kr;

        function jr(e, t) {
            if (Ar(e, t)) return !0;
            if (typeof e != `object` || !e || typeof t != `object` || !t) return !1;
            var n = Object.keys(e),
                r = Object.keys(t);
            if (n.length !== r.length) return !1;
            for (r = 0; r < n.length; r++) {
                var i = n[r];
                if (!je.call(t, i) || !Ar(e[i], t[i])) return !1
            }
            return !0
        }

        function Mr(e) {
            for (; e && e.firstChild;) e = e.firstChild;
            return e
        }

        function Nr(e, t) {
            var n = Mr(e);
            e = 0;
            for (var r; n;) {
                if (n.nodeType === 3) {
                    if (r = e + n.textContent.length, e <= t && r >= t) return {
                        node: n,
                        offset: t - e
                    };
                    e = r
                }
                a: {
                    for (; n;) {
                        if (n.nextSibling) {
                            n = n.nextSibling;
                            break a
                        }
                        n = n.parentNode
                    }
                    n = void 0
                }
                n = Mr(n)
            }
        }

        function Pr(e, t) {
            return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? Pr(e, t.parentNode) : `contains` in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
        }

        function Fr(e) {
            e = e != null && e.ownerDocument != null && e.ownerDocument.defaultView != null ? e.ownerDocument.defaultView : window;
            for (var t = Kt(e.document); t instanceof e.HTMLIFrameElement;) {
                try {
                    var n = typeof t.contentWindow.location.href == `string`
                } catch {
                    n = !1
                }
                if (n) e = t.contentWindow;
                else break;
                t = Kt(e.document)
            }
            return t
        }

        function Ir(e) {
            var t = e && e.nodeName && e.nodeName.toLowerCase();
            return t && (t === `input` && (e.type === `text` || e.type === `search` || e.type === `tel` || e.type === `url` || e.type === `password`) || t === `textarea` || e.contentEditable === `true`)
        }
        var Lr = yn && `documentMode` in document && 11 >= document.documentMode,
            Rr = null,
            zr = null,
            Br = null,
            Vr = !1;

        function Hr(e, t, n) {
            var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
            Vr || Rr == null || Rr !== Kt(r) || (r = Rr, `selectionStart` in r && Ir(r) ? r = {
                start: r.selectionStart,
                end: r.selectionEnd
            } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
                anchorNode: r.anchorNode,
                anchorOffset: r.anchorOffset,
                focusNode: r.focusNode,
                focusOffset: r.focusOffset
            }), Br && jr(Br, r) || (Br = r, r = Dd(zr, `onSelect`), 0 < r.length && (t = new jn(`onSelect`, `select`, null, t, n), e.push({
                event: t,
                listeners: r
            }), t.target = Rr)))
        }

        function Ur(e, t) {
            var n = {};
            return n[e.toLowerCase()] = t.toLowerCase(), n[`Webkit` + e] = `webkit` + t, n[`Moz` + e] = `moz` + t, n
        }
        var Wr = {
                animationend: Ur(`Animation`, `AnimationEnd`),
                animationiteration: Ur(`Animation`, `AnimationIteration`),
                animationstart: Ur(`Animation`, `AnimationStart`),
                transitionrun: Ur(`Transition`, `TransitionRun`),
                transitionstart: Ur(`Transition`, `TransitionStart`),
                transitioncancel: Ur(`Transition`, `TransitionCancel`),
                transitionend: Ur(`Transition`, `TransitionEnd`)
            },
            Gr = {},
            Kr = {};
        yn && (Kr = document.createElement(`div`).style, `AnimationEvent` in window || (delete Wr.animationend.animation, delete Wr.animationiteration.animation, delete Wr.animationstart.animation), `TransitionEvent` in window || delete Wr.transitionend.transition);

        function qr(e) {
            if (Gr[e]) return Gr[e];
            if (!Wr[e]) return e;
            var t = Wr[e],
                n;
            for (n in t)
                if (t.hasOwnProperty(n) && n in Kr) return Gr[e] = t[n];
            return e
        }
        var Jr = qr(`animationend`),
            Yr = qr(`animationiteration`),
            Xr = qr(`animationstart`),
            Zr = qr(`transitionrun`),
            Qr = qr(`transitionstart`),
            $r = qr(`transitioncancel`),
            ei = qr(`transitionend`),
            ti = new Map,
            ni = `abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);
        ni.push(`scrollEnd`);

        function ri(e, t) {
            ti.set(e, t), Mt(t, [e])
        }
        var ii = typeof reportError == `function` ? reportError : function(e) {
                if (typeof window == `object` && typeof window.ErrorEvent == `function`) {
                    var t = new window.ErrorEvent(`error`, {
                        bubbles: !0,
                        cancelable: !0,
                        message: typeof e == `object` && e && typeof e.message == `string` ? String(e.message) : String(e),
                        error: e
                    });
                    if (!window.dispatchEvent(t)) return
                } else if (typeof process == `object` && typeof process.emit == `function`) {
                    process.emit(`uncaughtException`, e);
                    return
                }
                console.error(e)
            },
            ai = [],
            oi = 0,
            si = 0;

        function ci() {
            for (var e = oi, t = si = oi = 0; t < e;) {
                var n = ai[t];
                ai[t++] = null;
                var r = ai[t];
                ai[t++] = null;
                var i = ai[t];
                ai[t++] = null;
                var a = ai[t];
                if (ai[t++] = null, r !== null && i !== null) {
                    var o = r.pending;
                    o === null ? i.next = i : (i.next = o.next, o.next = i), r.pending = i
                }
                a !== 0 && fi(n, i, a)
            }
        }

        function li(e, t, n, r) {
            ai[oi++] = e, ai[oi++] = t, ai[oi++] = n, ai[oi++] = r, si |= r, e.lanes |= r, e = e.alternate, e !== null && (e.lanes |= r)
        }

        function ui(e, t, n, r) {
            return li(e, t, n, r), pi(e)
        }

        function di(e, t) {
            return li(e, null, null, t), pi(e)
        }

        function fi(e, t, n) {
            e.lanes |= n;
            var r = e.alternate;
            r !== null && (r.lanes |= n);
            for (var i = !1, a = e.return; a !== null;) a.childLanes |= n, r = a.alternate, r !== null && (r.childLanes |= n), a.tag === 22 && (e = a.stateNode, e === null || e._visibility & 1 || (i = !0)), e = a, a = a.return;
            return e.tag === 3 ? (a = e.stateNode, i && t !== null && (i = 31 - Je(n), e = a.hiddenUpdates, r = e[i], r === null ? e[i] = [t] : r.push(t), t.lane = n | 536870912), a) : null
        }

        function pi(e) {
            if (50 < fu) throw fu = 0, pu = null, Error(i(185));
            for (var t = e.return; t !== null;) e = t, t = e.return;
            return e.tag === 3 ? e.stateNode : null
        }
        var mi = {};

        function hi(e, t, n, r) {
            this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
        }

        function gi(e, t, n, r) {
            return new hi(e, t, n, r)
        }

        function _i(e) {
            return e = e.prototype, !(!e || !e.isReactComponent)
        }

        function vi(e, t) {
            var n = e.alternate;
            return n === null ? (n = gi(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 65011712, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
                lanes: t.lanes,
                firstContext: t.firstContext
            }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n.refCleanup = e.refCleanup, n
        }

        function yi(e, t) {
            e.flags &= 65011714;
            var n = e.alternate;
            return n === null ? (e.childLanes = 0, e.lanes = t, e.child = null, e.subtreeFlags = 0, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null) : (e.childLanes = n.childLanes, e.lanes = n.lanes, e.child = n.child, e.subtreeFlags = 0, e.deletions = null, e.memoizedProps = n.memoizedProps, e.memoizedState = n.memoizedState, e.updateQueue = n.updateQueue, e.type = n.type, t = n.dependencies, e.dependencies = t === null ? null : {
                lanes: t.lanes,
                firstContext: t.firstContext
            }), e
        }

        function bi(e, t, n, r, a, o) {
            var s = 0;
            if (r = e, typeof e == `function`) _i(e) && (s = 1);
            else if (typeof e == `string`) s = Wf(e, n, ge.current) ? 26 : e === `html` || e === `head` || e === `body` ? 27 : 5;
            else a: switch (e) {
                case ae:
                    return e = gi(31, n, t, a), e.elementType = ae, e.lanes = o, e;
                case y:
                    return xi(n.children, a, o, t);
                case b:
                    s = 8, a |= 24;
                    break;
                case x:
                    return e = gi(12, n, t, a | 2), e.elementType = x, e.lanes = o, e;
                case te:
                    return e = gi(13, n, t, a), e.elementType = te, e.lanes = o, e;
                case ne:
                    return e = gi(19, n, t, a), e.elementType = ne, e.lanes = o, e;
                default:
                    if (typeof e == `object` && e) switch (e.$$typeof) {
                        case S:
                            s = 10;
                            break a;
                        case ee:
                            s = 9;
                            break a;
                        case C:
                            s = 11;
                            break a;
                        case re:
                            s = 14;
                            break a;
                        case ie:
                            s = 16, r = null;
                            break a
                    }
                    s = 29, n = Error(i(130, e === null ? `null` : typeof e, ``)), r = null
            }
            return t = gi(s, n, t, a), t.elementType = e, t.type = r, t.lanes = o, t
        }

        function xi(e, t, n, r) {
            return e = gi(7, e, r, t), e.lanes = n, e
        }

        function Si(e, t, n) {
            return e = gi(6, e, null, t), e.lanes = n, e
        }

        function Ci(e) {
            var t = gi(18, null, null, 0);
            return t.stateNode = e, t
        }

        function wi(e, t, n) {
            return t = gi(4, e.children === null ? [] : e.children, e.key, t), t.lanes = n, t.stateNode = {
                containerInfo: e.containerInfo,
                pendingChildren: null,
                implementation: e.implementation
            }, t
        }
        var Ti = new WeakMap;

        function Ei(e, t) {
            if (typeof e == `object` && e) {
                var n = Ti.get(e);
                return n === void 0 ? (t = {
                    value: e,
                    source: t,
                    stack: Ae(t)
                }, Ti.set(e, t), t) : n
            }
            return {
                value: e,
                source: t,
                stack: Ae(t)
            }
        }
        var Di = [],
            Oi = 0,
            ki = null,
            Ai = 0,
            ji = [],
            Mi = 0,
            Ni = null,
            Pi = 1,
            Fi = ``;

        function Ii(e, t) {
            Di[Oi++] = Ai, Di[Oi++] = ki, ki = e, Ai = t
        }

        function Li(e, t, n) {
            ji[Mi++] = Pi, ji[Mi++] = Fi, ji[Mi++] = Ni, Ni = e;
            var r = Pi;
            e = Fi;
            var i = 32 - Je(r) - 1;
            r &= ~(1 << i), n += 1;
            var a = 32 - Je(t) + i;
            if (30 < a) {
                var o = i - i % 5;
                a = (r & (1 << o) - 1).toString(32), r >>= o, i -= o, Pi = 1 << 32 - Je(t) + i | n << i | r, Fi = a + e
            } else Pi = 1 << a | n << i | r, Fi = e
        }

        function Ri(e) {
            e.return !== null && (Ii(e, 1), Li(e, 1, 0))
        }

        function zi(e) {
            for (; e === ki;) ki = Di[--Oi], Di[Oi] = null, Ai = Di[--Oi], Di[Oi] = null;
            for (; e === Ni;) Ni = ji[--Mi], ji[Mi] = null, Fi = ji[--Mi], ji[Mi] = null, Pi = ji[--Mi], ji[Mi] = null
        }

        function Bi(e, t) {
            ji[Mi++] = Pi, ji[Mi++] = Fi, ji[Mi++] = Ni, Pi = t.id, Fi = t.overflow, Ni = e
        }
        var Vi = null,
            M = null,
            N = !1,
            Hi = null,
            Ui = !1,
            Wi = Error(i(519));

        function Gi(e) {
            throw Zi(Ei(Error(i(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? `text` : `HTML`, ``)), e)), Wi
        }

        function Ki(e) {
            var t = e.stateNode,
                n = e.type,
                r = e.memoizedProps;
            switch (t[_t] = e, t[k] = r, n) {
                case `dialog`:
                    Q(`cancel`, t), Q(`close`, t);
                    break;
                case `iframe`:
                case `object`:
                case `embed`:
                    Q(`load`, t);
                    break;
                case `video`:
                case `audio`:
                    for (n = 0; n < vd.length; n++) Q(vd[n], t);
                    break;
                case `source`:
                    Q(`error`, t);
                    break;
                case `img`:
                case `image`:
                case `link`:
                    Q(`error`, t), Q(`load`, t);
                    break;
                case `details`:
                    Q(`toggle`, t);
                    break;
                case `input`:
                    Q(`invalid`, t), Xt(t, r.value, r.defaultValue, r.checked, r.defaultChecked, r.type, r.name, !0);
                    break;
                case `select`:
                    Q(`invalid`, t);
                    break;
                case `textarea`:
                    Q(`invalid`, t), en(t, r.value, r.defaultValue, r.children)
            }
            n = r.children, typeof n != `string` && typeof n != `number` && typeof n != `bigint` || t.textContent === `` + n || !0 === r.suppressHydrationWarning || Nd(t.textContent, n) ? (r.popover != null && (Q(`beforetoggle`, t), Q(`toggle`, t)), r.onScroll != null && Q(`scroll`, t), r.onScrollEnd != null && Q(`scrollend`, t), r.onClick != null && (t.onclick = un), t = !0) : t = !1, t || Gi(e, !0)
        }

        function qi(e) {
            for (Vi = e.return; Vi;) switch (Vi.tag) {
                case 5:
                case 31:
                case 13:
                    Ui = !1;
                    return;
                case 27:
                case 3:
                    Ui = !0;
                    return;
                default:
                    Vi = Vi.return
            }
        }

        function Ji(e) {
            if (e !== Vi) return !1;
            if (!N) return qi(e), N = !0, !1;
            var t = e.tag,
                n;
            if ((n = t !== 3 && t !== 27) && ((n = t === 5) && (n = e.type, n = !(n !== `form` && n !== `button`) || Wd(e.type, e.memoizedProps)), n = !n), n && M && Gi(e), qi(e), t === 13) {
                if (e = e.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(i(317));
                M = df(e)
            } else if (t === 31) {
                if (e = e.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(i(317));
                M = df(e)
            } else t === 27 ? (t = M, Qd(e.type) ? (e = uf, uf = null, M = e) : M = t) : M = Vi ? lf(e.stateNode.nextSibling) : null;
            return !0
        }

        function Yi() {
            M = Vi = null, N = !1
        }

        function Xi() {
            var e = Hi;
            return e !== null && (Ql === null ? Ql = e : Ql.push.apply(Ql, e), Hi = null), e
        }

        function Zi(e) {
            Hi === null ? Hi = [e] : Hi.push(e)
        }
        var Qi = he(null),
            $i = null,
            ea = null;

        function ta(e, t, n) {
            O(Qi, t._currentValue), t._currentValue = n
        }

        function na(e) {
            e._currentValue = Qi.current, D(Qi)
        }

        function ra(e, t, n) {
            for (; e !== null;) {
                var r = e.alternate;
                if ((e.childLanes & t) === t ? r !== null && (r.childLanes & t) !== t && (r.childLanes |= t) : (e.childLanes |= t, r !== null && (r.childLanes |= t)), e === n) break;
                e = e.return
            }
        }

        function ia(e, t, n, r) {
            var a = e.child;
            for (a !== null && (a.return = e); a !== null;) {
                var o = a.dependencies;
                if (o !== null) {
                    var s = a.child;
                    o = o.firstContext;
                    a: for (; o !== null;) {
                        var c = o;
                        o = a;
                        for (var l = 0; l < t.length; l++)
                            if (c.context === t[l]) {
                                o.lanes |= n, c = o.alternate, c !== null && (c.lanes |= n), ra(o.return, n, e), r || (s = null);
                                break a
                            }
                        o = c.next
                    }
                } else if (a.tag === 18) {
                    if (s = a.return, s === null) throw Error(i(341));
                    s.lanes |= n, o = s.alternate, o !== null && (o.lanes |= n), ra(s, n, e), s = null
                } else s = a.child;
                if (s !== null) s.return = a;
                else
                    for (s = a; s !== null;) {
                        if (s === e) {
                            s = null;
                            break
                        }
                        if (a = s.sibling, a !== null) {
                            a.return = s.return, s = a;
                            break
                        }
                        s = s.return
                    }
                a = s
            }
        }

        function aa(e, t, n, r) {
            e = null;
            for (var a = t, o = !1; a !== null;) {
                if (!o) {
                    if (a.flags & 524288) o = !0;
                    else if (a.flags & 262144) break
                }
                if (a.tag === 10) {
                    var s = a.alternate;
                    if (s === null) throw Error(i(387));
                    if (s = s.memoizedProps, s !== null) {
                        var c = a.type;
                        Ar(a.pendingProps.value, s.value) || (e === null ? e = [c] : e.push(c))
                    }
                } else if (a === ye.current) {
                    if (s = a.alternate, s === null) throw Error(i(387));
                    s.memoizedState.memoizedState !== a.memoizedState.memoizedState && (e === null ? e = [$f] : e.push($f))
                }
                a = a.return
            }
            e !== null && ia(t, e, n, r), t.flags |= 262144
        }

        function oa(e) {
            for (e = e.firstContext; e !== null;) {
                if (!Ar(e.context._currentValue, e.memoizedValue)) return !0;
                e = e.next
            }
            return !1
        }

        function sa(e) {
            $i = e, ea = null, e = e.dependencies, e !== null && (e.firstContext = null)
        }

        function ca(e) {
            return ua($i, e)
        }

        function la(e, t) {
            return $i === null && sa(e), ua(e, t)
        }

        function ua(e, t) {
            var n = t._currentValue;
            if (t = {
                    context: t,
                    memoizedValue: n,
                    next: null
                }, ea === null) {
                if (e === null) throw Error(i(308));
                ea = t, e.dependencies = {
                    lanes: 0,
                    firstContext: t
                }, e.flags |= 524288
            } else ea = ea.next = t;
            return n
        }
        var da = typeof AbortController < `u` ? AbortController : function() {
                var e = [],
                    t = this.signal = {
                        aborted: !1,
                        addEventListener: function(t, n) {
                            e.push(n)
                        }
                    };
                this.abort = function() {
                    t.aborted = !0, e.forEach(function(e) {
                        return e()
                    })
                }
            },
            fa = t.unstable_scheduleCallback,
            pa = t.unstable_NormalPriority,
            ma = {
                $$typeof: S,
                Consumer: null,
                Provider: null,
                _currentValue: null,
                _currentValue2: null,
                _threadCount: 0
            };

        function ha() {
            return {
                controller: new da,
                data: new Map,
                refCount: 0
            }
        }

        function ga(e) {
            e.refCount--, e.refCount === 0 && fa(pa, function() {
                e.controller.abort()
            })
        }
        var _a = null,
            va = 0,
            ya = 0,
            ba = null;

        function xa(e, t) {
            if (_a === null) {
                var n = _a = [];
                va = 0, ya = fd(), ba = {
                    status: `pending`,
                    value: void 0,
                    then: function(e) {
                        n.push(e)
                    }
                }
            }
            return va++, t.then(Sa, Sa), t
        }

        function Sa() {
            if (--va === 0 && _a !== null) {
                ba !== null && (ba.status = `fulfilled`);
                var e = _a;
                _a = null, ya = 0, ba = null;
                for (var t = 0; t < e.length; t++)(0, e[t])()
            }
        }

        function Ca(e, t) {
            var n = [],
                r = {
                    status: `pending`,
                    value: null,
                    reason: null,
                    then: function(e) {
                        n.push(e)
                    }
                };
            return e.then(function() {
                r.status = `fulfilled`, r.value = t;
                for (var e = 0; e < n.length; e++)(0, n[e])(t)
            }, function(e) {
                for (r.status = `rejected`, r.reason = e, e = 0; e < n.length; e++)(0, n[e])(void 0)
            }), r
        }
        var wa = w.S;
        w.S = function(e, t) {
            tu = Ie(), typeof t == `object` && t && typeof t.then == `function` && xa(e, t), wa !== null && wa(e, t)
        };
        var Ta = he(null);

        function Ea() {
            var e = Ta.current;
            return e === null ? K.pooledCache : e
        }

        function Da(e, t) {
            t === null ? O(Ta, Ta.current) : O(Ta, t.pool)
        }

        function Oa() {
            var e = Ea();
            return e === null ? null : {
                parent: ma._currentValue,
                pool: e
            }
        }
        var ka = Error(i(460)),
            Aa = Error(i(474)),
            ja = Error(i(542)),
            Ma = {
                then: function() {}
            };

        function Na(e) {
            return e = e.status, e === `fulfilled` || e === `rejected`
        }

        function Pa(e, t, n) {
            switch (n = e[n], n === void 0 ? e.push(t) : n !== t && (t.then(un, un), t = n), t.status) {
                case `fulfilled`:
                    return t.value;
                case `rejected`:
                    throw e = t.reason, Ra(e), e;
                default:
                    if (typeof t.status == `string`) t.then(un, un);
                    else {
                        if (e = K, e !== null && 100 < e.shellSuspendCounter) throw Error(i(482));
                        e = t, e.status = `pending`, e.then(function(e) {
                            if (t.status === `pending`) {
                                var n = t;
                                n.status = `fulfilled`, n.value = e
                            }
                        }, function(e) {
                            if (t.status === `pending`) {
                                var n = t;
                                n.status = `rejected`, n.reason = e
                            }
                        })
                    }
                    switch (t.status) {
                        case `fulfilled`:
                            return t.value;
                        case `rejected`:
                            throw e = t.reason, Ra(e), e
                    }
                    throw Ia = t, ka
            }
        }

        function Fa(e) {
            try {
                var t = e._init;
                return t(e._payload)
            } catch (e) {
                throw typeof e == `object` && e && typeof e.then == `function` ? (Ia = e, ka) : e
            }
        }
        var Ia = null;

        function La() {
            if (Ia === null) throw Error(i(459));
            var e = Ia;
            return Ia = null, e
        }

        function Ra(e) {
            if (e === ka || e === ja) throw Error(i(483))
        }
        var za = null,
            Ba = 0;

        function Va(e) {
            var t = Ba;
            return Ba += 1, za === null && (za = []), Pa(za, e, t)
        }

        function Ha(e, t) {
            t = t.props.ref, e.ref = t === void 0 ? null : t
        }

        function Ua(e, t) {
            throw t.$$typeof === g ? Error(i(525)) : (e = Object.prototype.toString.call(t), Error(i(31, e === `[object Object]` ? `object with keys {` + Object.keys(t).join(`, `) + `}` : e)))
        }

        function Wa(e) {
            function t(t, n) {
                if (e) {
                    var r = t.deletions;
                    r === null ? (t.deletions = [n], t.flags |= 16) : r.push(n)
                }
            }

            function n(n, r) {
                if (!e) return null;
                for (; r !== null;) t(n, r), r = r.sibling;
                return null
            }

            function r(e) {
                for (var t = new Map; e !== null;) e.key === null ? t.set(e.index, e) : t.set(e.key, e), e = e.sibling;
                return t
            }

            function a(e, t) {
                return e = vi(e, t), e.index = 0, e.sibling = null, e
            }

            function o(t, n, r) {
                return t.index = r, e ? (r = t.alternate, r === null ? (t.flags |= 67108866, n) : (r = r.index, r < n ? (t.flags |= 67108866, n) : r)) : (t.flags |= 1048576, n)
            }

            function s(t) {
                return e && t.alternate === null && (t.flags |= 67108866), t
            }

            function c(e, t, n, r) {
                return t === null || t.tag !== 6 ? (t = Si(n, e.mode, r), t.return = e, t) : (t = a(t, n), t.return = e, t)
            }

            function l(e, t, n, r) {
                var i = n.type;
                return i === y ? d(e, t, n.props.children, r, n.key) : t !== null && (t.elementType === i || typeof i == `object` && i && i.$$typeof === ie && Fa(i) === t.type) ? (t = a(t, n.props), Ha(t, n), t.return = e, t) : (t = bi(n.type, n.key, n.props, null, e.mode, r), Ha(t, n), t.return = e, t)
            }

            function u(e, t, n, r) {
                return t === null || t.tag !== 4 || t.stateNode.containerInfo !== n.containerInfo || t.stateNode.implementation !== n.implementation ? (t = wi(n, e.mode, r), t.return = e, t) : (t = a(t, n.children || []), t.return = e, t)
            }

            function d(e, t, n, r, i) {
                return t === null || t.tag !== 7 ? (t = xi(n, e.mode, r, i), t.return = e, t) : (t = a(t, n), t.return = e, t)
            }

            function f(e, t, n) {
                if (typeof t == `string` && t !== `` || typeof t == `number` || typeof t == `bigint`) return t = Si(`` + t, e.mode, n), t.return = e, t;
                if (typeof t == `object` && t) {
                    switch (t.$$typeof) {
                        case _:
                            return n = bi(t.type, t.key, t.props, null, e.mode, n), Ha(n, t), n.return = e, n;
                        case v:
                            return t = wi(t, e.mode, n), t.return = e, t;
                        case ie:
                            return t = Fa(t), f(e, t, n)
                    }
                    if (de(t) || ce(t)) return t = xi(t, e.mode, n, null), t.return = e, t;
                    if (typeof t.then == `function`) return f(e, Va(t), n);
                    if (t.$$typeof === S) return f(e, la(e, t), n);
                    Ua(e, t)
                }
                return null
            }

            function p(e, t, n, r) {
                var i = t === null ? null : t.key;
                if (typeof n == `string` && n !== `` || typeof n == `number` || typeof n == `bigint`) return i === null ? c(e, t, `` + n, r) : null;
                if (typeof n == `object` && n) {
                    switch (n.$$typeof) {
                        case _:
                            return n.key === i ? l(e, t, n, r) : null;
                        case v:
                            return n.key === i ? u(e, t, n, r) : null;
                        case ie:
                            return n = Fa(n), p(e, t, n, r)
                    }
                    if (de(n) || ce(n)) return i === null ? d(e, t, n, r, null) : null;
                    if (typeof n.then == `function`) return p(e, t, Va(n), r);
                    if (n.$$typeof === S) return p(e, t, la(e, n), r);
                    Ua(e, n)
                }
                return null
            }

            function m(e, t, n, r, i) {
                if (typeof r == `string` && r !== `` || typeof r == `number` || typeof r == `bigint`) return e = e.get(n) || null, c(t, e, `` + r, i);
                if (typeof r == `object` && r) {
                    switch (r.$$typeof) {
                        case _:
                            return e = e.get(r.key === null ? n : r.key) || null, l(t, e, r, i);
                        case v:
                            return e = e.get(r.key === null ? n : r.key) || null, u(t, e, r, i);
                        case ie:
                            return r = Fa(r), m(e, t, n, r, i)
                    }
                    if (de(r) || ce(r)) return e = e.get(n) || null, d(t, e, r, i, null);
                    if (typeof r.then == `function`) return m(e, t, n, Va(r), i);
                    if (r.$$typeof === S) return m(e, t, n, la(t, r), i);
                    Ua(t, r)
                }
                return null
            }

            function h(i, a, s, c) {
                for (var l = null, u = null, d = a, h = a = 0, g = null; d !== null && h < s.length; h++) {
                    d.index > h ? (g = d, d = null) : g = d.sibling;
                    var _ = p(i, d, s[h], c);
                    if (_ === null) {
                        d === null && (d = g);
                        break
                    }
                    e && d && _.alternate === null && t(i, d), a = o(_, a, h), u === null ? l = _ : u.sibling = _, u = _, d = g
                }
                if (h === s.length) return n(i, d), N && Ii(i, h), l;
                if (d === null) {
                    for (; h < s.length; h++) d = f(i, s[h], c), d !== null && (a = o(d, a, h), u === null ? l = d : u.sibling = d, u = d);
                    return N && Ii(i, h), l
                }
                for (d = r(d); h < s.length; h++) g = m(d, i, h, s[h], c), g !== null && (e && g.alternate !== null && d.delete(g.key === null ? h : g.key), a = o(g, a, h), u === null ? l = g : u.sibling = g, u = g);
                return e && d.forEach(function(e) {
                    return t(i, e)
                }), N && Ii(i, h), l
            }

            function g(a, s, c, l) {
                if (c == null) throw Error(i(151));
                for (var u = null, d = null, h = s, g = s = 0, _ = null, v = c.next(); h !== null && !v.done; g++, v = c.next()) {
                    h.index > g ? (_ = h, h = null) : _ = h.sibling;
                    var y = p(a, h, v.value, l);
                    if (y === null) {
                        h === null && (h = _);
                        break
                    }
                    e && h && y.alternate === null && t(a, h), s = o(y, s, g), d === null ? u = y : d.sibling = y, d = y, h = _
                }
                if (v.done) return n(a, h), N && Ii(a, g), u;
                if (h === null) {
                    for (; !v.done; g++, v = c.next()) v = f(a, v.value, l), v !== null && (s = o(v, s, g), d === null ? u = v : d.sibling = v, d = v);
                    return N && Ii(a, g), u
                }
                for (h = r(h); !v.done; g++, v = c.next()) v = m(h, a, g, v.value, l), v !== null && (e && v.alternate !== null && h.delete(v.key === null ? g : v.key), s = o(v, s, g), d === null ? u = v : d.sibling = v, d = v);
                return e && h.forEach(function(e) {
                    return t(a, e)
                }), N && Ii(a, g), u
            }

            function b(e, r, o, c) {
                if (typeof o == `object` && o && o.type === y && o.key === null && (o = o.props.children), typeof o == `object` && o) {
                    switch (o.$$typeof) {
                        case _:
                            a: {
                                for (var l = o.key; r !== null;) {
                                    if (r.key === l) {
                                        if (l = o.type, l === y) {
                                            if (r.tag === 7) {
                                                n(e, r.sibling), c = a(r, o.props.children), c.return = e, e = c;
                                                break a
                                            }
                                        } else if (r.elementType === l || typeof l == `object` && l && l.$$typeof === ie && Fa(l) === r.type) {
                                            n(e, r.sibling), c = a(r, o.props), Ha(c, o), c.return = e, e = c;
                                            break a
                                        }
                                        n(e, r);
                                        break
                                    } else t(e, r);
                                    r = r.sibling
                                }
                                o.type === y ? (c = xi(o.props.children, e.mode, c, o.key), c.return = e, e = c) : (c = bi(o.type, o.key, o.props, null, e.mode, c), Ha(c, o), c.return = e, e = c)
                            }
                            return s(e);
                        case v:
                            a: {
                                for (l = o.key; r !== null;) {
                                    if (r.key === l)
                                        if (r.tag === 4 && r.stateNode.containerInfo === o.containerInfo && r.stateNode.implementation === o.implementation) {
                                            n(e, r.sibling), c = a(r, o.children || []), c.return = e, e = c;
                                            break a
                                        } else {
                                            n(e, r);
                                            break
                                        }
                                    else t(e, r);
                                    r = r.sibling
                                }
                                c = wi(o, e.mode, c),
                                c.return = e,
                                e = c
                            }
                            return s(e);
                        case ie:
                            return o = Fa(o), b(e, r, o, c)
                    }
                    if (de(o)) return h(e, r, o, c);
                    if (ce(o)) {
                        if (l = ce(o), typeof l != `function`) throw Error(i(150));
                        return o = l.call(o), g(e, r, o, c)
                    }
                    if (typeof o.then == `function`) return b(e, r, Va(o), c);
                    if (o.$$typeof === S) return b(e, r, la(e, o), c);
                    Ua(e, o)
                }
                return typeof o == `string` && o !== `` || typeof o == `number` || typeof o == `bigint` ? (o = `` + o, r !== null && r.tag === 6 ? (n(e, r.sibling), c = a(r, o), c.return = e, e = c) : (n(e, r), c = Si(o, e.mode, c), c.return = e, e = c), s(e)) : n(e, r)
            }
            return function(e, t, n, r) {
                try {
                    Ba = 0;
                    var i = b(e, t, n, r);
                    return za = null, i
                } catch (t) {
                    if (t === ka || t === ja) throw t;
                    var a = gi(29, t, null, e.mode);
                    return a.lanes = r, a.return = e, a
                }
            }
        }
        var Ga = Wa(!0),
            Ka = Wa(!1),
            qa = !1;

        function Ja(e) {
            e.updateQueue = {
                baseState: e.memoizedState,
                firstBaseUpdate: null,
                lastBaseUpdate: null,
                shared: {
                    pending: null,
                    lanes: 0,
                    hiddenCallbacks: null
                },
                callbacks: null
            }
        }

        function Ya(e, t) {
            e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
                baseState: e.baseState,
                firstBaseUpdate: e.firstBaseUpdate,
                lastBaseUpdate: e.lastBaseUpdate,
                shared: e.shared,
                callbacks: null
            })
        }

        function Xa(e) {
            return {
                lane: e,
                tag: 0,
                payload: null,
                callback: null,
                next: null
            }
        }

        function Za(e, t, n) {
            var r = e.updateQueue;
            if (r === null) return null;
            if (r = r.shared, G & 2) {
                var i = r.pending;
                return i === null ? t.next = t : (t.next = i.next, i.next = t), r.pending = t, t = pi(e), fi(e, null, n), t
            }
            return li(e, r, t, n), pi(e)
        }

        function Qa(e, t, n) {
            if (t = t.updateQueue, t !== null && (t = t.shared, n & 4194048)) {
                var r = t.lanes;
                r &= e.pendingLanes, n |= r, t.lanes = n, ut(e, n)
            }
        }

        function $a(e, t) {
            var n = e.updateQueue,
                r = e.alternate;
            if (r !== null && (r = r.updateQueue, n === r)) {
                var i = null,
                    a = null;
                if (n = n.firstBaseUpdate, n !== null) {
                    do {
                        var o = {
                            lane: n.lane,
                            tag: n.tag,
                            payload: n.payload,
                            callback: null,
                            next: null
                        };
                        a === null ? i = a = o : a = a.next = o, n = n.next
                    } while (n !== null);
                    a === null ? i = a = t : a = a.next = t
                } else i = a = t;
                n = {
                    baseState: r.baseState,
                    firstBaseUpdate: i,
                    lastBaseUpdate: a,
                    shared: r.shared,
                    callbacks: r.callbacks
                }, e.updateQueue = n;
                return
            }
            e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
        }
        var eo = !1;

        function to() {
            if (eo) {
                var e = ba;
                if (e !== null) throw e
            }
        }

        function no(e, t, n, r) {
            eo = !1;
            var i = e.updateQueue;
            qa = !1;
            var a = i.firstBaseUpdate,
                o = i.lastBaseUpdate,
                s = i.shared.pending;
            if (s !== null) {
                i.shared.pending = null;
                var c = s,
                    l = c.next;
                c.next = null, o === null ? a = l : o.next = l, o = c;
                var u = e.alternate;
                u !== null && (u = u.updateQueue, s = u.lastBaseUpdate, s !== o && (s === null ? u.firstBaseUpdate = l : s.next = l, u.lastBaseUpdate = c))
            }
            if (a !== null) {
                var d = i.baseState;
                o = 0, u = l = c = null, s = a;
                do {
                    var f = s.lane & -536870913,
                        p = f !== s.lane;
                    if (p ? (J & f) === f : (r & f) === f) {
                        f !== 0 && f === ya && (eo = !0), u !== null && (u = u.next = {
                            lane: 0,
                            tag: s.tag,
                            payload: s.payload,
                            callback: null,
                            next: null
                        });
                        a: {
                            var m = e,
                                g = s;f = t;
                            var _ = n;
                            switch (g.tag) {
                                case 1:
                                    if (m = g.payload, typeof m == `function`) {
                                        d = m.call(_, d, f);
                                        break a
                                    }
                                    d = m;
                                    break a;
                                case 3:
                                    m.flags = m.flags & -65537 | 128;
                                case 0:
                                    if (m = g.payload, f = typeof m == `function` ? m.call(_, d, f) : m, f == null) break a;
                                    d = h({}, d, f);
                                    break a;
                                case 2:
                                    qa = !0
                            }
                        }
                        f = s.callback, f !== null && (e.flags |= 64, p && (e.flags |= 8192), p = i.callbacks, p === null ? i.callbacks = [f] : p.push(f))
                    } else p = {
                        lane: f,
                        tag: s.tag,
                        payload: s.payload,
                        callback: s.callback,
                        next: null
                    }, u === null ? (l = u = p, c = d) : u = u.next = p, o |= f;
                    if (s = s.next, s === null) {
                        if (s = i.shared.pending, s === null) break;
                        p = s, s = p.next, p.next = null, i.lastBaseUpdate = p, i.shared.pending = null
                    }
                } while (1);
                u === null && (c = d), i.baseState = c, i.firstBaseUpdate = l, i.lastBaseUpdate = u, a === null && (i.shared.lanes = 0), Kl |= o, e.lanes = o, e.memoizedState = d
            }
        }

        function ro(e, t) {
            if (typeof e != `function`) throw Error(i(191, e));
            e.call(t)
        }

        function io(e, t) {
            var n = e.callbacks;
            if (n !== null)
                for (e.callbacks = null, e = 0; e < n.length; e++) ro(n[e], t)
        }
        var ao = he(null),
            oo = he(0);

        function so(e, t) {
            e = Gl, O(oo, e), O(ao, t), Gl = e | t.baseLanes
        }

        function co() {
            O(oo, Gl), O(ao, ao.current)
        }

        function lo() {
            Gl = oo.current, D(ao), D(oo)
        }
        var uo = he(null),
            fo = null;

        function po(e) {
            var t = e.alternate;
            O(_o, _o.current & 1), O(uo, e), fo === null && (t === null || ao.current !== null || t.memoizedState !== null) && (fo = e)
        }

        function mo(e) {
            O(_o, _o.current), O(uo, e), fo === null && (fo = e)
        }

        function ho(e) {
            e.tag === 22 ? (O(_o, _o.current), O(uo, e), fo === null && (fo = e)) : go(e)
        }

        function go() {
            O(_o, _o.current), O(uo, uo.current)
        }

        function P(e) {
            D(uo), fo === e && (fo = null), D(_o)
        }
        var _o = he(0);

        function vo(e) {
            for (var t = e; t !== null;) {
                if (t.tag === 13) {
                    var n = t.memoizedState;
                    if (n !== null && (n = n.dehydrated, n === null || of (n) || sf(n))) return t
                } else if (t.tag === 19 && (t.memoizedProps.revealOrder === `forwards` || t.memoizedProps.revealOrder === `backwards` || t.memoizedProps.revealOrder === `unstable_legacy-backwards` || t.memoizedProps.revealOrder === `together`)) {
                    if (t.flags & 128) return t
                } else if (t.child !== null) {
                    t.child.return = t, t = t.child;
                    continue
                }
                if (t === e) break;
                for (; t.sibling === null;) {
                    if (t.return === null || t.return === e) return null;
                    t = t.return
                }
                t.sibling.return = t.return, t = t.sibling
            }
            return null
        }
        var yo = 0,
            F = null,
            I = null,
            bo = null,
            xo = !1,
            So = !1,
            Co = !1,
            wo = 0,
            To = 0,
            Eo = null,
            Do = 0;

        function L() {
            throw Error(i(321))
        }

        function Oo(e, t) {
            if (t === null) return !1;
            for (var n = 0; n < t.length && n < e.length; n++)
                if (!Ar(e[n], t[n])) return !1;
            return !0
        }

        function ko(e, t, n, r, i, a) {
            return yo = a, F = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, w.H = e === null || e.memoizedState === null ? Hs : Us, Co = !1, a = n(r, i), Co = !1, So && (a = jo(t, n, r, i)), Ao(e), a
        }

        function Ao(e) {
            w.H = Vs;
            var t = I !== null && I.next !== null;
            if (yo = 0, bo = I = F = null, xo = !1, To = 0, Eo = null, t) throw Error(i(300));
            e === null || ac || (e = e.dependencies, e !== null && oa(e) && (ac = !0))
        }

        function jo(e, t, n, r) {
            F = e;
            var a = 0;
            do {
                if (So && (Eo = null), To = 0, So = !1, 25 <= a) throw Error(i(301));
                if (a += 1, bo = I = null, e.updateQueue != null) {
                    var o = e.updateQueue;
                    o.lastEffect = null, o.events = null, o.stores = null, o.memoCache != null && (o.memoCache.index = 0)
                }
                w.H = Ws, o = t(n, r)
            } while (So);
            return o
        }

        function Mo() {
            var e = w.H,
                t = e.useState()[0];
            return t = typeof t.then == `function` ? Ro(t) : t, e = e.useState()[0], (I === null ? null : I.memoizedState) !== e && (F.flags |= 1024), t
        }

        function No() {
            var e = wo !== 0;
            return wo = 0, e
        }

        function Po(e, t, n) {
            t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~n
        }

        function Fo(e) {
            if (xo) {
                for (e = e.memoizedState; e !== null;) {
                    var t = e.queue;
                    t !== null && (t.pending = null), e = e.next
                }
                xo = !1
            }
            yo = 0, bo = I = F = null, So = !1, To = wo = 0, Eo = null
        }

        function Io() {
            var e = {
                memoizedState: null,
                baseState: null,
                baseQueue: null,
                queue: null,
                next: null
            };
            return bo === null ? F.memoizedState = bo = e : bo = bo.next = e, bo
        }

        function R() {
            if (I === null) {
                var e = F.alternate;
                e = e === null ? null : e.memoizedState
            } else e = I.next;
            var t = bo === null ? F.memoizedState : bo.next;
            if (t !== null) bo = t, I = e;
            else {
                if (e === null) throw F.alternate === null ? Error(i(467)) : Error(i(310));
                I = e, e = {
                    memoizedState: I.memoizedState,
                    baseState: I.baseState,
                    baseQueue: I.baseQueue,
                    queue: I.queue,
                    next: null
                }, bo === null ? F.memoizedState = bo = e : bo = bo.next = e
            }
            return bo
        }

        function Lo() {
            return {
                lastEffect: null,
                events: null,
                stores: null,
                memoCache: null
            }
        }

        function Ro(e) {
            var t = To;
            return To += 1, Eo === null && (Eo = []), e = Pa(Eo, e, t), t = F, (bo === null ? t.memoizedState : bo.next) === null && (t = t.alternate, w.H = t === null || t.memoizedState === null ? Hs : Us), e
        }

        function zo(e) {
            if (typeof e == `object` && e) {
                if (typeof e.then == `function`) return Ro(e);
                if (e.$$typeof === S) return ca(e)
            }
            throw Error(i(438, String(e)))
        }

        function Bo(e) {
            var t = null,
                n = F.updateQueue;
            if (n !== null && (t = n.memoCache), t == null) {
                var r = F.alternate;
                r !== null && (r = r.updateQueue, r !== null && (r = r.memoCache, r != null && (t = {
                    data: r.data.map(function(e) {
                        return e.slice()
                    }),
                    index: 0
                })))
            }
            if (t ? ? = {
                    data: [],
                    index: 0
                }, n === null && (n = Lo(), F.updateQueue = n), n.memoCache = t, n = t.data[t.index], n === void 0)
                for (n = t.data[t.index] = Array(e), r = 0; r < e; r++) n[r] = oe;
            return t.index++, n
        }

        function Vo(e, t) {
            return typeof t == `function` ? t(e) : t
        }

        function Ho(e) {
            return Uo(R(), I, e)
        }

        function Uo(e, t, n) {
            var r = e.queue;
            if (r === null) throw Error(i(311));
            r.lastRenderedReducer = n;
            var a = e.baseQueue,
                o = r.pending;
            if (o !== null) {
                if (a !== null) {
                    var s = a.next;
                    a.next = o.next, o.next = s
                }
                t.baseQueue = a = o, r.pending = null
            }
            if (o = e.baseState, a === null) e.memoizedState = o;
            else {
                t = a.next;
                var c = s = null,
                    l = null,
                    u = t,
                    d = !1;
                do {
                    var f = u.lane & -536870913;
                    if (f === u.lane ? (yo & f) === f : (J & f) === f) {
                        var p = u.revertLane;
                        if (p === 0) l !== null && (l = l.next = {
                            lane: 0,
                            revertLane: 0,
                            gesture: null,
                            action: u.action,
                            hasEagerState: u.hasEagerState,
                            eagerState: u.eagerState,
                            next: null
                        }), f === ya && (d = !0);
                        else if ((yo & p) === p) {
                            u = u.next, p === ya && (d = !0);
                            continue
                        } else f = {
                            lane: 0,
                            revertLane: u.revertLane,
                            gesture: null,
                            action: u.action,
                            hasEagerState: u.hasEagerState,
                            eagerState: u.eagerState,
                            next: null
                        }, l === null ? (c = l = f, s = o) : l = l.next = f, F.lanes |= p, Kl |= p;
                        f = u.action, Co && n(o, f), o = u.hasEagerState ? u.eagerState : n(o, f)
                    } else p = {
                        lane: f,
                        revertLane: u.revertLane,
                        gesture: u.gesture,
                        action: u.action,
                        hasEagerState: u.hasEagerState,
                        eagerState: u.eagerState,
                        next: null
                    }, l === null ? (c = l = p, s = o) : l = l.next = p, F.lanes |= f, Kl |= f;
                    u = u.next
                } while (u !== null && u !== t);
                if (l === null ? s = o : l.next = c, !Ar(o, e.memoizedState) && (ac = !0, d && (n = ba, n !== null))) throw n;
                e.memoizedState = o, e.baseState = s, e.baseQueue = l, r.lastRenderedState = o
            }
            return a === null && (r.lanes = 0), [e.memoizedState, r.dispatch]
        }

        function Wo(e) {
            var t = R(),
                n = t.queue;
            if (n === null) throw Error(i(311));
            n.lastRenderedReducer = e;
            var r = n.dispatch,
                a = n.pending,
                o = t.memoizedState;
            if (a !== null) {
                n.pending = null;
                var s = a = a.next;
                do o = e(o, s.action), s = s.next; while (s !== a);
                Ar(o, t.memoizedState) || (ac = !0), t.memoizedState = o, t.baseQueue === null && (t.baseState = o), n.lastRenderedState = o
            }
            return [o, r]
        }

        function Go(e, t, n) {
            var r = F,
                a = R(),
                o = N;
            if (o) {
                if (n === void 0) throw Error(i(407));
                n = n()
            } else n = t();
            var s = !Ar((I || a).memoizedState, n);
            if (s && (a.memoizedState = n, ac = !0), a = a.queue, hs(Jo.bind(null, r, a, e), [e]), a.getSnapshot !== t || s || bo !== null && bo.memoizedState.tag & 1) {
                if (r.flags |= 2048, us(9, {
                        destroy: void 0
                    }, qo.bind(null, r, a, n, t), null), K === null) throw Error(i(349));
                o || yo & 127 || Ko(r, t, n)
            }
            return n
        }

        function Ko(e, t, n) {
            e.flags |= 16384, e = {
                getSnapshot: t,
                value: n
            }, t = F.updateQueue, t === null ? (t = Lo(), F.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e))
        }

        function qo(e, t, n, r) {
            t.value = n, t.getSnapshot = r, Yo(t) && Xo(e)
        }

        function Jo(e, t, n) {
            return n(function() {
                Yo(t) && Xo(e)
            })
        }

        function Yo(e) {
            var t = e.getSnapshot;
            e = e.value;
            try {
                var n = t();
                return !Ar(e, n)
            } catch {
                return !0
            }
        }

        function Xo(e) {
            var t = di(e, 2);
            t !== null && gu(t, e, 2)
        }

        function Zo(e) {
            var t = Io();
            if (typeof e == `function`) {
                var n = e;
                if (e = n(), Co) {
                    qe(!0);
                    try {
                        n()
                    } finally {
                        qe(!1)
                    }
                }
            }
            return t.memoizedState = t.baseState = e, t.queue = {
                pending: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: Vo,
                lastRenderedState: e
            }, t
        }

        function Qo(e, t, n, r) {
            return e.baseState = n, Uo(e, I, typeof r == `function` ? r : Vo)
        }

        function $o(e, t, n, r, a) {
            if (Rs(e)) throw Error(i(485));
            if (e = t.action, e !== null) {
                var o = {
                    payload: a,
                    action: e,
                    next: null,
                    isTransition: !0,
                    status: `pending`,
                    value: null,
                    reason: null,
                    listeners: [],
                    then: function(e) {
                        o.listeners.push(e)
                    }
                };
                w.T === null ? o.isTransition = !1 : n(!0), r(o), n = t.pending, n === null ? (o.next = t.pending = o, es(t, o)) : (o.next = n.next, t.pending = n.next = o)
            }
        }

        function es(e, t) {
            var n = t.action,
                r = t.payload,
                i = e.state;
            if (t.isTransition) {
                var a = w.T,
                    o = {};
                w.T = o;
                try {
                    var s = n(i, r),
                        c = w.S;
                    c !== null && c(o, s), ts(e, t, s)
                } catch (n) {
                    rs(e, t, n)
                } finally {
                    a !== null && o.types !== null && (a.types = o.types), w.T = a
                }
            } else try {
                a = n(i, r), ts(e, t, a)
            } catch (n) {
                rs(e, t, n)
            }
        }

        function ts(e, t, n) {
            typeof n == `object` && n && typeof n.then == `function` ? n.then(function(n) {
                ns(e, t, n)
            }, function(n) {
                return rs(e, t, n)
            }) : ns(e, t, n)
        }

        function ns(e, t, n) {
            t.status = `fulfilled`, t.value = n, is(t), e.state = n, t = e.pending, t !== null && (n = t.next, n === t ? e.pending = null : (n = n.next, t.next = n, es(e, n)))
        }

        function rs(e, t, n) {
            var r = e.pending;
            if (e.pending = null, r !== null) {
                r = r.next;
                do t.status = `rejected`, t.reason = n, is(t), t = t.next; while (t !== r)
            }
            e.action = null
        }

        function is(e) {
            e = e.listeners;
            for (var t = 0; t < e.length; t++)(0, e[t])()
        }

        function as(e, t) {
            return t
        }

        function os(e, t) {
            if (N) {
                var n = K.formState;
                if (n !== null) {
                    a: {
                        var r = F;
                        if (N) {
                            if (M) {
                                b: {
                                    for (var i = M, a = Ui; i.nodeType !== 8;) {
                                        if (!a) {
                                            i = null;
                                            break b
                                        }
                                        if (i = lf(i.nextSibling), i === null) {
                                            i = null;
                                            break b
                                        }
                                    }
                                    a = i.data,
                                    i = a === `F!` || a === `F` ? i : null
                                }
                                if (i) {
                                    M = lf(i.nextSibling), r = i.data === `F!`;
                                    break a
                                }
                            }
                            Gi(r)
                        }
                        r = !1
                    }
                    r && (t = n[0])
                }
            }
            return n = Io(), n.memoizedState = n.baseState = t, r = {
                pending: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: as,
                lastRenderedState: t
            }, n.queue = r, n = Fs.bind(null, F, r), r.dispatch = n, r = Zo(!1), a = Ls.bind(null, F, !1, r.queue), r = Io(), i = {
                state: t,
                dispatch: null,
                action: e,
                pending: null
            }, r.queue = i, n = $o.bind(null, F, i, a, n), i.dispatch = n, r.memoizedState = e, [t, n, !1]
        }

        function ss(e) {
            return cs(R(), I, e)
        }

        function cs(e, t, n) {
            if (t = Uo(e, t, as)[0], e = Ho(Vo)[0], typeof t == `object` && t && typeof t.then == `function`) try {
                var r = Ro(t)
            } catch (e) {
                throw e === ka ? ja : e
            } else r = t;
            t = R();
            var i = t.queue,
                a = i.dispatch;
            return n !== t.memoizedState && (F.flags |= 2048, us(9, {
                destroy: void 0
            }, ls.bind(null, i, n), null)), [r, a, e]
        }

        function ls(e, t) {
            e.action = t
        }

        function z(e) {
            var t = R(),
                n = I;
            if (n !== null) return cs(t, n, e);
            R(), t = t.memoizedState, n = R();
            var r = n.queue.dispatch;
            return n.memoizedState = e, [t, r, !1]
        }

        function us(e, t, n, r) {
            return e = {
                tag: e,
                create: n,
                deps: r,
                inst: t,
                next: null
            }, t = F.updateQueue, t === null && (t = Lo(), F.updateQueue = t), n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e), e
        }

        function ds() {
            return R().memoizedState
        }

        function fs(e, t, n, r) {
            var i = Io();
            F.flags |= e, i.memoizedState = us(1 | t, {
                destroy: void 0
            }, n, r === void 0 ? null : r)
        }

        function ps(e, t, n, r) {
            var i = R();
            r = r === void 0 ? null : r;
            var a = i.memoizedState.inst;
            I !== null && r !== null && Oo(r, I.memoizedState.deps) ? i.memoizedState = us(t, a, n, r) : (F.flags |= e, i.memoizedState = us(1 | t, a, n, r))
        }

        function ms(e, t) {
            fs(8390656, 8, e, t)
        }

        function hs(e, t) {
            ps(2048, 8, e, t)
        }

        function gs(e) {
            F.flags |= 4;
            var t = F.updateQueue;
            if (t === null) t = Lo(), F.updateQueue = t, t.events = [e];
            else {
                var n = t.events;
                n === null ? t.events = [e] : n.push(e)
            }
        }

        function B(e) {
            var t = R().memoizedState;
            return gs({
                    ref: t,
                    nextImpl: e
                }),
                function() {
                    if (G & 2) throw Error(i(440));
                    return t.impl.apply(void 0, arguments)
                }
        }

        function _s(e, t) {
            return ps(4, 2, e, t)
        }

        function vs(e, t) {
            return ps(4, 4, e, t)
        }

        function ys(e, t) {
            if (typeof t == `function`) {
                e = e();
                var n = t(e);
                return function() {
                    typeof n == `function` ? n() : t(null)
                }
            }
            if (t != null) return e = e(), t.current = e,
                function() {
                    t.current = null
                }
        }

        function bs(e, t, n) {
            n = n == null ? null : n.concat([e]), ps(4, 4, ys.bind(null, t, e), n)
        }

        function xs() {}

        function Ss(e, t) {
            var n = R();
            t = t === void 0 ? null : t;
            var r = n.memoizedState;
            return t !== null && Oo(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
        }

        function Cs(e, t) {
            var n = R();
            t = t === void 0 ? null : t;
            var r = n.memoizedState;
            if (t !== null && Oo(t, r[1])) return r[0];
            if (r = e(), Co) {
                qe(!0);
                try {
                    e()
                } finally {
                    qe(!1)
                }
            }
            return n.memoizedState = [r, t], r
        }

        function ws(e, t, n) {
            return n === void 0 || yo & 1073741824 && !(J & 261930) ? e.memoizedState = t : (e.memoizedState = n, e = hu(), F.lanes |= e, Kl |= e, n)
        }

        function Ts(e, t, n, r) {
            return Ar(n, t) ? n : ao.current === null ? !(yo & 42) || yo & 1073741824 && !(J & 261930) ? (ac = !0, e.memoizedState = n) : (e = hu(), F.lanes |= e, Kl |= e, t) : (e = ws(e, n, r), Ar(e, t) || (ac = !0), e)
        }

        function Es(e, t, n, r, i) {
            var a = E.p;
            E.p = a !== 0 && 8 > a ? a : 8;
            var o = w.T,
                s = {};
            w.T = s, Ls(e, !1, t, n);
            try {
                var c = i(),
                    l = w.S;
                l !== null && l(s, c), typeof c == `object` && c && typeof c.then == `function` ? Is(e, t, Ca(c, r), mu(e)) : Is(e, t, r, mu(e))
            } catch (n) {
                Is(e, t, {
                    then: function() {},
                    status: `rejected`,
                    reason: n
                }, mu())
            } finally {
                E.p = a, o !== null && s.types !== null && (o.types = s.types), w.T = o
            }
        }

        function Ds() {}

        function Os(e, t, n, r) {
            if (e.tag !== 5) throw Error(i(476));
            var a = ks(e).queue;
            Es(e, a, t, fe, n === null ? Ds : function() {
                return V(e), n(r)
            })
        }

        function ks(e) {
            var t = e.memoizedState;
            if (t !== null) return t;
            t = {
                memoizedState: fe,
                baseState: fe,
                baseQueue: null,
                queue: {
                    pending: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: Vo,
                    lastRenderedState: fe
                },
                next: null
            };
            var n = {};
            return t.next = {
                memoizedState: n,
                baseState: n,
                baseQueue: null,
                queue: {
                    pending: null,
                    lanes: 0,
                    dispatch: null,
                    lastRenderedReducer: Vo,
                    lastRenderedState: n
                },
                next: null
            }, e.memoizedState = t, e = e.alternate, e !== null && (e.memoizedState = t), t
        }

        function V(e) {
            var t = ks(e);
            t.next === null && (t = e.alternate.memoizedState), Is(e, t.next.queue, {}, mu())
        }

        function As() {
            return ca($f)
        }

        function js() {
            return R().memoizedState
        }

        function Ms() {
            return R().memoizedState
        }

        function Ns(e) {
            for (var t = e.return; t !== null;) {
                switch (t.tag) {
                    case 24:
                    case 3:
                        var n = mu();
                        e = Xa(n);
                        var r = Za(t, e, n);
                        r !== null && (gu(r, t, n), Qa(r, t, n)), t = {
                            cache: ha()
                        }, e.payload = t;
                        return
                }
                t = t.return
            }
        }

        function Ps(e, t, n) {
            var r = mu();
            n = {
                lane: r,
                revertLane: 0,
                gesture: null,
                action: n,
                hasEagerState: !1,
                eagerState: null,
                next: null
            }, Rs(e) ? zs(t, n) : (n = ui(e, t, n, r), n !== null && (gu(n, e, r), Bs(n, t, r)))
        }

        function Fs(e, t, n) {
            Is(e, t, n, mu())
        }

        function Is(e, t, n, r) {
            var i = {
                lane: r,
                revertLane: 0,
                gesture: null,
                action: n,
                hasEagerState: !1,
                eagerState: null,
                next: null
            };
            if (Rs(e)) zs(t, i);
            else {
                var a = e.alternate;
                if (e.lanes === 0 && (a === null || a.lanes === 0) && (a = t.lastRenderedReducer, a !== null)) try {
                    var o = t.lastRenderedState,
                        s = a(o, n);
                    if (i.hasEagerState = !0, i.eagerState = s, Ar(s, o)) return li(e, t, i, 0), K === null && ci(), !1
                } catch {}
                if (n = ui(e, t, i, r), n !== null) return gu(n, e, r), Bs(n, t, r), !0
            }
            return !1
        }

        function Ls(e, t, n, r) {
            if (r = {
                    lane: 2,
                    revertLane: fd(),
                    gesture: null,
                    action: r,
                    hasEagerState: !1,
                    eagerState: null,
                    next: null
                }, Rs(e)) {
                if (t) throw Error(i(479))
            } else t = ui(e, n, r, 2), t !== null && gu(t, e, 2)
        }

        function Rs(e) {
            var t = e.alternate;
            return e === F || t !== null && t === F
        }

        function zs(e, t) {
            So = xo = !0;
            var n = e.pending;
            n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
        }

        function Bs(e, t, n) {
            if (n & 4194048) {
                var r = t.lanes;
                r &= e.pendingLanes, n |= r, t.lanes = n, ut(e, n)
            }
        }
        var Vs = {
            readContext: ca,
            use: zo,
            useCallback: L,
            useContext: L,
            useEffect: L,
            useImperativeHandle: L,
            useLayoutEffect: L,
            useInsertionEffect: L,
            useMemo: L,
            useReducer: L,
            useRef: L,
            useState: L,
            useDebugValue: L,
            useDeferredValue: L,
            useTransition: L,
            useSyncExternalStore: L,
            useId: L,
            useHostTransitionStatus: L,
            useFormState: L,
            useActionState: L,
            useOptimistic: L,
            useMemoCache: L,
            useCacheRefresh: L
        };
        Vs.useEffectEvent = L;
        var Hs = {
                readContext: ca,
                use: zo,
                useCallback: function(e, t) {
                    return Io().memoizedState = [e, t === void 0 ? null : t], e
                },
                useContext: ca,
                useEffect: ms,
                useImperativeHandle: function(e, t, n) {
                    n = n == null ? null : n.concat([e]), fs(4194308, 4, ys.bind(null, t, e), n)
                },
                useLayoutEffect: function(e, t) {
                    return fs(4194308, 4, e, t)
                },
                useInsertionEffect: function(e, t) {
                    fs(4, 2, e, t)
                },
                useMemo: function(e, t) {
                    var n = Io();
                    t = t === void 0 ? null : t;
                    var r = e();
                    if (Co) {
                        qe(!0);
                        try {
                            e()
                        } finally {
                            qe(!1)
                        }
                    }
                    return n.memoizedState = [r, t], r
                },
                useReducer: function(e, t, n) {
                    var r = Io();
                    if (n !== void 0) {
                        var i = n(t);
                        if (Co) {
                            qe(!0);
                            try {
                                n(t)
                            } finally {
                                qe(!1)
                            }
                        }
                    } else i = t;
                    return r.memoizedState = r.baseState = i, e = {
                        pending: null,
                        lanes: 0,
                        dispatch: null,
                        lastRenderedReducer: e,
                        lastRenderedState: i
                    }, r.queue = e, e = e.dispatch = Ps.bind(null, F, e), [r.memoizedState, e]
                },
                useRef: function(e) {
                    var t = Io();
                    return e = {
                        current: e
                    }, t.memoizedState = e
                },
                useState: function(e) {
                    e = Zo(e);
                    var t = e.queue,
                        n = Fs.bind(null, F, t);
                    return t.dispatch = n, [e.memoizedState, n]
                },
                useDebugValue: xs,
                useDeferredValue: function(e, t) {
                    return ws(Io(), e, t)
                },
                useTransition: function() {
                    var e = Zo(!1);
                    return e = Es.bind(null, F, e.queue, !0, !1), Io().memoizedState = e, [!1, e]
                },
                useSyncExternalStore: function(e, t, n) {
                    var r = F,
                        a = Io();
                    if (N) {
                        if (n === void 0) throw Error(i(407));
                        n = n()
                    } else {
                        if (n = t(), K === null) throw Error(i(349));
                        J & 127 || Ko(r, t, n)
                    }
                    a.memoizedState = n;
                    var o = {
                        value: n,
                        getSnapshot: t
                    };
                    return a.queue = o, ms(Jo.bind(null, r, o, e), [e]), r.flags |= 2048, us(9, {
                        destroy: void 0
                    }, qo.bind(null, r, o, n, t), null), n
                },
                useId: function() {
                    var e = Io(),
                        t = K.identifierPrefix;
                    if (N) {
                        var n = Fi,
                            r = Pi;
                        n = (r & ~(1 << 32 - Je(r) - 1)).toString(32) + n, t = `_` + t + `R_` + n, n = wo++, 0 < n && (t += `H` + n.toString(32)), t += `_`
                    } else n = Do++, t = `_` + t + `r_` + n.toString(32) + `_`;
                    return e.memoizedState = t
                },
                useHostTransitionStatus: As,
                useFormState: os,
                useActionState: os,
                useOptimistic: function(e) {
                    var t = Io();
                    t.memoizedState = t.baseState = e;
                    var n = {
                        pending: null,
                        lanes: 0,
                        dispatch: null,
                        lastRenderedReducer: null,
                        lastRenderedState: null
                    };
                    return t.queue = n, t = Ls.bind(null, F, !0, n), n.dispatch = t, [e, t]
                },
                useMemoCache: Bo,
                useCacheRefresh: function() {
                    return Io().memoizedState = Ns.bind(null, F)
                },
                useEffectEvent: function(e) {
                    var t = Io(),
                        n = {
                            impl: e
                        };
                    return t.memoizedState = n,
                        function() {
                            if (G & 2) throw Error(i(440));
                            return n.impl.apply(void 0, arguments)
                        }
                }
            },
            Us = {
                readContext: ca,
                use: zo,
                useCallback: Ss,
                useContext: ca,
                useEffect: hs,
                useImperativeHandle: bs,
                useInsertionEffect: _s,
                useLayoutEffect: vs,
                useMemo: Cs,
                useReducer: Ho,
                useRef: ds,
                useState: function() {
                    return Ho(Vo)
                },
                useDebugValue: xs,
                useDeferredValue: function(e, t) {
                    return Ts(R(), I.memoizedState, e, t)
                },
                useTransition: function() {
                    var e = Ho(Vo)[0],
                        t = R().memoizedState;
                    return [typeof e == `boolean` ? e : Ro(e), t]
                },
                useSyncExternalStore: Go,
                useId: js,
                useHostTransitionStatus: As,
                useFormState: ss,
                useActionState: ss,
                useOptimistic: function(e, t) {
                    return Qo(R(), I, e, t)
                },
                useMemoCache: Bo,
                useCacheRefresh: Ms
            };
        Us.useEffectEvent = B;
        var Ws = {
            readContext: ca,
            use: zo,
            useCallback: Ss,
            useContext: ca,
            useEffect: hs,
            useImperativeHandle: bs,
            useInsertionEffect: _s,
            useLayoutEffect: vs,
            useMemo: Cs,
            useReducer: Wo,
            useRef: ds,
            useState: function() {
                return Wo(Vo)
            },
            useDebugValue: xs,
            useDeferredValue: function(e, t) {
                var n = R();
                return I === null ? ws(n, e, t) : Ts(n, I.memoizedState, e, t)
            },
            useTransition: function() {
                var e = Wo(Vo)[0],
                    t = R().memoizedState;
                return [typeof e == `boolean` ? e : Ro(e), t]
            },
            useSyncExternalStore: Go,
            useId: js,
            useHostTransitionStatus: As,
            useFormState: z,
            useActionState: z,
            useOptimistic: function(e, t) {
                var n = R();
                return I === null ? (n.baseState = e, [e, n.queue.dispatch]) : Qo(n, I, e, t)
            },
            useMemoCache: Bo,
            useCacheRefresh: Ms
        };
        Ws.useEffectEvent = B;

        function Gs(e, t, n, r) {
            t = e.memoizedState, n = n(r, t), n = n == null ? t : h({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n)
        }
        var Ks = {
            enqueueSetState: function(e, t, n) {
                e = e._reactInternals;
                var r = mu(),
                    i = Xa(r);
                i.payload = t, n != null && (i.callback = n), t = Za(e, i, r), t !== null && (gu(t, e, r), Qa(t, e, r))
            },
            enqueueReplaceState: function(e, t, n) {
                e = e._reactInternals;
                var r = mu(),
                    i = Xa(r);
                i.tag = 1, i.payload = t, n != null && (i.callback = n), t = Za(e, i, r), t !== null && (gu(t, e, r), Qa(t, e, r))
            },
            enqueueForceUpdate: function(e, t) {
                e = e._reactInternals;
                var n = mu(),
                    r = Xa(n);
                r.tag = 2, t != null && (r.callback = t), t = Za(e, r, n), t !== null && (gu(t, e, n), Qa(t, e, n))
            }
        };

        function qs(e, t, n, r, i, a, o) {
            return e = e.stateNode, typeof e.shouldComponentUpdate == `function` ? e.shouldComponentUpdate(r, a, o) : t.prototype && t.prototype.isPureReactComponent ? !jr(n, r) || !jr(i, a) : !0
        }

        function Js(e, t, n, r) {
            e = t.state, typeof t.componentWillReceiveProps == `function` && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == `function` && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Ks.enqueueReplaceState(t, t.state, null)
        }

        function Ys(e, t) {
            var n = t;
            if (`ref` in t)
                for (var r in n = {}, t) r !== `ref` && (n[r] = t[r]);
            if (e = e.defaultProps)
                for (var i in n === t && (n = h({}, n)), e) n[i] === void 0 && (n[i] = e[i]);
            return n
        }

        function Xs(e) {
            ii(e)
        }

        function Zs(e) {
            console.error(e)
        }

        function Qs(e) {
            ii(e)
        }

        function H(e, t) {
            try {
                var n = e.onUncaughtError;
                n(t.value, {
                    componentStack: t.stack
                })
            } catch (e) {
                setTimeout(function() {
                    throw e
                })
            }
        }

        function $s(e, t, n) {
            try {
                var r = e.onCaughtError;
                r(n.value, {
                    componentStack: n.stack,
                    errorBoundary: t.tag === 1 ? t.stateNode : null
                })
            } catch (e) {
                setTimeout(function() {
                    throw e
                })
            }
        }

        function ec(e, t, n) {
            return n = Xa(n), n.tag = 3, n.payload = {
                element: null
            }, n.callback = function() {
                H(e, t)
            }, n
        }

        function tc(e) {
            return e = Xa(e), e.tag = 3, e
        }

        function nc(e, t, n, r) {
            var i = n.type.getDerivedStateFromError;
            if (typeof i == `function`) {
                var a = r.value;
                e.payload = function() {
                    return i(a)
                }, e.callback = function() {
                    $s(t, n, r)
                }
            }
            var o = n.stateNode;
            o !== null && typeof o.componentDidCatch == `function` && (e.callback = function() {
                $s(t, n, r), typeof i != `function` && (iu === null ? iu = new Set([this]) : iu.add(this));
                var e = r.stack;
                this.componentDidCatch(r.value, {
                    componentStack: e === null ? `` : e
                })
            })
        }

        function rc(e, t, n, r, a) {
            if (n.flags |= 32768, typeof r == `object` && r && typeof r.then == `function`) {
                if (t = n.alternate, t !== null && aa(t, n, a, !0), n = uo.current, n !== null) {
                    switch (n.tag) {
                        case 31:
                        case 13:
                            return fo === null ? Ou() : n.alternate === null && X === 0 && (X = 3), n.flags &= -257, n.flags |= 65536, n.lanes = a, r === Ma ? n.flags |= 16384 : (t = n.updateQueue, t === null ? n.updateQueue = new Set([r]) : t.add(r), Ku(e, r, a)), !1;
                        case 22:
                            return n.flags |= 65536, r === Ma ? n.flags |= 16384 : (t = n.updateQueue, t === null ? (t = {
                                transitions: null,
                                markerInstances: null,
                                retryQueue: new Set([r])
                            }, n.updateQueue = t) : (n = t.retryQueue, n === null ? t.retryQueue = new Set([r]) : n.add(r)), Ku(e, r, a)), !1
                    }
                    throw Error(i(435, n.tag))
                }
                return Ku(e, r, a), Ou(), !1
            }
            if (N) return t = uo.current, t === null ? (r !== Wi && (t = Error(i(423), {
                cause: r
            }), Zi(Ei(t, n))), e = e.current.alternate, e.flags |= 65536, a &= -a, e.lanes |= a, r = Ei(r, n), a = ec(e.stateNode, r, a), $a(e, a), X !== 4 && (X = 2)) : (!(t.flags & 65536) && (t.flags |= 256), t.flags |= 65536, t.lanes = a, r !== Wi && (e = Error(i(422), {
                cause: r
            }), Zi(Ei(e, n)))), !1;
            var o = Error(i(520), {
                cause: r
            });
            if (o = Ei(o, n), Zl === null ? Zl = [o] : Zl.push(o), X !== 4 && (X = 2), t === null) return !0;
            r = Ei(r, n), n = t;
            do {
                switch (n.tag) {
                    case 3:
                        return n.flags |= 65536, e = a & -a, n.lanes |= e, e = ec(n.stateNode, r, e), $a(n, e), !1;
                    case 1:
                        if (t = n.type, o = n.stateNode, !(n.flags & 128) && (typeof t.getDerivedStateFromError == `function` || o !== null && typeof o.componentDidCatch == `function` && (iu === null || !iu.has(o)))) return n.flags |= 65536, a &= -a, n.lanes |= a, a = tc(a), nc(a, e, n, r), $a(n, a), !1
                }
                n = n.return
            } while (n !== null);
            return !1
        }
        var ic = Error(i(461)),
            ac = !1;

        function oc(e, t, n, r) {
            t.child = e === null ? Ka(t, null, n, r) : Ga(t, e.child, n, r)
        }

        function sc(e, t, n, r, i) {
            n = n.render;
            var a = t.ref;
            if (`ref` in r) {
                var o = {};
                for (var s in r) s !== `ref` && (o[s] = r[s])
            } else o = r;
            return sa(t), r = ko(e, t, n, o, a, i), s = No(), e !== null && !ac ? (Po(e, t, i), jc(e, t, i)) : (N && s && Ri(t), t.flags |= 1, oc(e, t, r, i), t.child)
        }

        function cc(e, t, n, r, i) {
            if (e === null) {
                var a = n.type;
                return typeof a == `function` && !_i(a) && a.defaultProps === void 0 && n.compare === null ? (t.tag = 15, t.type = a, lc(e, t, a, r, i)) : (e = bi(n.type, null, r, t, t.mode, i), e.ref = t.ref, e.return = t, t.child = e)
            }
            if (a = e.child, !Mc(e, i)) {
                var o = a.memoizedProps;
                if (n = n.compare, n = n === null ? jr : n, n(o, r) && e.ref === t.ref) return jc(e, t, i)
            }
            return t.flags |= 1, e = vi(a, r), e.ref = t.ref, e.return = t, t.child = e
        }

        function lc(e, t, n, r, i) {
            if (e !== null) {
                var a = e.memoizedProps;
                if (jr(a, r) && e.ref === t.ref)
                    if (ac = !1, t.pendingProps = r = a, Mc(e, i)) e.flags & 131072 && (ac = !0);
                    else return t.lanes = e.lanes, jc(e, t, i)
            }
            return _c(e, t, n, r, i)
        }

        function uc(e, t, n, r) {
            var i = r.children,
                a = e === null ? null : e.memoizedState;
            if (e === null && t.stateNode === null && (t.stateNode = {
                    _visibility: 1,
                    _pendingMarkers: null,
                    _retryCache: null,
                    _transitions: null
                }), r.mode === `hidden`) {
                if (t.flags & 128) {
                    if (a = a === null ? n : a.baseLanes | n, e !== null) {
                        for (r = t.child = e.child, i = 0; r !== null;) i = i | r.lanes | r.childLanes, r = r.sibling;
                        r = i & ~a
                    } else r = 0, t.child = null;
                    return fc(e, t, a, n, r)
                }
                if (n & 536870912) t.memoizedState = {
                    baseLanes: 0,
                    cachePool: null
                }, e !== null && Da(t, a === null ? null : a.cachePool), a === null ? co() : so(t, a), ho(t);
                else return r = t.lanes = 536870912, fc(e, t, a === null ? n : a.baseLanes | n, n, r)
            } else a === null ? (e !== null && Da(t, null), co(), go(t)) : (Da(t, a.cachePool), so(t, a), go(t), t.memoizedState = null);
            return oc(e, t, i, n), t.child
        }

        function dc(e, t) {
            return e !== null && e.tag === 22 || t.stateNode !== null || (t.stateNode = {
                _visibility: 1,
                _pendingMarkers: null,
                _retryCache: null,
                _transitions: null
            }), t.sibling
        }

        function fc(e, t, n, r, i) {
            var a = Ea();
            return a = a === null ? null : {
                parent: ma._currentValue,
                pool: a
            }, t.memoizedState = {
                baseLanes: n,
                cachePool: a
            }, e !== null && Da(t, null), co(), ho(t), e !== null && aa(e, t, r, !0), t.childLanes = i, null
        }

        function pc(e, t) {
            return t = Ec({
                mode: t.mode,
                children: t.children
            }, e.mode), t.ref = e.ref, e.child = t, t.return = e, t
        }

        function mc(e, t, n) {
            return Ga(t, e.child, null, n), e = pc(t, t.pendingProps), e.flags |= 2, P(t), t.memoizedState = null, e
        }

        function hc(e, t, n) {
            var r = t.pendingProps,
                a = (t.flags & 128) != 0;
            if (t.flags &= -129, e === null) {
                if (N) {
                    if (r.mode === `hidden`) return e = pc(t, r), t.lanes = 536870912, dc(null, e);
                    if (mo(t), (e = M) ? (e = af(e, Ui), e = e !== null && e.data === `&` ? e : null, e !== null && (t.memoizedState = {
                            dehydrated: e,
                            treeContext: Ni === null ? null : {
                                id: Pi,
                                overflow: Fi
                            },
                            retryLane: 536870912,
                            hydrationErrors: null
                        }, n = Ci(e), n.return = t, t.child = n, Vi = t, M = null)) : e = null, e === null) throw Gi(t);
                    return t.lanes = 536870912, null
                }
                return pc(t, r)
            }
            var o = e.memoizedState;
            if (o !== null) {
                var s = o.dehydrated;
                if (mo(t), a)
                    if (t.flags & 256) t.flags &= -257, t = mc(e, t, n);
                    else if (t.memoizedState !== null) t.child = e.child, t.flags |= 128, t = null;
                else throw Error(i(558));
                else if (ac || aa(e, t, n, !1), a = (n & e.childLanes) !== 0, ac || a) {
                    if (r = K, r !== null && (s = dt(r, n), s !== 0 && s !== o.retryLane)) throw o.retryLane = s, di(e, s), gu(r, e, s), ic;
                    Ou(), t = mc(e, t, n)
                } else e = o.treeContext, M = lf(s.nextSibling), Vi = t, N = !0, Hi = null, Ui = !1, e !== null && Bi(t, e), t = pc(t, r), t.flags |= 4096;
                return t
            }
            return e = vi(e.child, {
                mode: r.mode,
                children: r.children
            }), e.ref = t.ref, t.child = e, e.return = t, e
        }

        function gc(e, t) {
            var n = t.ref;
            if (n === null) e !== null && e.ref !== null && (t.flags |= 4194816);
            else {
                if (typeof n != `function` && typeof n != `object`) throw Error(i(284));
                (e === null || e.ref !== n) && (t.flags |= 4194816)
            }
        }

        function _c(e, t, n, r, i) {
            return sa(t), n = ko(e, t, n, r, void 0, i), r = No(), e !== null && !ac ? (Po(e, t, i), jc(e, t, i)) : (N && r && Ri(t), t.flags |= 1, oc(e, t, n, i), t.child)
        }

        function vc(e, t, n, r, i, a) {
            return sa(t), t.updateQueue = null, n = jo(t, r, n, i), Ao(e), r = No(), e !== null && !ac ? (Po(e, t, a), jc(e, t, a)) : (N && r && Ri(t), t.flags |= 1, oc(e, t, n, a), t.child)
        }

        function yc(e, t, n, r, i) {
            if (sa(t), t.stateNode === null) {
                var a = mi,
                    o = n.contextType;
                typeof o == `object` && o && (a = ca(o)), a = new n(r, a), t.memoizedState = a.state !== null && a.state !== void 0 ? a.state : null, a.updater = Ks, t.stateNode = a, a._reactInternals = t, a = t.stateNode, a.props = r, a.state = t.memoizedState, a.refs = {}, Ja(t), o = n.contextType, a.context = typeof o == `object` && o ? ca(o) : mi, a.state = t.memoizedState, o = n.getDerivedStateFromProps, typeof o == `function` && (Gs(t, n, o, r), a.state = t.memoizedState), typeof n.getDerivedStateFromProps == `function` || typeof a.getSnapshotBeforeUpdate == `function` || typeof a.UNSAFE_componentWillMount != `function` && typeof a.componentWillMount != `function` || (o = a.state, typeof a.componentWillMount == `function` && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == `function` && a.UNSAFE_componentWillMount(), o !== a.state && Ks.enqueueReplaceState(a, a.state, null), no(t, r, a, i), to(), a.state = t.memoizedState), typeof a.componentDidMount == `function` && (t.flags |= 4194308), r = !0
            } else if (e === null) {
                a = t.stateNode;
                var s = t.memoizedProps,
                    c = Ys(n, s);
                a.props = c;
                var l = a.context,
                    u = n.contextType;
                o = mi, typeof u == `object` && u && (o = ca(u));
                var d = n.getDerivedStateFromProps;
                u = typeof d == `function` || typeof a.getSnapshotBeforeUpdate == `function`, s = t.pendingProps !== s, u || typeof a.UNSAFE_componentWillReceiveProps != `function` && typeof a.componentWillReceiveProps != `function` || (s || l !== o) && Js(t, a, r, o), qa = !1;
                var f = t.memoizedState;
                a.state = f, no(t, r, a, i), to(), l = t.memoizedState, s || f !== l || qa ? (typeof d == `function` && (Gs(t, n, d, r), l = t.memoizedState), (c = qa || qs(t, n, c, r, f, l, o)) ? (u || typeof a.UNSAFE_componentWillMount != `function` && typeof a.componentWillMount != `function` || (typeof a.componentWillMount == `function` && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == `function` && a.UNSAFE_componentWillMount()), typeof a.componentDidMount == `function` && (t.flags |= 4194308)) : (typeof a.componentDidMount == `function` && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = l), a.props = r, a.state = l, a.context = o, r = c) : (typeof a.componentDidMount == `function` && (t.flags |= 4194308), r = !1)
            } else {
                a = t.stateNode, Ya(e, t), o = t.memoizedProps, u = Ys(n, o), a.props = u, d = t.pendingProps, f = a.context, l = n.contextType, c = mi, typeof l == `object` && l && (c = ca(l)), s = n.getDerivedStateFromProps, (l = typeof s == `function` || typeof a.getSnapshotBeforeUpdate == `function`) || typeof a.UNSAFE_componentWillReceiveProps != `function` && typeof a.componentWillReceiveProps != `function` || (o !== d || f !== c) && Js(t, a, r, c), qa = !1, f = t.memoizedState, a.state = f, no(t, r, a, i), to();
                var p = t.memoizedState;
                o !== d || f !== p || qa || e !== null && e.dependencies !== null && oa(e.dependencies) ? (typeof s == `function` && (Gs(t, n, s, r), p = t.memoizedState), (u = qa || qs(t, n, u, r, f, p, c) || e !== null && e.dependencies !== null && oa(e.dependencies)) ? (l || typeof a.UNSAFE_componentWillUpdate != `function` && typeof a.componentWillUpdate != `function` || (typeof a.componentWillUpdate == `function` && a.componentWillUpdate(r, p, c), typeof a.UNSAFE_componentWillUpdate == `function` && a.UNSAFE_componentWillUpdate(r, p, c)), typeof a.componentDidUpdate == `function` && (t.flags |= 4), typeof a.getSnapshotBeforeUpdate == `function` && (t.flags |= 1024)) : (typeof a.componentDidUpdate != `function` || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != `function` || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = p), a.props = r, a.state = p, a.context = c, r = u) : (typeof a.componentDidUpdate != `function` || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != `function` || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), r = !1)
            }
            return a = r, gc(e, t), r = (t.flags & 128) != 0, a || r ? (a = t.stateNode, n = r && typeof n.getDerivedStateFromError != `function` ? null : a.render(), t.flags |= 1, e !== null && r ? (t.child = Ga(t, e.child, null, i), t.child = Ga(t, null, n, i)) : oc(e, t, n, i), t.memoizedState = a.state, e = t.child) : e = jc(e, t, i), e
        }

        function bc(e, t, n, r) {
            return Yi(), t.flags |= 256, oc(e, t, n, r), t.child
        }
        var xc = {
            dehydrated: null,
            treeContext: null,
            retryLane: 0,
            hydrationErrors: null
        };

        function Sc(e) {
            return {
                baseLanes: e,
                cachePool: Oa()
            }
        }

        function Cc(e, t, n) {
            return e = e === null ? 0 : e.childLanes & ~n, t && (e |= Yl), e
        }

        function wc(e, t, n) {
            var r = t.pendingProps,
                a = !1,
                o = (t.flags & 128) != 0,
                s;
            if ((s = o) || (s = e !== null && e.memoizedState === null ? !1 : (_o.current & 2) != 0), s && (a = !0, t.flags &= -129), s = (t.flags & 32) != 0, t.flags &= -33, e === null) {
                if (N) {
                    if (a ? po(t) : go(t), (e = M) ? (e = af(e, Ui), e = e !== null && e.data !== `&` ? e : null, e !== null && (t.memoizedState = {
                            dehydrated: e,
                            treeContext: Ni === null ? null : {
                                id: Pi,
                                overflow: Fi
                            },
                            retryLane: 536870912,
                            hydrationErrors: null
                        }, n = Ci(e), n.return = t, t.child = n, Vi = t, M = null)) : e = null, e === null) throw Gi(t);
                    return sf(e) ? t.lanes = 32 : t.lanes = 536870912, null
                }
                var c = r.children;
                return r = r.fallback, a ? (go(t), a = t.mode, c = Ec({
                    mode: `hidden`,
                    children: c
                }, a), r = xi(r, a, n, null), c.return = t, r.return = t, c.sibling = r, t.child = c, r = t.child, r.memoizedState = Sc(n), r.childLanes = Cc(e, s, n), t.memoizedState = xc, dc(null, r)) : (po(t), Tc(t, c))
            }
            var l = e.memoizedState;
            if (l !== null && (c = l.dehydrated, c !== null)) {
                if (o) t.flags & 256 ? (po(t), t.flags &= -257, t = Dc(e, t, n)) : t.memoizedState === null ? (go(t), c = r.fallback, a = t.mode, r = Ec({
                    mode: `visible`,
                    children: r.children
                }, a), c = xi(c, a, n, null), c.flags |= 2, r.return = t, c.return = t, r.sibling = c, t.child = r, Ga(t, e.child, null, n), r = t.child, r.memoizedState = Sc(n), r.childLanes = Cc(e, s, n), t.memoizedState = xc, t = dc(null, r)) : (go(t), t.child = e.child, t.flags |= 128, t = null);
                else if (po(t), sf(c)) {
                    if (s = c.nextSibling && c.nextSibling.dataset, s) var u = s.dgst;
                    s = u, r = Error(i(419)), r.stack = ``, r.digest = s, Zi({
                        value: r,
                        source: null,
                        stack: null
                    }), t = Dc(e, t, n)
                } else if (ac || aa(e, t, n, !1), s = (n & e.childLanes) !== 0, ac || s) {
                    if (s = K, s !== null && (r = dt(s, n), r !== 0 && r !== l.retryLane)) throw l.retryLane = r, di(e, r), gu(s, e, r), ic; of (c) || Ou(), t = Dc(e, t, n)
                } else of(c) ? (t.flags |= 192, t.child = e.child, t = null) : (e = l.treeContext, M = lf(c.nextSibling), Vi = t, N = !0, Hi = null, Ui = !1, e !== null && Bi(t, e), t = Tc(t, r.children), t.flags |= 4096);
                return t
            }
            return a ? (go(t), c = r.fallback, a = t.mode, l = e.child, u = l.sibling, r = vi(l, {
                mode: `hidden`,
                children: r.children
            }), r.subtreeFlags = l.subtreeFlags & 65011712, u === null ? (c = xi(c, a, n, null), c.flags |= 2) : c = vi(u, c), c.return = t, r.return = t, r.sibling = c, t.child = r, dc(null, r), r = t.child, c = e.child.memoizedState, c === null ? c = Sc(n) : (a = c.cachePool, a === null ? a = Oa() : (l = ma._currentValue, a = a.parent === l ? a : {
                parent: l,
                pool: l
            }), c = {
                baseLanes: c.baseLanes | n,
                cachePool: a
            }), r.memoizedState = c, r.childLanes = Cc(e, s, n), t.memoizedState = xc, dc(e.child, r)) : (po(t), n = e.child, e = n.sibling, n = vi(n, {
                mode: `visible`,
                children: r.children
            }), n.return = t, n.sibling = null, e !== null && (s = t.deletions, s === null ? (t.deletions = [e], t.flags |= 16) : s.push(e)), t.child = n, t.memoizedState = null, n)
        }

        function Tc(e, t) {
            return t = Ec({
                mode: `visible`,
                children: t
            }, e.mode), t.return = e, e.child = t
        }

        function Ec(e, t) {
            return e = gi(22, e, null, t), e.lanes = 0, e
        }

        function Dc(e, t, n) {
            return Ga(t, e.child, null, n), e = Tc(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
        }

        function Oc(e, t, n) {
            e.lanes |= t;
            var r = e.alternate;
            r !== null && (r.lanes |= t), ra(e.return, t, n)
        }

        function kc(e, t, n, r, i, a) {
            var o = e.memoizedState;
            o === null ? e.memoizedState = {
                isBackwards: t,
                rendering: null,
                renderingStartTime: 0,
                last: r,
                tail: n,
                tailMode: i,
                treeForkCount: a
            } : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = i, o.treeForkCount = a)
        }

        function Ac(e, t, n) {
            var r = t.pendingProps,
                i = r.revealOrder,
                a = r.tail;
            r = r.children;
            var o = _o.current,
                s = (o & 2) != 0;
            if (s ? (o = o & 1 | 2, t.flags |= 128) : o &= 1, O(_o, o), oc(e, t, r, n), r = N ? Ai : 0, !s && e !== null && e.flags & 128) a: for (e = t.child; e !== null;) {
                if (e.tag === 13) e.memoizedState !== null && Oc(e, n, t);
                else if (e.tag === 19) Oc(e, n, t);
                else if (e.child !== null) {
                    e.child.return = e, e = e.child;
                    continue
                }
                if (e === t) break a;
                for (; e.sibling === null;) {
                    if (e.return === null || e.return === t) break a;
                    e = e.return
                }
                e.sibling.return = e.return, e = e.sibling
            }
            switch (i) {
                case `forwards`:
                    for (n = t.child, i = null; n !== null;) e = n.alternate, e !== null && vo(e) === null && (i = n), n = n.sibling;
                    n = i, n === null ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null), kc(t, !1, i, n, a, r);
                    break;
                case `backwards`:
                case `unstable_legacy-backwards`:
                    for (n = null, i = t.child, t.child = null; i !== null;) {
                        if (e = i.alternate, e !== null && vo(e) === null) {
                            t.child = i;
                            break
                        }
                        e = i.sibling, i.sibling = n, n = i, i = e
                    }
                    kc(t, !0, n, null, a, r);
                    break;
                case `together`:
                    kc(t, !1, null, null, void 0, r);
                    break;
                default:
                    t.memoizedState = null
            }
            return t.child
        }

        function jc(e, t, n) {
            if (e !== null && (t.dependencies = e.dependencies), Kl |= t.lanes, (n & t.childLanes) === 0)
                if (e !== null) {
                    if (aa(e, t, n, !1), (n & t.childLanes) === 0) return null
                } else return null;
            if (e !== null && t.child !== e.child) throw Error(i(153));
            if (t.child !== null) {
                for (e = t.child, n = vi(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = vi(e, e.pendingProps), n.return = t;
                n.sibling = null
            }
            return t.child
        }

        function Mc(e, t) {
            return (e.lanes & t) === 0 ? (e = e.dependencies, !!(e !== null && oa(e))) : !0
        }

        function Nc(e, t, n) {
            switch (t.tag) {
                case 3:
                    be(t, t.stateNode.containerInfo), ta(t, ma, e.memoizedState.cache), Yi();
                    break;
                case 27:
                case 5:
                    Se(t);
                    break;
                case 4:
                    be(t, t.stateNode.containerInfo);
                    break;
                case 10:
                    ta(t, t.type, t.memoizedProps.value);
                    break;
                case 31:
                    if (t.memoizedState !== null) return t.flags |= 128, mo(t), null;
                    break;
                case 13:
                    var r = t.memoizedState;
                    if (r !== null) return r.dehydrated === null ? (n & t.child.childLanes) === 0 ? (po(t), e = jc(e, t, n), e === null ? null : e.sibling) : wc(e, t, n) : (po(t), t.flags |= 128, null);
                    po(t);
                    break;
                case 19:
                    var i = (e.flags & 128) != 0;
                    if (r = (n & t.childLanes) !== 0, r || = (aa(e, t, n, !1), (n & t.childLanes) !== 0), i) {
                        if (r) return Ac(e, t, n);
                        t.flags |= 128
                    }
                    if (i = t.memoizedState, i !== null && (i.rendering = null, i.tail = null, i.lastEffect = null), O(_o, _o.current), r) break;
                    return null;
                case 22:
                    return t.lanes = 0, uc(e, t, n, t.pendingProps);
                case 24:
                    ta(t, ma, e.memoizedState.cache)
            }
            return jc(e, t, n)
        }

        function Pc(e, t, n) {
            if (e !== null)
                if (e.memoizedProps !== t.pendingProps) ac = !0;
                else {
                    if (!Mc(e, n) && !(t.flags & 128)) return ac = !1, Nc(e, t, n);
                    ac = !!(e.flags & 131072)
                }
            else ac = !1, N && t.flags & 1048576 && Li(t, Ai, t.index);
            switch (t.lanes = 0, t.tag) {
                case 16:
                    a: {
                        var r = t.pendingProps;
                        if (e = Fa(t.elementType), t.type = e, typeof e == `function`) _i(e) ? (r = Ys(e, r), t.tag = 1, t = yc(null, t, e, r, n)) : (t.tag = 0, t = _c(null, t, e, r, n));
                        else {
                            if (e != null) {
                                var a = e.$$typeof;
                                if (a === C) {
                                    t.tag = 11, t = sc(null, t, e, r, n);
                                    break a
                                } else if (a === re) {
                                    t.tag = 14, t = cc(null, t, e, r, n);
                                    break a
                                }
                            }
                            throw t = ue(e) || e, Error(i(306, t, ``))
                        }
                    }
                    return t;
                case 0:
                    return _c(e, t, t.type, t.pendingProps, n);
                case 1:
                    return r = t.type, a = Ys(r, t.pendingProps), yc(e, t, r, a, n);
                case 3:
                    a: {
                        if (be(t, t.stateNode.containerInfo), e === null) throw Error(i(387));r = t.pendingProps;
                        var o = t.memoizedState;a = o.element,
                        Ya(e, t),
                        no(t, r, null, n);
                        var s = t.memoizedState;
                        if (r = s.cache, ta(t, ma, r), r !== o.cache && ia(t, [ma], n, !0), to(), r = s.element, o.isDehydrated)
                            if (o = {
                                    element: r,
                                    isDehydrated: !1,
                                    cache: s.cache
                                }, t.updateQueue.baseState = o, t.memoizedState = o, t.flags & 256) {
                                t = bc(e, t, r, n);
                                break a
                            } else if (r !== a) {
                            a = Ei(Error(i(424)), t), Zi(a), t = bc(e, t, r, n);
                            break a
                        } else {
                            switch (e = t.stateNode.containerInfo, e.nodeType) {
                                case 9:
                                    e = e.body;
                                    break;
                                default:
                                    e = e.nodeName === `HTML` ? e.ownerDocument.body : e
                            }
                            for (M = lf(e.firstChild), Vi = t, N = !0, Hi = null, Ui = !0, n = Ka(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling
                        } else {
                            if (Yi(), r === a) {
                                t = jc(e, t, n);
                                break a
                            }
                            oc(e, t, r, n)
                        }
                        t = t.child
                    }
                    return t;
                case 26:
                    return gc(e, t), e === null ? (n = Af(t.type, null, t.pendingProps, null)) ? t.memoizedState = n : N || (n = t.type, e = t.pendingProps, r = Vd(ve.current).createElement(n), r[_t] = t, r[k] = e, Fd(r, n, e), kt(r), t.stateNode = r) : t.memoizedState = Af(t.type, e.memoizedProps, t.pendingProps, e.memoizedState), null;
                case 27:
                    return Se(t), e === null && N && (r = t.stateNode = pf(t.type, t.pendingProps, ve.current), Vi = t, Ui = !0, a = M, Qd(t.type) ? (uf = a, M = lf(r.firstChild)) : M = a), oc(e, t, t.pendingProps.children, n), gc(e, t), e === null && (t.flags |= 4194304), t.child;
                case 5:
                    return e === null && N && ((a = r = M) && (r = nf(r, t.type, t.pendingProps, Ui), r === null ? a = !1 : (t.stateNode = r, Vi = t, M = lf(r.firstChild), Ui = !1, a = !0)), a || Gi(t)), Se(t), a = t.type, o = t.pendingProps, s = e === null ? null : e.memoizedProps, r = o.children, Wd(a, o) ? r = null : s !== null && Wd(a, s) && (t.flags |= 32), t.memoizedState !== null && (a = ko(e, t, Mo, null, null, n), $f._currentValue = a), gc(e, t), oc(e, t, r, n), t.child;
                case 6:
                    return e === null && N && ((e = n = M) && (n = rf(n, t.pendingProps, Ui), n === null ? e = !1 : (t.stateNode = n, Vi = t, M = null, e = !0)), e || Gi(t)), null;
                case 13:
                    return wc(e, t, n);
                case 4:
                    return be(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = Ga(t, null, r, n) : oc(e, t, r, n), t.child;
                case 11:
                    return sc(e, t, t.type, t.pendingProps, n);
                case 7:
                    return oc(e, t, t.pendingProps, n), t.child;
                case 8:
                    return oc(e, t, t.pendingProps.children, n), t.child;
                case 12:
                    return oc(e, t, t.pendingProps.children, n), t.child;
                case 10:
                    return r = t.pendingProps, ta(t, t.type, r.value), oc(e, t, r.children, n), t.child;
                case 9:
                    return a = t.type._context, r = t.pendingProps.children, sa(t), a = ca(a), r = r(a), t.flags |= 1, oc(e, t, r, n), t.child;
                case 14:
                    return cc(e, t, t.type, t.pendingProps, n);
                case 15:
                    return lc(e, t, t.type, t.pendingProps, n);
                case 19:
                    return Ac(e, t, n);
                case 31:
                    return hc(e, t, n);
                case 22:
                    return uc(e, t, n, t.pendingProps);
                case 24:
                    return sa(t), r = ca(ma), e === null ? (a = Ea(), a === null && (a = K, o = ha(), a.pooledCache = o, o.refCount++, o !== null && (a.pooledCacheLanes |= n), a = o), t.memoizedState = {
                        parent: r,
                        cache: a
                    }, Ja(t), ta(t, ma, a)) : ((e.lanes & n) !== 0 && (Ya(e, t), no(t, null, null, n), to()), a = e.memoizedState, o = t.memoizedState, a.parent === r ? (r = o.cache, ta(t, ma, r), r !== a.cache && ia(t, [ma], n, !0)) : (a = {
                        parent: r,
                        cache: r
                    }, t.memoizedState = a, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = a), ta(t, ma, r))), oc(e, t, t.pendingProps.children, n), t.child;
                case 29:
                    throw t.pendingProps
            }
            throw Error(i(156, t.tag))
        }

        function Fc(e) {
            e.flags |= 4
        }

        function Ic(e, t, n, r, i) {
            if ((t = (e.mode & 32) != 0) && (t = !1), t) {
                if (e.flags |= 16777216, (i & 335544128) === i)
                    if (e.stateNode.complete) e.flags |= 8192;
                    else if (Tu()) e.flags |= 8192;
                else throw Ia = Ma, Aa
            } else e.flags &= -16777217
        }

        function Lc(e, t) {
            if (t.type !== `stylesheet` || t.state.loading & 4) e.flags &= -16777217;
            else if (e.flags |= 16777216, !Gf(t))
                if (Tu()) e.flags |= 8192;
                else throw Ia = Ma, Aa
        }

        function Rc(e, t) {
            t !== null && (e.flags |= 4), e.flags & 16384 && (t = e.tag === 22 ? 536870912 : at(), e.lanes |= t, Xl |= t)
        }

        function zc(e, t) {
            if (!N) switch (e.tailMode) {
                case `hidden`:
                    t = e.tail;
                    for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
                    n === null ? e.tail = null : n.sibling = null;
                    break;
                case `collapsed`:
                    n = e.tail;
                    for (var r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
                    r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
            }
        }

        function U(e) {
            var t = e.alternate !== null && e.alternate.child === e.child,
                n = 0,
                r = 0;
            if (t)
                for (var i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags & 65011712, r |= i.flags & 65011712, i.return = e, i = i.sibling;
            else
                for (i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags, r |= i.flags, i.return = e, i = i.sibling;
            return e.subtreeFlags |= r, e.childLanes = n, t
        }

        function Bc(e, t, n) {
            var r = t.pendingProps;
            switch (zi(t), t.tag) {
                case 16:
                case 15:
                case 0:
                case 11:
                case 7:
                case 8:
                case 12:
                case 9:
                case 14:
                    return U(t), null;
                case 1:
                    return U(t), null;
                case 3:
                    return n = t.stateNode, r = null, e !== null && (r = e.memoizedState.cache), t.memoizedState.cache !== r && (t.flags |= 2048), na(ma), xe(), n.pendingContext && (n.context = n.pendingContext, n.pendingContext = null), (e === null || e.child === null) && (Ji(t) ? Fc(t) : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, Xi())), U(t), null;
                case 26:
                    var a = t.type,
                        o = t.memoizedState;
                    return e === null ? (Fc(t), o === null ? (U(t), Ic(t, a, null, r, n)) : (U(t), Lc(t, o))) : o ? o === e.memoizedState ? (U(t), t.flags &= -16777217) : (Fc(t), U(t), Lc(t, o)) : (e = e.memoizedProps, e !== r && Fc(t), U(t), Ic(t, a, e, r, n)), null;
                case 27:
                    if (Ce(t), n = ve.current, a = t.type, e !== null && t.stateNode != null) e.memoizedProps !== r && Fc(t);
                    else {
                        if (!r) {
                            if (t.stateNode === null) throw Error(i(166));
                            return U(t), null
                        }
                        e = ge.current, Ji(t) ? Ki(t, e) : (e = pf(a, r, n), t.stateNode = e, Fc(t))
                    }
                    return U(t), null;
                case 5:
                    if (Ce(t), a = t.type, e !== null && t.stateNode != null) e.memoizedProps !== r && Fc(t);
                    else {
                        if (!r) {
                            if (t.stateNode === null) throw Error(i(166));
                            return U(t), null
                        }
                        if (o = ge.current, Ji(t)) Ki(t, o);
                        else {
                            var s = Vd(ve.current);
                            switch (o) {
                                case 1:
                                    o = s.createElementNS(`http://www.w3.org/2000/svg`, a);
                                    break;
                                case 2:
                                    o = s.createElementNS(`http://www.w3.org/1998/Math/MathML`, a);
                                    break;
                                default:
                                    switch (a) {
                                        case `svg`:
                                            o = s.createElementNS(`http://www.w3.org/2000/svg`, a);
                                            break;
                                        case `math`:
                                            o = s.createElementNS(`http://www.w3.org/1998/Math/MathML`, a);
                                            break;
                                        case `script`:
                                            o = s.createElement(`div`), o.innerHTML = `<script><\/script>`, o = o.removeChild(o.firstChild);
                                            break;
                                        case `select`:
                                            o = typeof r.is == `string` ? s.createElement(`select`, {
                                                is: r.is
                                            }) : s.createElement(`select`), r.multiple ? o.multiple = !0 : r.size && (o.size = r.size);
                                            break;
                                        default:
                                            o = typeof r.is == `string` ? s.createElement(a, {
                                                is: r.is
                                            }) : s.createElement(a)
                                    }
                            }
                            o[_t] = t, o[k] = r;
                            a: for (s = t.child; s !== null;) {
                                if (s.tag === 5 || s.tag === 6) o.appendChild(s.stateNode);
                                else if (s.tag !== 4 && s.tag !== 27 && s.child !== null) {
                                    s.child.return = s, s = s.child;
                                    continue
                                }
                                if (s === t) break a;
                                for (; s.sibling === null;) {
                                    if (s.return === null || s.return === t) break a;
                                    s = s.return
                                }
                                s.sibling.return = s.return, s = s.sibling
                            }
                            t.stateNode = o;
                            a: switch (Fd(o, a, r), a) {
                                case `button`:
                                case `input`:
                                case `select`:
                                case `textarea`:
                                    r = !!r.autoFocus;
                                    break a;
                                case `img`:
                                    r = !0;
                                    break a;
                                default:
                                    r = !1
                            }
                            r && Fc(t)
                        }
                    }
                    return U(t), Ic(t, t.type, e === null ? null : e.memoizedProps, t.pendingProps, n), null;
                case 6:
                    if (e && t.stateNode != null) e.memoizedProps !== r && Fc(t);
                    else {
                        if (typeof r != `string` && t.stateNode === null) throw Error(i(166));
                        if (e = ve.current, Ji(t)) {
                            if (e = t.stateNode, n = t.memoizedProps, r = null, a = Vi, a !== null) switch (a.tag) {
                                case 27:
                                case 5:
                                    r = a.memoizedProps
                            }
                            e[_t] = t, e = !!(e.nodeValue === n || r !== null && !0 === r.suppressHydrationWarning || Nd(e.nodeValue, n)), e || Gi(t, !0)
                        } else e = Vd(e).createTextNode(r), e[_t] = t, t.stateNode = e
                    }
                    return U(t), null;
                case 31:
                    if (n = t.memoizedState, e === null || e.memoizedState !== null) {
                        if (r = Ji(t), n !== null) {
                            if (e === null) {
                                if (!r) throw Error(i(318));
                                if (e = t.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(i(557));
                                e[_t] = t
                            } else Yi(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
                            U(t), e = !1
                        } else n = Xi(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = n), e = !0;
                        if (!e) return t.flags & 256 ? (P(t), t) : (P(t), null);
                        if (t.flags & 128) throw Error(i(558))
                    }
                    return U(t), null;
                case 13:
                    if (r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
                        if (a = Ji(t), r !== null && r.dehydrated !== null) {
                            if (e === null) {
                                if (!a) throw Error(i(318));
                                if (a = t.memoizedState, a = a === null ? null : a.dehydrated, !a) throw Error(i(317));
                                a[_t] = t
                            } else Yi(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
                            U(t), a = !1
                        } else a = Xi(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = a), a = !0;
                        if (!a) return t.flags & 256 ? (P(t), t) : (P(t), null)
                    }
                    return P(t), t.flags & 128 ? (t.lanes = n, t) : (n = r !== null, e = e !== null && e.memoizedState !== null, n && (r = t.child, a = null, r.alternate !== null && r.alternate.memoizedState !== null && r.alternate.memoizedState.cachePool !== null && (a = r.alternate.memoizedState.cachePool.pool), o = null, r.memoizedState !== null && r.memoizedState.cachePool !== null && (o = r.memoizedState.cachePool.pool), o !== a && (r.flags |= 2048)), n !== e && n && (t.child.flags |= 8192), Rc(t, t.updateQueue), U(t), null);
                case 4:
                    return xe(), e === null && Cd(t.stateNode.containerInfo), U(t), null;
                case 10:
                    return na(t.type), U(t), null;
                case 19:
                    if (D(_o), r = t.memoizedState, r === null) return U(t), null;
                    if (a = (t.flags & 128) != 0, o = r.rendering, o === null)
                        if (a) zc(r, !1);
                        else {
                            if (X !== 0 || e !== null && e.flags & 128)
                                for (e = t.child; e !== null;) {
                                    if (o = vo(e), o !== null) {
                                        for (t.flags |= 128, zc(r, !1), e = o.updateQueue, t.updateQueue = e, Rc(t, e), t.subtreeFlags = 0, e = n, n = t.child; n !== null;) yi(n, e), n = n.sibling;
                                        return O(_o, _o.current & 1 | 2), N && Ii(t, r.treeForkCount), t.child
                                    }
                                    e = e.sibling
                                }
                            r.tail !== null && Ie() > nu && (t.flags |= 128, a = !0, zc(r, !1), t.lanes = 4194304)
                        }
                    else {
                        if (!a)
                            if (e = vo(o), e !== null) {
                                if (t.flags |= 128, a = !0, e = e.updateQueue, t.updateQueue = e, Rc(t, e), zc(r, !0), r.tail === null && r.tailMode === `hidden` && !o.alternate && !N) return U(t), null
                            } else 2 * Ie() - r.renderingStartTime > nu && n !== 536870912 && (t.flags |= 128, a = !0, zc(r, !1), t.lanes = 4194304);
                        r.isBackwards ? (o.sibling = t.child, t.child = o) : (e = r.last, e === null ? t.child = o : e.sibling = o, r.last = o)
                    }
                    return r.tail === null ? (U(t), null) : (e = r.tail, r.rendering = e, r.tail = e.sibling, r.renderingStartTime = Ie(), e.sibling = null, n = _o.current, O(_o, a ? n & 1 | 2 : n & 1), N && Ii(t, r.treeForkCount), e);
                case 22:
                case 23:
                    return P(t), lo(), r = t.memoizedState !== null, e === null ? r && (t.flags |= 8192) : e.memoizedState !== null !== r && (t.flags |= 8192), r ? n & 536870912 && !(t.flags & 128) && (U(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : U(t), n = t.updateQueue, n !== null && Rc(t, n.retryQueue), n = null, e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), r = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (r = t.memoizedState.cachePool.pool), r !== n && (t.flags |= 2048), e !== null && D(Ta), null;
                case 24:
                    return n = null, e !== null && (n = e.memoizedState.cache), t.memoizedState.cache !== n && (t.flags |= 2048), na(ma), U(t), null;
                case 25:
                    return null;
                case 30:
                    return null
            }
            throw Error(i(156, t.tag))
        }

        function Vc(e, t) {
            switch (zi(t), t.tag) {
                case 1:
                    return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
                case 3:
                    return na(ma), xe(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
                case 26:
                case 27:
                case 5:
                    return Ce(t), null;
                case 31:
                    if (t.memoizedState !== null) {
                        if (P(t), t.alternate === null) throw Error(i(340));
                        Yi()
                    }
                    return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
                case 13:
                    if (P(t), e = t.memoizedState, e !== null && e.dehydrated !== null) {
                        if (t.alternate === null) throw Error(i(340));
                        Yi()
                    }
                    return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
                case 19:
                    return D(_o), null;
                case 4:
                    return xe(), null;
                case 10:
                    return na(t.type), null;
                case 22:
                case 23:
                    return P(t), lo(), e !== null && D(Ta), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
                case 24:
                    return na(ma), null;
                case 25:
                    return null;
                default:
                    return null
            }
        }

        function Hc(e, t) {
            switch (zi(t), t.tag) {
                case 3:
                    na(ma), xe();
                    break;
                case 26:
                case 27:
                case 5:
                    Ce(t);
                    break;
                case 4:
                    xe();
                    break;
                case 31:
                    t.memoizedState !== null && P(t);
                    break;
                case 13:
                    P(t);
                    break;
                case 19:
                    D(_o);
                    break;
                case 10:
                    na(t.type);
                    break;
                case 22:
                case 23:
                    P(t), lo(), e !== null && D(Ta);
                    break;
                case 24:
                    na(ma)
            }
        }

        function Uc(e, t) {
            try {
                var n = t.updateQueue,
                    r = n === null ? null : n.lastEffect;
                if (r !== null) {
                    var i = r.next;
                    n = i;
                    do {
                        if ((n.tag & e) === e) {
                            r = void 0;
                            var a = n.create,
                                o = n.inst;
                            r = a(), o.destroy = r
                        }
                        n = n.next
                    } while (n !== i)
                }
            } catch (e) {
                Z(t, t.return, e)
            }
        }

        function Wc(e, t, n) {
            try {
                var r = t.updateQueue,
                    i = r === null ? null : r.lastEffect;
                if (i !== null) {
                    var a = i.next;
                    r = a;
                    do {
                        if ((r.tag & e) === e) {
                            var o = r.inst,
                                s = o.destroy;
                            if (s !== void 0) {
                                o.destroy = void 0, i = t;
                                var c = n,
                                    l = s;
                                try {
                                    l()
                                } catch (e) {
                                    Z(i, c, e)
                                }
                            }
                        }
                        r = r.next
                    } while (r !== a)
                }
            } catch (e) {
                Z(t, t.return, e)
            }
        }

        function Gc(e) {
            var t = e.updateQueue;
            if (t !== null) {
                var n = e.stateNode;
                try {
                    io(t, n)
                } catch (t) {
                    Z(e, e.return, t)
                }
            }
        }

        function Kc(e, t, n) {
            n.props = Ys(e.type, e.memoizedProps), n.state = e.memoizedState;
            try {
                n.componentWillUnmount()
            } catch (n) {
                Z(e, t, n)
            }
        }

        function qc(e, t) {
            try {
                var n = e.ref;
                if (n !== null) {
                    switch (e.tag) {
                        case 26:
                        case 27:
                        case 5:
                            var r = e.stateNode;
                            break;
                        case 30:
                            r = e.stateNode;
                            break;
                        default:
                            r = e.stateNode
                    }
                    typeof n == `function` ? e.refCleanup = n(r) : n.current = r
                }
            } catch (n) {
                Z(e, t, n)
            }
        }

        function Jc(e, t) {
            var n = e.ref,
                r = e.refCleanup;
            if (n !== null)
                if (typeof r == `function`) try {
                    r()
                } catch (n) {
                    Z(e, t, n)
                } finally {
                    e.refCleanup = null, e = e.alternate, e != null && (e.refCleanup = null)
                } else if (typeof n == `function`) try {
                    n(null)
                } catch (n) {
                    Z(e, t, n)
                } else n.current = null
        }

        function Yc(e) {
            var t = e.type,
                n = e.memoizedProps,
                r = e.stateNode;
            try {
                a: switch (t) {
                    case `button`:
                    case `input`:
                    case `select`:
                    case `textarea`:
                        n.autoFocus && r.focus();
                        break a;
                    case `img`:
                        n.src ? r.src = n.src : n.srcSet && (r.srcset = n.srcSet)
                }
            }
            catch (t) {
                Z(e, e.return, t)
            }
        }

        function Xc(e, t, n) {
            try {
                var r = e.stateNode;
                Id(r, e.type, n, t), r[k] = t
            } catch (t) {
                Z(e, e.return, t)
            }
        }

        function Zc(e) {
            return e.tag === 5 || e.tag === 3 || e.tag === 26 || e.tag === 27 && Qd(e.type) || e.tag === 4
        }

        function Qc(e) {
            a: for (;;) {
                for (; e.sibling === null;) {
                    if (e.return === null || Zc(e.return)) return null;
                    e = e.return
                }
                for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
                    if (e.tag === 27 && Qd(e.type) || e.flags & 2 || e.child === null || e.tag === 4) continue a;
                    e.child.return = e, e = e.child
                }
                if (!(e.flags & 2)) return e.stateNode
            }
        }

        function $c(e, t, n) {
            var r = e.tag;
            if (r === 5 || r === 6) e = e.stateNode, t ? (n.nodeType === 9 ? n.body : n.nodeName === `HTML` ? n.ownerDocument.body : n).insertBefore(e, t) : (t = n.nodeType === 9 ? n.body : n.nodeName === `HTML` ? n.ownerDocument.body : n, t.appendChild(e), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = un));
            else if (r !== 4 && (r === 27 && Qd(e.type) && (n = e.stateNode, t = null), e = e.child, e !== null))
                for ($c(e, t, n), e = e.sibling; e !== null;) $c(e, t, n), e = e.sibling
        }

        function el(e, t, n) {
            var r = e.tag;
            if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
            else if (r !== 4 && (r === 27 && Qd(e.type) && (n = e.stateNode), e = e.child, e !== null))
                for (el(e, t, n), e = e.sibling; e !== null;) el(e, t, n), e = e.sibling
        }

        function tl(e) {
            var t = e.stateNode,
                n = e.memoizedProps;
            try {
                for (var r = e.type, i = t.attributes; i.length;) t.removeAttributeNode(i[0]);
                Fd(t, r, n), t[_t] = e, t[k] = n
            } catch (t) {
                Z(e, e.return, t)
            }
        }
        var nl = !1,
            rl = !1,
            il = !1,
            al = typeof WeakSet == `function` ? WeakSet : Set,
            ol = null;

        function sl(e, t) {
            if (e = e.containerInfo, zd = cp, e = Fr(e), Ir(e)) {
                if (`selectionStart` in e) var n = {
                    start: e.selectionStart,
                    end: e.selectionEnd
                };
                else a: {
                    n = (n = e.ownerDocument) && n.defaultView || window;
                    var r = n.getSelection && n.getSelection();
                    if (r && r.rangeCount !== 0) {
                        n = r.anchorNode;
                        var a = r.anchorOffset,
                            o = r.focusNode;
                        r = r.focusOffset;
                        try {
                            n.nodeType, o.nodeType
                        } catch {
                            n = null;
                            break a
                        }
                        var s = 0,
                            c = -1,
                            l = -1,
                            u = 0,
                            d = 0,
                            f = e,
                            p = null;
                        b: for (;;) {
                            for (var m; f !== n || a !== 0 && f.nodeType !== 3 || (c = s + a), f !== o || r !== 0 && f.nodeType !== 3 || (l = s + r), f.nodeType === 3 && (s += f.nodeValue.length), (m = f.firstChild) !== null;) p = f, f = m;
                            for (;;) {
                                if (f === e) break b;
                                if (p === n && ++u === a && (c = s), p === o && ++d === r && (l = s), (m = f.nextSibling) !== null) break;
                                f = p, p = f.parentNode
                            }
                            f = m
                        }
                        n = c === -1 || l === -1 ? null : {
                            start: c,
                            end: l
                        }
                    } else n = null
                }
                n || = {
                    start: 0,
                    end: 0
                }
            } else n = null;
            for (Bd = {
                    focusedElem: e,
                    selectionRange: n
                }, cp = !1, ol = t; ol !== null;)
                if (t = ol, e = t.child, t.subtreeFlags & 1028 && e !== null) e.return = t, ol = e;
                else
                    for (; ol !== null;) {
                        switch (t = ol, o = t.alternate, e = t.flags, t.tag) {
                            case 0:
                                if (e & 4 && (e = t.updateQueue, e = e === null ? null : e.events, e !== null))
                                    for (n = 0; n < e.length; n++) a = e[n], a.ref.impl = a.nextImpl;
                                break;
                            case 11:
                            case 15:
                                break;
                            case 1:
                                if (e & 1024 && o !== null) {
                                    e = void 0, n = t, a = o.memoizedProps, o = o.memoizedState, r = n.stateNode;
                                    try {
                                        var h = Ys(n.type, a);
                                        e = r.getSnapshotBeforeUpdate(h, o), r.__reactInternalSnapshotBeforeUpdate = e
                                    } catch (e) {
                                        Z(n, n.return, e)
                                    }
                                }
                                break;
                            case 3:
                                if (e & 1024) {
                                    if (e = t.stateNode.containerInfo, n = e.nodeType, n === 9) tf(e);
                                    else if (n === 1) switch (e.nodeName) {
                                        case `HEAD`:
                                        case `HTML`:
                                        case `BODY`:
                                            tf(e);
                                            break;
                                        default:
                                            e.textContent = ``
                                    }
                                }
                                break;
                            case 5:
                            case 26:
                            case 27:
                            case 6:
                            case 4:
                            case 17:
                                break;
                            default:
                                if (e & 1024) throw Error(i(163))
                        }
                        if (e = t.sibling, e !== null) {
                            e.return = t.return, ol = e;
                            break
                        }
                        ol = t.return
                    }
        }

        function cl(e, t, n) {
            var r = n.flags;
            switch (n.tag) {
                case 0:
                case 11:
                case 15:
                    Sl(e, n), r & 4 && Uc(5, n);
                    break;
                case 1:
                    if (Sl(e, n), r & 4)
                        if (e = n.stateNode, t === null) try {
                            e.componentDidMount()
                        } catch (e) {
                            Z(n, n.return, e)
                        } else {
                            var i = Ys(n.type, t.memoizedProps);
                            t = t.memoizedState;
                            try {
                                e.componentDidUpdate(i, t, e.__reactInternalSnapshotBeforeUpdate)
                            } catch (e) {
                                Z(n, n.return, e)
                            }
                        }
                    r & 64 && Gc(n), r & 512 && qc(n, n.return);
                    break;
                case 3:
                    if (Sl(e, n), r & 64 && (e = n.updateQueue, e !== null)) {
                        if (t = null, n.child !== null) switch (n.child.tag) {
                            case 27:
                            case 5:
                                t = n.child.stateNode;
                                break;
                            case 1:
                                t = n.child.stateNode
                        }
                        try {
                            io(e, t)
                        } catch (e) {
                            Z(n, n.return, e)
                        }
                    }
                    break;
                case 27:
                    t === null && r & 4 && tl(n);
                case 26:
                case 5:
                    Sl(e, n), t === null && r & 4 && Yc(n), r & 512 && qc(n, n.return);
                    break;
                case 12:
                    Sl(e, n);
                    break;
                case 31:
                    Sl(e, n), r & 4 && pl(e, n);
                    break;
                case 13:
                    Sl(e, n), r & 4 && ml(e, n), r & 64 && (e = n.memoizedState, e !== null && (e = e.dehydrated, e !== null && (n = Yu.bind(null, n), cf(e, n))));
                    break;
                case 22:
                    if (r = n.memoizedState !== null || nl, !r) {
                        t = t !== null && t.memoizedState !== null || rl, i = nl;
                        var a = rl;
                        nl = r, (rl = t) && !a ? wl(e, n, (n.subtreeFlags & 8772) != 0) : Sl(e, n), nl = i, rl = a
                    }
                    break;
                case 30:
                    break;
                default:
                    Sl(e, n)
            }
        }

        function ll(e) {
            var t = e.alternate;
            t !== null && (e.alternate = null, ll(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && wt(t)), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
        }
        var W = null,
            ul = !1;

        function dl(e, t, n) {
            for (n = n.child; n !== null;) fl(e, t, n), n = n.sibling
        }

        function fl(e, t, n) {
            if (Ke && typeof Ke.onCommitFiberUnmount == `function`) try {
                Ke.onCommitFiberUnmount(Ge, n)
            } catch {}
            switch (n.tag) {
                case 26:
                    rl || Jc(n, t), dl(e, t, n), n.memoizedState ? n.memoizedState.count-- : n.stateNode && (n = n.stateNode, n.parentNode.removeChild(n));
                    break;
                case 27:
                    rl || Jc(n, t);
                    var r = W,
                        i = ul;
                    Qd(n.type) && (W = n.stateNode, ul = !1), dl(e, t, n), mf(n.stateNode), W = r, ul = i;
                    break;
                case 5:
                    rl || Jc(n, t);
                case 6:
                    if (r = W, i = ul, W = null, dl(e, t, n), W = r, ul = i, W !== null)
                        if (ul) try {
                            (W.nodeType === 9 ? W.body : W.nodeName === `HTML` ? W.ownerDocument.body : W).removeChild(n.stateNode)
                        } catch (e) {
                            Z(n, t, e)
                        } else try {
                            W.removeChild(n.stateNode)
                        } catch (e) {
                            Z(n, t, e)
                        }
                    break;
                case 18:
                    W !== null && (ul ? (e = W, $d(e.nodeType === 9 ? e.body : e.nodeName === `HTML` ? e.ownerDocument.body : e, n.stateNode), Pp(e)) : $d(W, n.stateNode));
                    break;
                case 4:
                    r = W, i = ul, W = n.stateNode.containerInfo, ul = !0, dl(e, t, n), W = r, ul = i;
                    break;
                case 0:
                case 11:
                case 14:
                case 15:
                    Wc(2, n, t), rl || Wc(4, n, t), dl(e, t, n);
                    break;
                case 1:
                    rl || (Jc(n, t), r = n.stateNode, typeof r.componentWillUnmount == `function` && Kc(n, t, r)), dl(e, t, n);
                    break;
                case 21:
                    dl(e, t, n);
                    break;
                case 22:
                    rl = (r = rl) || n.memoizedState !== null, dl(e, t, n), rl = r;
                    break;
                default:
                    dl(e, t, n)
            }
        }

        function pl(e, t) {
            if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null))) {
                e = e.dehydrated;
                try {
                    Pp(e)
                } catch (e) {
                    Z(t, t.return, e)
                }
            }
        }

        function ml(e, t) {
            if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null && (e = e.dehydrated, e !== null)))) try {
                Pp(e)
            } catch (e) {
                Z(t, t.return, e)
            }
        }

        function hl(e) {
            switch (e.tag) {
                case 31:
                case 13:
                case 19:
                    var t = e.stateNode;
                    return t === null && (t = e.stateNode = new al), t;
                case 22:
                    return e = e.stateNode, t = e._retryCache, t === null && (t = e._retryCache = new al), t;
                default:
                    throw Error(i(435, e.tag))
            }
        }

        function gl(e, t) {
            var n = hl(e);
            t.forEach(function(t) {
                if (!n.has(t)) {
                    n.add(t);
                    var r = Xu.bind(null, e, t);
                    t.then(r, r)
                }
            })
        }

        function _l(e, t) {
            var n = t.deletions;
            if (n !== null)
                for (var r = 0; r < n.length; r++) {
                    var a = n[r],
                        o = e,
                        s = t,
                        c = s;
                    a: for (; c !== null;) {
                        switch (c.tag) {
                            case 27:
                                if (Qd(c.type)) {
                                    W = c.stateNode, ul = !1;
                                    break a
                                }
                                break;
                            case 5:
                                W = c.stateNode, ul = !1;
                                break a;
                            case 3:
                            case 4:
                                W = c.stateNode.containerInfo, ul = !0;
                                break a
                        }
                        c = c.return
                    }
                    if (W === null) throw Error(i(160));
                    fl(o, s, a), W = null, ul = !1, o = a.alternate, o !== null && (o.return = null), a.return = null
                }
            if (t.subtreeFlags & 13886)
                for (t = t.child; t !== null;) yl(t, e), t = t.sibling
        }
        var vl = null;

        function yl(e, t) {
            var n = e.alternate,
                r = e.flags;
            switch (e.tag) {
                case 0:
                case 11:
                case 14:
                case 15:
                    _l(t, e), bl(e), r & 4 && (Wc(3, e, e.return), Uc(3, e), Wc(5, e, e.return));
                    break;
                case 1:
                    _l(t, e), bl(e), r & 512 && (rl || n === null || Jc(n, n.return)), r & 64 && nl && (e = e.updateQueue, e !== null && (r = e.callbacks, r !== null && (n = e.shared.hiddenCallbacks, e.shared.hiddenCallbacks = n === null ? r : n.concat(r))));
                    break;
                case 26:
                    var a = vl;
                    if (_l(t, e), bl(e), r & 512 && (rl || n === null || Jc(n, n.return)), r & 4) {
                        var o = n === null ? null : n.memoizedState;
                        if (r = e.memoizedState, n === null)
                            if (r === null)
                                if (e.stateNode === null) {
                                    a: {
                                        r = e.type,
                                        n = e.memoizedProps,
                                        a = a.ownerDocument || a;b: switch (r) {
                                            case `title`:
                                                o = a.getElementsByTagName(`title`)[0], (!o || o[Ct] || o[_t] || o.namespaceURI === `http://www.w3.org/2000/svg` || o.hasAttribute(`itemprop`)) && (o = a.createElement(r), a.head.insertBefore(o, a.querySelector(`head > title`))), Fd(o, r, n), o[_t] = e, kt(o), r = o;
                                                break a;
                                            case `link`:
                                                var s = Hf(`link`, `href`, a).get(r + (n.href || ``));
                                                if (s) {
                                                    for (var c = 0; c < s.length; c++)
                                                        if (o = s[c], o.getAttribute(`href`) === (n.href == null || n.href === `` ? null : n.href) && o.getAttribute(`rel`) === (n.rel == null ? null : n.rel) && o.getAttribute(`title`) === (n.title == null ? null : n.title) && o.getAttribute(`crossorigin`) === (n.crossOrigin == null ? null : n.crossOrigin)) {
                                                            s.splice(c, 1);
                                                            break b
                                                        }
                                                }
                                                o = a.createElement(r), Fd(o, r, n), a.head.appendChild(o);
                                                break;
                                            case `meta`:
                                                if (s = Hf(`meta`, `content`, a).get(r + (n.content || ``))) {
                                                    for (c = 0; c < s.length; c++)
                                                        if (o = s[c], o.getAttribute(`content`) === (n.content == null ? null : `` + n.content) && o.getAttribute(`name`) === (n.name == null ? null : n.name) && o.getAttribute(`property`) === (n.property == null ? null : n.property) && o.getAttribute(`http-equiv`) === (n.httpEquiv == null ? null : n.httpEquiv) && o.getAttribute(`charset`) === (n.charSet == null ? null : n.charSet)) {
                                                            s.splice(c, 1);
                                                            break b
                                                        }
                                                }
                                                o = a.createElement(r), Fd(o, r, n), a.head.appendChild(o);
                                                break;
                                            default:
                                                throw Error(i(468, r))
                                        }
                                        o[_t] = e,
                                        kt(o),
                                        r = o
                                    }
                                    e.stateNode = r
                                }
                        else Uf(a, e.type, e.stateNode);
                        else e.stateNode = Lf(a, r, e.memoizedProps);
                        else o === r ? r === null && e.stateNode !== null && Xc(e, e.memoizedProps, n.memoizedProps) : (o === null ? n.stateNode !== null && (n = n.stateNode, n.parentNode.removeChild(n)) : o.count--, r === null ? Uf(a, e.type, e.stateNode) : Lf(a, r, e.memoizedProps))
                    }
                    break;
                case 27:
                    _l(t, e), bl(e), r & 512 && (rl || n === null || Jc(n, n.return)), n !== null && r & 4 && Xc(e, e.memoizedProps, n.memoizedProps);
                    break;
                case 5:
                    if (_l(t, e), bl(e), r & 512 && (rl || n === null || Jc(n, n.return)), e.flags & 32) {
                        a = e.stateNode;
                        try {
                            tn(a, ``)
                        } catch (t) {
                            Z(e, e.return, t)
                        }
                    }
                    r & 4 && e.stateNode != null && (a = e.memoizedProps, Xc(e, a, n === null ? a : n.memoizedProps)), r & 1024 && (il = !0);
                    break;
                case 6:
                    if (_l(t, e), bl(e), r & 4) {
                        if (e.stateNode === null) throw Error(i(162));
                        r = e.memoizedProps, n = e.stateNode;
                        try {
                            n.nodeValue = r
                        } catch (t) {
                            Z(e, e.return, t)
                        }
                    }
                    break;
                case 3:
                    if (Vf = null, a = vl, vl = _f(t.containerInfo), _l(t, e), vl = a, bl(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try {
                        Pp(t.containerInfo)
                    } catch (t) {
                        Z(e, e.return, t)
                    }
                    il && (il = !1, xl(e));
                    break;
                case 4:
                    r = vl, vl = _f(e.stateNode.containerInfo), _l(t, e), bl(e), vl = r;
                    break;
                case 12:
                    _l(t, e), bl(e);
                    break;
                case 31:
                    _l(t, e), bl(e), r & 4 && (r = e.updateQueue, r !== null && (e.updateQueue = null, gl(e, r)));
                    break;
                case 13:
                    _l(t, e), bl(e), e.child.flags & 8192 && e.memoizedState !== null != (n !== null && n.memoizedState !== null) && (eu = Ie()), r & 4 && (r = e.updateQueue, r !== null && (e.updateQueue = null, gl(e, r)));
                    break;
                case 22:
                    a = e.memoizedState !== null;
                    var l = n !== null && n.memoizedState !== null,
                        u = nl,
                        d = rl;
                    if (nl = u || a, rl = d || l, _l(t, e), rl = d, nl = u, bl(e), r & 8192) a: for (t = e.stateNode, t._visibility = a ? t._visibility & -2 : t._visibility | 1, a && (n === null || l || nl || rl || Cl(e)), n = null, t = e;;) {
                        if (t.tag === 5 || t.tag === 26) {
                            if (n === null) {
                                l = n = t;
                                try {
                                    if (o = l.stateNode, a) s = o.style, typeof s.setProperty == `function` ? s.setProperty(`display`, `none`, `important`) : s.display = `none`;
                                    else {
                                        c = l.stateNode;
                                        var f = l.memoizedProps.style,
                                            p = f != null && f.hasOwnProperty(`display`) ? f.display : null;
                                        c.style.display = p == null || typeof p == `boolean` ? `` : (`` + p).trim()
                                    }
                                } catch (e) {
                                    Z(l, l.return, e)
                                }
                            }
                        } else if (t.tag === 6) {
                            if (n === null) {
                                l = t;
                                try {
                                    l.stateNode.nodeValue = a ? `` : l.memoizedProps
                                } catch (e) {
                                    Z(l, l.return, e)
                                }
                            }
                        } else if (t.tag === 18) {
                            if (n === null) {
                                l = t;
                                try {
                                    var m = l.stateNode;
                                    a ? ef(m, !0) : ef(l.stateNode, !1)
                                } catch (e) {
                                    Z(l, l.return, e)
                                }
                            }
                        } else if ((t.tag !== 22 && t.tag !== 23 || t.memoizedState === null || t === e) && t.child !== null) {
                            t.child.return = t, t = t.child;
                            continue
                        }
                        if (t === e) break a;
                        for (; t.sibling === null;) {
                            if (t.return === null || t.return === e) break a;
                            n === t && (n = null), t = t.return
                        }
                        n === t && (n = null), t.sibling.return = t.return, t = t.sibling
                    }
                    r & 4 && (r = e.updateQueue, r !== null && (n = r.retryQueue, n !== null && (r.retryQueue = null, gl(e, n))));
                    break;
                case 19:
                    _l(t, e), bl(e), r & 4 && (r = e.updateQueue, r !== null && (e.updateQueue = null, gl(e, r)));
                    break;
                case 30:
                    break;
                case 21:
                    break;
                default:
                    _l(t, e), bl(e)
            }
        }

        function bl(e) {
            var t = e.flags;
            if (t & 2) {
                try {
                    for (var n, r = e.return; r !== null;) {
                        if (Zc(r)) {
                            n = r;
                            break
                        }
                        r = r.return
                    }
                    if (n == null) throw Error(i(160));
                    switch (n.tag) {
                        case 27:
                            var a = n.stateNode;
                            el(e, Qc(e), a);
                            break;
                        case 5:
                            var o = n.stateNode;
                            n.flags & 32 && (tn(o, ``), n.flags &= -33), el(e, Qc(e), o);
                            break;
                        case 3:
                        case 4:
                            var s = n.stateNode.containerInfo;
                            $c(e, Qc(e), s);
                            break;
                        default:
                            throw Error(i(161))
                    }
                } catch (t) {
                    Z(e, e.return, t)
                }
                e.flags &= -3
            }
            t & 4096 && (e.flags &= -4097)
        }

        function xl(e) {
            if (e.subtreeFlags & 1024)
                for (e = e.child; e !== null;) {
                    var t = e;
                    xl(t), t.tag === 5 && t.flags & 1024 && t.stateNode.reset(), e = e.sibling
                }
        }

        function Sl(e, t) {
            if (t.subtreeFlags & 8772)
                for (t = t.child; t !== null;) cl(e, t.alternate, t), t = t.sibling
        }

        function Cl(e) {
            for (e = e.child; e !== null;) {
                var t = e;
                switch (t.tag) {
                    case 0:
                    case 11:
                    case 14:
                    case 15:
                        Wc(4, t, t.return), Cl(t);
                        break;
                    case 1:
                        Jc(t, t.return);
                        var n = t.stateNode;
                        typeof n.componentWillUnmount == `function` && Kc(t, t.return, n), Cl(t);
                        break;
                    case 27:
                        mf(t.stateNode);
                    case 26:
                    case 5:
                        Jc(t, t.return), Cl(t);
                        break;
                    case 22:
                        t.memoizedState === null && Cl(t);
                        break;
                    case 30:
                        Cl(t);
                        break;
                    default:
                        Cl(t)
                }
                e = e.sibling
            }
        }

        function wl(e, t, n) {
            for (n && = (t.subtreeFlags & 8772) != 0, t = t.child; t !== null;) {
                var r = t.alternate,
                    i = e,
                    a = t,
                    o = a.flags;
                switch (a.tag) {
                    case 0:
                    case 11:
                    case 15:
                        wl(i, a, n), Uc(4, a);
                        break;
                    case 1:
                        if (wl(i, a, n), r = a, i = r.stateNode, typeof i.componentDidMount == `function`) try {
                            i.componentDidMount()
                        } catch (e) {
                            Z(r, r.return, e)
                        }
                        if (r = a, i = r.updateQueue, i !== null) {
                            var s = r.stateNode;
                            try {
                                var c = i.shared.hiddenCallbacks;
                                if (c !== null)
                                    for (i.shared.hiddenCallbacks = null, i = 0; i < c.length; i++) ro(c[i], s)
                            } catch (e) {
                                Z(r, r.return, e)
                            }
                        }
                        n && o & 64 && Gc(a), qc(a, a.return);
                        break;
                    case 27:
                        tl(a);
                    case 26:
                    case 5:
                        wl(i, a, n), n && r === null && o & 4 && Yc(a), qc(a, a.return);
                        break;
                    case 12:
                        wl(i, a, n);
                        break;
                    case 31:
                        wl(i, a, n), n && o & 4 && pl(i, a);
                        break;
                    case 13:
                        wl(i, a, n), n && o & 4 && ml(i, a);
                        break;
                    case 22:
                        a.memoizedState === null && wl(i, a, n), qc(a, a.return);
                        break;
                    case 30:
                        break;
                    default:
                        wl(i, a, n)
                }
                t = t.sibling
            }
        }

        function Tl(e, t) {
            var n = null;
            e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), e = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (e = t.memoizedState.cachePool.pool), e !== n && (e != null && e.refCount++, n != null && ga(n))
        }

        function El(e, t) {
            e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && ga(e))
        }

        function Dl(e, t, n, r) {
            if (t.subtreeFlags & 10256)
                for (t = t.child; t !== null;) Ol(e, t, n, r), t = t.sibling
        }

        function Ol(e, t, n, r) {
            var i = t.flags;
            switch (t.tag) {
                case 0:
                case 11:
                case 15:
                    Dl(e, t, n, r), i & 2048 && Uc(9, t);
                    break;
                case 1:
                    Dl(e, t, n, r);
                    break;
                case 3:
                    Dl(e, t, n, r), i & 2048 && (e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && ga(e)));
                    break;
                case 12:
                    if (i & 2048) {
                        Dl(e, t, n, r), e = t.stateNode;
                        try {
                            var a = t.memoizedProps,
                                o = a.id,
                                s = a.onPostCommit;
                            typeof s == `function` && s(o, t.alternate === null ? `mount` : `update`, e.passiveEffectDuration, -0)
                        } catch (e) {
                            Z(t, t.return, e)
                        }
                    } else Dl(e, t, n, r);
                    break;
                case 31:
                    Dl(e, t, n, r);
                    break;
                case 13:
                    Dl(e, t, n, r);
                    break;
                case 23:
                    break;
                case 22:
                    a = t.stateNode, o = t.alternate, t.memoizedState === null ? a._visibility & 2 ? Dl(e, t, n, r) : (a._visibility |= 2, kl(e, t, n, r, (t.subtreeFlags & 10256) != 0 || !1)) : a._visibility & 2 ? Dl(e, t, n, r) : Al(e, t), i & 2048 && Tl(o, t);
                    break;
                case 24:
                    Dl(e, t, n, r), i & 2048 && El(t.alternate, t);
                    break;
                default:
                    Dl(e, t, n, r)
            }
        }

        function kl(e, t, n, r, i) {
            for (i && = (t.subtreeFlags & 10256) != 0 || !1, t = t.child; t !== null;) {
                var a = e,
                    o = t,
                    s = n,
                    c = r,
                    l = o.flags;
                switch (o.tag) {
                    case 0:
                    case 11:
                    case 15:
                        kl(a, o, s, c, i), Uc(8, o);
                        break;
                    case 23:
                        break;
                    case 22:
                        var u = o.stateNode;
                        o.memoizedState === null ? (u._visibility |= 2, kl(a, o, s, c, i)) : u._visibility & 2 ? kl(a, o, s, c, i) : Al(a, o), i && l & 2048 && Tl(o.alternate, o);
                        break;
                    case 24:
                        kl(a, o, s, c, i), i && l & 2048 && El(o.alternate, o);
                        break;
                    default:
                        kl(a, o, s, c, i)
                }
                t = t.sibling
            }
        }

        function Al(e, t) {
            if (t.subtreeFlags & 10256)
                for (t = t.child; t !== null;) {
                    var n = e,
                        r = t,
                        i = r.flags;
                    switch (r.tag) {
                        case 22:
                            Al(n, r), i & 2048 && Tl(r.alternate, r);
                            break;
                        case 24:
                            Al(n, r), i & 2048 && El(r.alternate, r);
                            break;
                        default:
                            Al(n, r)
                    }
                    t = t.sibling
                }
        }
        var jl = 8192;

        function Ml(e, t, n) {
            if (e.subtreeFlags & jl)
                for (e = e.child; e !== null;) Nl(e, t, n), e = e.sibling
        }

        function Nl(e, t, n) {
            switch (e.tag) {
                case 26:
                    Ml(e, t, n), e.flags & jl && e.memoizedState !== null && Kf(n, vl, e.memoizedState, e.memoizedProps);
                    break;
                case 5:
                    Ml(e, t, n);
                    break;
                case 3:
                case 4:
                    var r = vl;
                    vl = _f(e.stateNode.containerInfo), Ml(e, t, n), vl = r;
                    break;
                case 22:
                    e.memoizedState === null && (r = e.alternate, r !== null && r.memoizedState !== null ? (r = jl, jl = 16777216, Ml(e, t, n), jl = r) : Ml(e, t, n));
                    break;
                default:
                    Ml(e, t, n)
            }
        }

        function Pl(e) {
            var t = e.alternate;
            if (t !== null && (e = t.child, e !== null)) {
                t.child = null;
                do t = e.sibling, e.sibling = null, e = t; while (e !== null)
            }
        }

        function Fl(e) {
            var t = e.deletions;
            if (e.flags & 16) {
                if (t !== null)
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        ol = r, Rl(r, e)
                    }
                Pl(e)
            }
            if (e.subtreeFlags & 10256)
                for (e = e.child; e !== null;) Il(e), e = e.sibling
        }

        function Il(e) {
            switch (e.tag) {
                case 0:
                case 11:
                case 15:
                    Fl(e), e.flags & 2048 && Wc(9, e, e.return);
                    break;
                case 3:
                    Fl(e);
                    break;
                case 12:
                    Fl(e);
                    break;
                case 22:
                    var t = e.stateNode;
                    e.memoizedState !== null && t._visibility & 2 && (e.return === null || e.return.tag !== 13) ? (t._visibility &= -3, Ll(e)) : Fl(e);
                    break;
                default:
                    Fl(e)
            }
        }

        function Ll(e) {
            var t = e.deletions;
            if (e.flags & 16) {
                if (t !== null)
                    for (var n = 0; n < t.length; n++) {
                        var r = t[n];
                        ol = r, Rl(r, e)
                    }
                Pl(e)
            }
            for (e = e.child; e !== null;) {
                switch (t = e, t.tag) {
                    case 0:
                    case 11:
                    case 15:
                        Wc(8, t, t.return), Ll(t);
                        break;
                    case 22:
                        n = t.stateNode, n._visibility & 2 && (n._visibility &= -3, Ll(t));
                        break;
                    default:
                        Ll(t)
                }
                e = e.sibling
            }
        }

        function Rl(e, t) {
            for (; ol !== null;) {
                var n = ol;
                switch (n.tag) {
                    case 0:
                    case 11:
                    case 15:
                        Wc(8, n, t);
                        break;
                    case 23:
                    case 22:
                        if (n.memoizedState !== null && n.memoizedState.cachePool !== null) {
                            var r = n.memoizedState.cachePool.pool;
                            r != null && r.refCount++
                        }
                        break;
                    case 24:
                        ga(n.memoizedState.cache)
                }
                if (r = n.child, r !== null) r.return = n, ol = r;
                else a: for (n = e; ol !== null;) {
                    r = ol;
                    var i = r.sibling,
                        a = r.return;
                    if (ll(r), r === n) {
                        ol = null;
                        break a
                    }
                    if (i !== null) {
                        i.return = a, ol = i;
                        break a
                    }
                    ol = a
                }
            }
        }
        var zl = {
                getCacheForType: function(e) {
                    var t = ca(ma),
                        n = t.data.get(e);
                    return n === void 0 && (n = e(), t.data.set(e, n)), n
                },
                cacheSignal: function() {
                    return ca(ma).controller.signal
                }
            },
            Bl = typeof WeakMap == `function` ? WeakMap : Map,
            G = 0,
            K = null,
            q = null,
            J = 0,
            Y = 0,
            Vl = null,
            Hl = !1,
            Ul = !1,
            Wl = !1,
            Gl = 0,
            X = 0,
            Kl = 0,
            ql = 0,
            Jl = 0,
            Yl = 0,
            Xl = 0,
            Zl = null,
            Ql = null,
            $l = !1,
            eu = 0,
            tu = 0,
            nu = 1 / 0,
            ru = null,
            iu = null,
            au = 0,
            ou = null,
            su = null,
            cu = 0,
            lu = 0,
            uu = null,
            du = null,
            fu = 0,
            pu = null;

        function mu() {
            return G & 2 && J !== 0 ? J & -J : w.T === null ? mt() : fd()
        }

        function hu() {
            if (Yl === 0)
                if (!(J & 536870912) || N) {
                    var e = $e;
                    $e <<= 1, !($e & 3932160) && ($e = 262144), Yl = e
                } else Yl = 536870912;
            return e = uo.current, e !== null && (e.flags |= 32), Yl
        }

        function gu(e, t, n) {
            (e === K && (Y === 2 || Y === 9) || e.cancelPendingCommit !== null) && (Cu(e, 0), bu(e, J, Yl, !1)), st(e, n), (!(G & 2) || e !== K) && (e === K && (!(G & 2) && (ql |= n), X === 4 && bu(e, J, Yl, !1)), id(e))
        }

        function _u(e, t, n) {
            if (G & 6) throw Error(i(327));
            var r = !n && (t & 127) == 0 && (t & e.expiredLanes) === 0 || rt(e, t),
                a = r ? ju(e, t) : ku(e, t, !0),
                o = r;
            do {
                if (a === 0) {
                    Ul && !r && bu(e, t, 0, !1);
                    break
                } else {
                    if (n = e.current.alternate, o && !yu(n)) {
                        a = ku(e, t, !1), o = !1;
                        continue
                    }
                    if (a === 2) {
                        if (o = t, e.errorRecoveryDisabledLanes & o) var s = 0;
                        else s = e.pendingLanes & -536870913, s = s === 0 ? s & 536870912 ? 536870912 : 0 : s;
                        if (s !== 0) {
                            t = s;
                            a: {
                                var c = e;a = Zl;
                                var l = c.current.memoizedState.isDehydrated;
                                if (l && (Cu(c, s).flags |= 256), s = ku(c, s, !1), s !== 2) {
                                    if (Wl && !l) {
                                        c.errorRecoveryDisabledLanes |= o, ql |= o, a = 4;
                                        break a
                                    }
                                    o = Ql, Ql = a, o !== null && (Ql === null ? Ql = o : Ql.push.apply(Ql, o))
                                }
                                a = s
                            }
                            if (o = !1, a !== 2) continue
                        }
                    }
                    if (a === 1) {
                        Cu(e, 0), bu(e, t, 0, !0);
                        break
                    }
                    a: {
                        switch (r = e, o = a, o) {
                            case 0:
                            case 1:
                                throw Error(i(345));
                            case 4:
                                if ((t & 4194048) !== t) break;
                            case 6:
                                bu(r, t, Yl, !Hl);
                                break a;
                            case 2:
                                Ql = null;
                                break;
                            case 3:
                            case 5:
                                break;
                            default:
                                throw Error(i(329))
                        }
                        if ((t & 62914560) === t && (a = eu + 300 - Ie(), 10 < a)) {
                            if (bu(r, t, Yl, !Hl), nt(r, 0, !0) !== 0) break a;
                            cu = t, r.timeoutHandle = qd(vu.bind(null, r, n, Ql, ru, $l, t, Yl, ql, Xl, Hl, o, `Throttled`, -0, 0), a);
                            break a
                        }
                        vu(r, n, Ql, ru, $l, t, Yl, ql, Xl, Hl, o, null, -0, 0)
                    }
                }
                break
            } while (1);
            id(e)
        }

        function vu(e, t, n, r, i, a, o, s, c, l, u, d, f, p) {
            if (e.timeoutHandle = -1, d = t.subtreeFlags, d & 8192 || (d & 16785408) == 16785408) {
                d = {
                    stylesheets: null,
                    count: 0,
                    imgCount: 0,
                    imgBytes: 0,
                    suspenseyImages: [],
                    waitingForImages: !0,
                    waitingForViewTransition: !1,
                    unsuspend: un
                }, Nl(t, a, d);
                var m = (a & 62914560) === a ? eu - Ie() : (a & 4194048) === a ? tu - Ie() : 0;
                if (m = Jf(d, m), m !== null) {
                    cu = a, e.cancelPendingCommit = m(Ru.bind(null, e, t, a, n, r, i, o, s, c, u, d, null, f, p)), bu(e, a, o, !l);
                    return
                }
            }
            Ru(e, t, a, n, r, i, o, s, c)
        }

        function yu(e) {
            for (var t = e;;) {
                var n = t.tag;
                if ((n === 0 || n === 11 || n === 15) && t.flags & 16384 && (n = t.updateQueue, n !== null && (n = n.stores, n !== null)))
                    for (var r = 0; r < n.length; r++) {
                        var i = n[r],
                            a = i.getSnapshot;
                        i = i.value;
                        try {
                            if (!Ar(a(), i)) return !1
                        } catch {
                            return !1
                        }
                    }
                if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
                else {
                    if (t === e) break;
                    for (; t.sibling === null;) {
                        if (t.return === null || t.return === e) return !0;
                        t = t.return
                    }
                    t.sibling.return = t.return, t = t.sibling
                }
            }
            return !0
        }

        function bu(e, t, n, r) {
            t &= ~Jl, t &= ~ql, e.suspendedLanes |= t, e.pingedLanes &= ~t, r && (e.warmLanes |= t), r = e.expirationTimes;
            for (var i = t; 0 < i;) {
                var a = 31 - Je(i),
                    o = 1 << a;
                r[a] = -1, i &= ~o
            }
            n !== 0 && lt(e, n, t)
        }

        function xu() {
            return G & 6 ? !0 : (ad(0, !1), !1)
        }

        function Su() {
            if (q !== null) {
                if (Y === 0) var e = q.return;
                else e = q, ea = $i = null, Fo(e), za = null, Ba = 0, e = q;
                for (; e !== null;) Hc(e.alternate, e), e = e.return;
                q = null
            }
        }

        function Cu(e, t) {
            var n = e.timeoutHandle;
            n !== -1 && (e.timeoutHandle = -1, Jd(n)), n = e.cancelPendingCommit, n !== null && (e.cancelPendingCommit = null, n()), cu = 0, Su(), K = e, q = n = vi(e.current, null), J = t, Y = 0, Vl = null, Hl = !1, Ul = rt(e, t), Wl = !1, Xl = Yl = Jl = ql = Kl = X = 0, Ql = Zl = null, $l = !1, t & 8 && (t |= t & 32);
            var r = e.entangledLanes;
            if (r !== 0)
                for (e = e.entanglements, r &= t; 0 < r;) {
                    var i = 31 - Je(r),
                        a = 1 << i;
                    t |= e[i], r &= ~a
                }
            return Gl = t, ci(), n
        }

        function wu(e, t) {
            F = null, w.H = Vs, t === ka || t === ja ? (t = La(), Y = 3) : t === Aa ? (t = La(), Y = 4) : Y = t === ic ? 8 : typeof t == `object` && t && typeof t.then == `function` ? 6 : 1, Vl = t, q === null && (X = 1, H(e, Ei(t, e.current)))
        }

        function Tu() {
            var e = uo.current;
            return e === null ? !0 : (J & 4194048) === J ? fo === null : (J & 62914560) === J || J & 536870912 ? e === fo : !1
        }

        function Eu() {
            var e = w.H;
            return w.H = Vs, e === null ? Vs : e
        }

        function Du() {
            var e = w.A;
            return w.A = zl, e
        }

        function Ou() {
            X = 4, Hl || (J & 4194048) !== J && uo.current !== null || (Ul = !0), !(Kl & 134217727) && !(ql & 134217727) || K === null || bu(K, J, Yl, !1)
        }

        function ku(e, t, n) {
            var r = G;
            G |= 2;
            var i = Eu(),
                a = Du();
            (K !== e || J !== t) && (ru = null, Cu(e, t)), t = !1;
            var o = X;
            a: do try {
                    if (Y !== 0 && q !== null) {
                        var s = q,
                            c = Vl;
                        switch (Y) {
                            case 8:
                                Su(), o = 6;
                                break a;
                            case 3:
                            case 2:
                            case 9:
                            case 6:
                                uo.current === null && (t = !0);
                                var l = Y;
                                if (Y = 0, Vl = null, Fu(e, s, c, l), n && Ul) {
                                    o = 0;
                                    break a
                                }
                                break;
                            default:
                                l = Y, Y = 0, Vl = null, Fu(e, s, c, l)
                        }
                    }
                    Au(), o = X;
                    break
                } catch (t) {
                    wu(e, t)
                }
                while (1);
                return t && e.shellSuspendCounter++, ea = $i = null, G = r, w.H = i, w.A = a, q === null && (K = null, J = 0, ci()), o
        }

        function Au() {
            for (; q !== null;) Nu(q)
        }

        function ju(e, t) {
            var n = G;
            G |= 2;
            var r = Eu(),
                a = Du();
            K !== e || J !== t ? (ru = null, nu = Ie() + 500, Cu(e, t)) : Ul = rt(e, t);
            a: do try {
                    if (Y !== 0 && q !== null) {
                        t = q;
                        var o = Vl;
                        b: switch (Y) {
                            case 1:
                                Y = 0, Vl = null, Fu(e, t, o, 1);
                                break;
                            case 2:
                            case 9:
                                if (Na(o)) {
                                    Y = 0, Vl = null, Pu(t);
                                    break
                                }
                                t = function() {
                                    Y !== 2 && Y !== 9 || K !== e || (Y = 7), id(e)
                                }, o.then(t, t);
                                break a;
                            case 3:
                                Y = 7;
                                break a;
                            case 4:
                                Y = 5;
                                break a;
                            case 7:
                                Na(o) ? (Y = 0, Vl = null, Pu(t)) : (Y = 0, Vl = null, Fu(e, t, o, 7));
                                break;
                            case 5:
                                var s = null;
                                switch (q.tag) {
                                    case 26:
                                        s = q.memoizedState;
                                    case 5:
                                    case 27:
                                        var c = q;
                                        if (s ? Gf(s) : c.stateNode.complete) {
                                            Y = 0, Vl = null;
                                            var l = c.sibling;
                                            if (l !== null) q = l;
                                            else {
                                                var u = c.return;
                                                u === null ? q = null : (q = u, Iu(u))
                                            }
                                            break b
                                        }
                                }
                                Y = 0, Vl = null, Fu(e, t, o, 5);
                                break;
                            case 6:
                                Y = 0, Vl = null, Fu(e, t, o, 6);
                                break;
                            case 8:
                                Su(), X = 6;
                                break a;
                            default:
                                throw Error(i(462))
                        }
                    }
                    Mu();
                    break
                } catch (t) {
                    wu(e, t)
                }
                while (1);
                return ea = $i = null, w.H = r, w.A = a, G = n, q === null ? (K = null, J = 0, ci(), X) : 0
        }

        function Mu() {
            for (; q !== null && !Pe();) Nu(q)
        }

        function Nu(e) {
            var t = Pc(e.alternate, e, Gl);
            e.memoizedProps = e.pendingProps, t === null ? Iu(e) : q = t
        }

        function Pu(e) {
            var t = e,
                n = t.alternate;
            switch (t.tag) {
                case 15:
                case 0:
                    t = vc(n, t, t.pendingProps, t.type, void 0, J);
                    break;
                case 11:
                    t = vc(n, t, t.pendingProps, t.type.render, t.ref, J);
                    break;
                case 5:
                    Fo(t);
                default:
                    Hc(n, t), t = q = yi(t, Gl), t = Pc(n, t, Gl)
            }
            e.memoizedProps = e.pendingProps, t === null ? Iu(e) : q = t
        }

        function Fu(e, t, n, r) {
            ea = $i = null, Fo(t), za = null, Ba = 0;
            var i = t.return;
            try {
                if (rc(e, i, t, n, J)) {
                    X = 1, H(e, Ei(n, e.current)), q = null;
                    return
                }
            } catch (t) {
                if (i !== null) throw q = i, t;
                X = 1, H(e, Ei(n, e.current)), q = null;
                return
            }
            t.flags & 32768 ? (N || r === 1 ? e = !0 : Ul || J & 536870912 ? e = !1 : (Hl = e = !0, (r === 2 || r === 9 || r === 3 || r === 6) && (r = uo.current, r !== null && r.tag === 13 && (r.flags |= 16384))), Lu(t, e)) : Iu(t)
        }

        function Iu(e) {
            var t = e;
            do {
                if (t.flags & 32768) {
                    Lu(t, Hl);
                    return
                }
                e = t.return;
                var n = Bc(t.alternate, t, Gl);
                if (n !== null) {
                    q = n;
                    return
                }
                if (t = t.sibling, t !== null) {
                    q = t;
                    return
                }
                q = t = e
            } while (t !== null);
            X === 0 && (X = 5)
        }

        function Lu(e, t) {
            do {
                var n = Vc(e.alternate, e);
                if (n !== null) {
                    n.flags &= 32767, q = n;
                    return
                }
                if (n = e.return, n !== null && (n.flags |= 32768, n.subtreeFlags = 0, n.deletions = null), !t && (e = e.sibling, e !== null)) {
                    q = e;
                    return
                }
                q = e = n
            } while (e !== null);
            X = 6, q = null
        }

        function Ru(e, t, n, r, a, o, s, c, l) {
            e.cancelPendingCommit = null;
            do Uu(); while (au !== 0);
            if (G & 6) throw Error(i(327));
            if (t !== null) {
                if (t === e.current) throw Error(i(177));
                if (o = t.lanes | t.childLanes, o |= si, ct(e, n, o, s, c, l), e === K && (q = K = null, J = 0), su = t, ou = e, cu = n, lu = o, uu = a, du = r, t.subtreeFlags & 10256 || t.flags & 10256 ? (e.callbackNode = null, e.callbackPriority = 0, Zu(Be, function() {
                        return Wu(), null
                    })) : (e.callbackNode = null, e.callbackPriority = 0), r = (t.flags & 13878) != 0, t.subtreeFlags & 13878 || r) {
                    r = w.T, w.T = null, a = E.p, E.p = 2, s = G, G |= 4;
                    try {
                        sl(e, t, n)
                    } finally {
                        G = s, E.p = a, w.T = r
                    }
                }
                au = 1, zu(), Bu(), Vu()
            }
        }

        function zu() {
            if (au === 1) {
                au = 0;
                var e = ou,
                    t = su,
                    n = (t.flags & 13878) != 0;
                if (t.subtreeFlags & 13878 || n) {
                    n = w.T, w.T = null;
                    var r = E.p;
                    E.p = 2;
                    var i = G;
                    G |= 4;
                    try {
                        yl(t, e);
                        var a = Bd,
                            o = Fr(e.containerInfo),
                            s = a.focusedElem,
                            c = a.selectionRange;
                        if (o !== s && s && s.ownerDocument && Pr(s.ownerDocument.documentElement, s)) {
                            if (c !== null && Ir(s)) {
                                var l = c.start,
                                    u = c.end;
                                if (u === void 0 && (u = l), `selectionStart` in s) s.selectionStart = l, s.selectionEnd = Math.min(u, s.value.length);
                                else {
                                    var d = s.ownerDocument || document,
                                        f = d && d.defaultView || window;
                                    if (f.getSelection) {
                                        var p = f.getSelection(),
                                            m = s.textContent.length,
                                            h = Math.min(c.start, m),
                                            g = c.end === void 0 ? h : Math.min(c.end, m);
                                        !p.extend && h > g && (o = g, g = h, h = o);
                                        var _ = Nr(s, h),
                                            v = Nr(s, g);
                                        if (_ && v && (p.rangeCount !== 1 || p.anchorNode !== _.node || p.anchorOffset !== _.offset || p.focusNode !== v.node || p.focusOffset !== v.offset)) {
                                            var y = d.createRange();
                                            y.setStart(_.node, _.offset), p.removeAllRanges(), h > g ? (p.addRange(y), p.extend(v.node, v.offset)) : (y.setEnd(v.node, v.offset), p.addRange(y))
                                        }
                                    }
                                }
                            }
                            for (d = [], p = s; p = p.parentNode;) p.nodeType === 1 && d.push({
                                element: p,
                                left: p.scrollLeft,
                                top: p.scrollTop
                            });
                            for (typeof s.focus == `function` && s.focus(), s = 0; s < d.length; s++) {
                                var b = d[s];
                                b.element.scrollLeft = b.left, b.element.scrollTop = b.top
                            }
                        }
                        cp = !!zd, Bd = zd = null
                    } finally {
                        G = i, E.p = r, w.T = n
                    }
                }
                e.current = t, au = 2
            }
        }

        function Bu() {
            if (au === 2) {
                au = 0;
                var e = ou,
                    t = su,
                    n = (t.flags & 8772) != 0;
                if (t.subtreeFlags & 8772 || n) {
                    n = w.T, w.T = null;
                    var r = E.p;
                    E.p = 2;
                    var i = G;
                    G |= 4;
                    try {
                        cl(e, t.alternate, t)
                    } finally {
                        G = i, E.p = r, w.T = n
                    }
                }
                au = 3
            }
        }

        function Vu() {
            if (au === 4 || au === 3) {
                au = 0, Fe();
                var e = ou,
                    t = su,
                    n = cu,
                    r = du;
                t.subtreeFlags & 10256 || t.flags & 10256 ? au = 5 : (au = 0, su = ou = null, Hu(e, e.pendingLanes));
                var i = e.pendingLanes;
                if (i === 0 && (iu = null), pt(n), t = t.stateNode, Ke && typeof Ke.onCommitFiberRoot == `function`) try {
                    Ke.onCommitFiberRoot(Ge, t, void 0, (t.current.flags & 128) == 128)
                } catch {}
                if (r !== null) {
                    t = w.T, i = E.p, E.p = 2, w.T = null;
                    try {
                        for (var a = e.onRecoverableError, o = 0; o < r.length; o++) {
                            var s = r[o];
                            a(s.value, {
                                componentStack: s.stack
                            })
                        }
                    } finally {
                        w.T = t, E.p = i
                    }
                }
                cu & 3 && Uu(), id(e), i = e.pendingLanes, n & 261930 && i & 42 ? e === pu ? fu++ : (fu = 0, pu = e) : fu = 0, ad(0, !1)
            }
        }

        function Hu(e, t) {
            (e.pooledCacheLanes &= t) === 0 && (t = e.pooledCache, t != null && (e.pooledCache = null, ga(t)))
        }

        function Uu() {
            return zu(), Bu(), Vu(), Wu()
        }

        function Wu() {
            if (au !== 5) return !1;
            var e = ou,
                t = lu;
            lu = 0;
            var n = pt(cu),
                r = w.T,
                a = E.p;
            try {
                E.p = 32 > n ? 32 : n, w.T = null, n = uu, uu = null;
                var o = ou,
                    s = cu;
                if (au = 0, su = ou = null, cu = 0, G & 6) throw Error(i(331));
                var c = G;
                if (G |= 4, Il(o.current), Ol(o, o.current, s, n), G = c, ad(0, !1), Ke && typeof Ke.onPostCommitFiberRoot == `function`) try {
                    Ke.onPostCommitFiberRoot(Ge, o)
                } catch {}
                return !0
            } finally {
                E.p = a, w.T = r, Hu(e, t)
            }
        }

        function Gu(e, t, n) {
            t = Ei(n, t), t = ec(e.stateNode, t, 2), e = Za(e, t, 2), e !== null && (st(e, 2), id(e))
        }

        function Z(e, t, n) {
            if (e.tag === 3) Gu(e, e, n);
            else
                for (; t !== null;) {
                    if (t.tag === 3) {
                        Gu(t, e, n);
                        break
                    } else if (t.tag === 1) {
                        var r = t.stateNode;
                        if (typeof t.type.getDerivedStateFromError == `function` || typeof r.componentDidCatch == `function` && (iu === null || !iu.has(r))) {
                            e = Ei(n, e), n = tc(2), r = Za(t, n, 2), r !== null && (nc(n, r, t, e), st(r, 2), id(r));
                            break
                        }
                    }
                    t = t.return
                }
        }

        function Ku(e, t, n) {
            var r = e.pingCache;
            if (r === null) {
                r = e.pingCache = new Bl;
                var i = new Set;
                r.set(t, i)
            } else i = r.get(t), i === void 0 && (i = new Set, r.set(t, i));
            i.has(n) || (Wl = !0, i.add(n), e = qu.bind(null, e, t, n), t.then(e, e))
        }

        function qu(e, t, n) {
            var r = e.pingCache;
            r !== null && r.delete(t), e.pingedLanes |= e.suspendedLanes & n, e.warmLanes &= ~n, K === e && (J & n) === n && (X === 4 || X === 3 && (J & 62914560) === J && 300 > Ie() - eu ? !(G & 2) && Cu(e, 0) : Jl |= n, Xl === J && (Xl = 0)), id(e)
        }

        function Ju(e, t) {
            t === 0 && (t = at()), e = di(e, t), e !== null && (st(e, t), id(e))
        }

        function Yu(e) {
            var t = e.memoizedState,
                n = 0;
            t !== null && (n = t.retryLane), Ju(e, n)
        }

        function Xu(e, t) {
            var n = 0;
            switch (e.tag) {
                case 31:
                case 13:
                    var r = e.stateNode,
                        a = e.memoizedState;
                    a !== null && (n = a.retryLane);
                    break;
                case 19:
                    r = e.stateNode;
                    break;
                case 22:
                    r = e.stateNode._retryCache;
                    break;
                default:
                    throw Error(i(314))
            }
            r !== null && r.delete(t), Ju(e, n)
        }

        function Zu(e, t) {
            return Me(e, t)
        }
        var Qu = null,
            $u = null,
            ed = !1,
            td = !1,
            nd = !1,
            rd = 0;

        function id(e) {
            e !== $u && e.next === null && ($u === null ? Qu = $u = e : $u = $u.next = e), td = !0, ed || (ed = !0, dd())
        }

        function ad(e, t) {
            if (!nd && td) {
                nd = !0;
                do
                    for (var n = !1, r = Qu; r !== null;) {
                        if (!t)
                            if (e !== 0) {
                                var i = r.pendingLanes;
                                if (i === 0) var a = 0;
                                else {
                                    var o = r.suspendedLanes,
                                        s = r.pingedLanes;
                                    a = (1 << 31 - Je(42 | e) + 1) - 1, a &= i & ~(o & ~s), a = a & 201326741 ? a & 201326741 | 1 : a ? a | 2 : 0
                                }
                                a !== 0 && (n = !0, ud(r, a))
                            } else a = J, a = nt(r, r === K ? a : 0, r.cancelPendingCommit !== null || r.timeoutHandle !== -1), !(a & 3) || rt(r, a) || (n = !0, ud(r, a));
                        r = r.next
                    }
                while (n);
                nd = !1
            }
        }

        function od() {
            sd()
        }

        function sd() {
            td = ed = !1;
            var e = 0;
            rd !== 0 && Kd() && (e = rd);
            for (var t = Ie(), n = null, r = Qu; r !== null;) {
                var i = r.next,
                    a = cd(r, t);
                a === 0 ? (r.next = null, n === null ? Qu = i : n.next = i, i === null && ($u = n)) : (n = r, (e !== 0 || a & 3) && (td = !0)), r = i
            }
            au !== 0 && au !== 5 || ad(e, !1), rd !== 0 && (rd = 0)
        }

        function cd(e, t) {
            for (var n = e.suspendedLanes, r = e.pingedLanes, i = e.expirationTimes, a = e.pendingLanes & -62914561; 0 < a;) {
                var o = 31 - Je(a),
                    s = 1 << o,
                    c = i[o];
                c === -1 ? ((s & n) === 0 || (s & r) !== 0) && (i[o] = it(s, t)) : c <= t && (e.expiredLanes |= s), a &= ~s
            }
            if (t = K, n = J, n = nt(e, e === t ? n : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), r = e.callbackNode, n === 0 || e === t && (Y === 2 || Y === 9) || e.cancelPendingCommit !== null) return r !== null && r !== null && Ne(r), e.callbackNode = null, e.callbackPriority = 0;
            if (!(n & 3) || rt(e, n)) {
                if (t = n & -n, t === e.callbackPriority) return t;
                switch (r !== null && Ne(r), pt(n)) {
                    case 2:
                    case 8:
                        n = ze;
                        break;
                    case 32:
                        n = Be;
                        break;
                    case 268435456:
                        n = He;
                        break;
                    default:
                        n = Be
                }
                return r = ld.bind(null, e), n = Me(n, r), e.callbackPriority = t, e.callbackNode = n, t
            }
            return r !== null && r !== null && Ne(r), e.callbackPriority = 2, e.callbackNode = null, 2
        }

        function ld(e, t) {
            if (au !== 0 && au !== 5) return e.callbackNode = null, e.callbackPriority = 0, null;
            var n = e.callbackNode;
            if (Uu() && e.callbackNode !== n) return null;
            var r = J;
            return r = nt(e, e === K ? r : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), r === 0 ? null : (_u(e, r, t), cd(e, Ie()), e.callbackNode != null && e.callbackNode === n ? ld.bind(null, e) : null)
        }

        function ud(e, t) {
            if (Uu()) return null;
            _u(e, t, !0)
        }

        function dd() {
            Xd(function() {
                G & 6 ? Me(Re, od) : sd()
            })
        }

        function fd() {
            if (rd === 0) {
                var e = ya;
                e === 0 && (e = Qe, Qe <<= 1, !(Qe & 261888) && (Qe = 256)), rd = e
            }
            return rd
        }

        function pd(e) {
            return e == null || typeof e == `symbol` || typeof e == `boolean` ? null : typeof e == `function` ? e : ln(`` + e)
        }

        function md(e, t) {
            var n = t.ownerDocument.createElement(`input`);
            return n.name = t.name, n.value = t.value, e.id && n.setAttribute(`form`, e.id), t.parentNode.insertBefore(n, t), e = new FormData(e), n.parentNode.removeChild(n), e
        }

        function hd(e, t, n, r, i) {
            if (t === `submit` && n && n.stateNode === i) {
                var a = pd((i[k] || null).action),
                    o = r.submitter;
                o && (t = (t = o[k] || null) ? pd(t.formAction) : o.getAttribute(`formAction`), t !== null && (a = t, o = null));
                var s = new jn(`action`, `action`, null, r, i);
                e.push({
                    event: s,
                    listeners: [{
                        instance: null,
                        listener: function() {
                            if (r.defaultPrevented) {
                                if (rd !== 0) {
                                    var e = o ? md(i, o) : new FormData(i);
                                    Os(n, {
                                        pending: !0,
                                        data: e,
                                        method: i.method,
                                        action: a
                                    }, null, e)
                                }
                            } else typeof a == `function` && (s.preventDefault(), e = o ? md(i, o) : new FormData(i), Os(n, {
                                pending: !0,
                                data: e,
                                method: i.method,
                                action: a
                            }, a, e))
                        },
                        currentTarget: i
                    }]
                })
            }
        }
        for (var gd = 0; gd < ni.length; gd++) {
            var _d = ni[gd];
            ri(_d.toLowerCase(), `on` + (_d[0].toUpperCase() + _d.slice(1)))
        }
        ri(Jr, `onAnimationEnd`), ri(Yr, `onAnimationIteration`), ri(Xr, `onAnimationStart`), ri(`dblclick`, `onDoubleClick`), ri(`focusin`, `onFocus`), ri(`focusout`, `onBlur`), ri(Zr, `onTransitionRun`), ri(Qr, `onTransitionStart`), ri($r, `onTransitionCancel`), ri(ei, `onTransitionEnd`), Nt(`onMouseEnter`, [`mouseout`, `mouseover`]), Nt(`onMouseLeave`, [`mouseout`, `mouseover`]), Nt(`onPointerEnter`, [`pointerout`, `pointerover`]), Nt(`onPointerLeave`, [`pointerout`, `pointerover`]), Mt(`onChange`, `change click focusin focusout input keydown keyup selectionchange`.split(` `)), Mt(`onSelect`, `focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)), Mt(`onBeforeInput`, [`compositionend`, `keypress`, `textInput`, `paste`]), Mt(`onCompositionEnd`, `compositionend focusout keydown keypress keyup mousedown`.split(` `)), Mt(`onCompositionStart`, `compositionstart focusout keydown keypress keyup mousedown`.split(` `)), Mt(`onCompositionUpdate`, `compositionupdate focusout keydown keypress keyup mousedown`.split(` `));
        var vd = `abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `),
            yd = new Set(`beforetoggle cancel close invalid load scroll scrollend toggle`.split(` `).concat(vd));

        function bd(e, t) {
            t = (t & 4) != 0;
            for (var n = 0; n < e.length; n++) {
                var r = e[n],
                    i = r.event;
                r = r.listeners;
                a: {
                    var a = void 0;
                    if (t)
                        for (var o = r.length - 1; 0 <= o; o--) {
                            var s = r[o],
                                c = s.instance,
                                l = s.currentTarget;
                            if (s = s.listener, c !== a && i.isPropagationStopped()) break a;
                            a = s, i.currentTarget = l;
                            try {
                                a(i)
                            } catch (e) {
                                ii(e)
                            }
                            i.currentTarget = null, a = c
                        } else
                            for (o = 0; o < r.length; o++) {
                                if (s = r[o], c = s.instance, l = s.currentTarget, s = s.listener, c !== a && i.isPropagationStopped()) break a;
                                a = s, i.currentTarget = l;
                                try {
                                    a(i)
                                } catch (e) {
                                    ii(e)
                                }
                                i.currentTarget = null, a = c
                            }
                }
            }
        }

        function Q(e, t) {
            var n = t[yt];
            n === void 0 && (n = t[yt] = new Set);
            var r = e + `__bubble`;
            n.has(r) || (wd(t, e, 2, !1), n.add(r))
        }

        function xd(e, t, n) {
            var r = 0;
            t && (r |= 4), wd(n, e, r, t)
        }
        var Sd = `_reactListening` + Math.random().toString(36).slice(2);

        function Cd(e) {
            if (!e[Sd]) {
                e[Sd] = !0, At.forEach(function(t) {
                    t !== `selectionchange` && (yd.has(t) || xd(t, !1, e), xd(t, !0, e))
                });
                var t = e.nodeType === 9 ? e : e.ownerDocument;
                t === null || t[Sd] || (t[Sd] = !0, xd(`selectionchange`, !1, t))
            }
        }

        function wd(e, t, n, r) {
            switch (hp(t)) {
                case 2:
                    var i = lp;
                    break;
                case 8:
                    i = up;
                    break;
                default:
                    i = dp
            }
            n = i.bind(null, t, n, e), i = void 0, !bn || t !== `touchstart` && t !== `touchmove` && t !== `wheel` || (i = !0), r ? i === void 0 ? e.addEventListener(t, n, !0) : e.addEventListener(t, n, {
                capture: !0,
                passive: i
            }) : i === void 0 ? e.addEventListener(t, n, !1) : e.addEventListener(t, n, {
                passive: i
            })
        }

        function Td(e, t, n, r, i) {
            var a = r;
            if (!(t & 1) && !(t & 2) && r !== null) a: for (;;) {
                if (r === null) return;
                var s = r.tag;
                if (s === 3 || s === 4) {
                    var c = r.stateNode.containerInfo;
                    if (c === i) break;
                    if (s === 4)
                        for (s = r.return; s !== null;) {
                            var l = s.tag;
                            if ((l === 3 || l === 4) && s.stateNode.containerInfo === i) return;
                            s = s.return
                        }
                    for (; c !== null;) {
                        if (s = Tt(c), s === null) return;
                        if (l = s.tag, l === 5 || l === 6 || l === 26 || l === 27) {
                            r = a = s;
                            continue a
                        }
                        c = c.parentNode
                    }
                }
                r = r.return
            }
            _n(function() {
                var r = a,
                    i = fn(n),
                    s = [];
                a: {
                    var c = ti.get(e);
                    if (c !== void 0) {
                        var l = jn,
                            u = e;
                        switch (e) {
                            case `keypress`:
                                if (En(n) === 0) break a;
                            case `keydown`:
                            case `keyup`:
                                l = Yn;
                                break;
                            case `focusin`:
                                u = `focus`, l = Bn;
                                break;
                            case `focusout`:
                                u = `blur`, l = Bn;
                                break;
                            case `beforeblur`:
                            case `afterblur`:
                                l = Bn;
                                break;
                            case `click`:
                                if (n.button === 2) break a;
                            case `auxclick`:
                            case `dblclick`:
                            case `mousedown`:
                            case `mousemove`:
                            case `mouseup`:
                            case `mouseout`:
                            case `mouseover`:
                            case `contextmenu`:
                                l = Rn;
                                break;
                            case `drag`:
                            case `dragend`:
                            case `dragenter`:
                            case `dragexit`:
                            case `dragleave`:
                            case `dragover`:
                            case `dragstart`:
                            case `drop`:
                                l = zn;
                                break;
                            case `touchcancel`:
                            case `touchend`:
                            case `touchmove`:
                            case `touchstart`:
                                l = Zn;
                                break;
                            case Jr:
                            case Yr:
                            case Xr:
                                l = Vn;
                                break;
                            case ei:
                                l = Qn;
                                break;
                            case `scroll`:
                            case `scrollend`:
                                l = Nn;
                                break;
                            case `wheel`:
                                l = $n;
                                break;
                            case `copy`:
                            case `cut`:
                            case `paste`:
                                l = Hn;
                                break;
                            case `gotpointercapture`:
                            case `lostpointercapture`:
                            case `pointercancel`:
                            case `pointerdown`:
                            case `pointermove`:
                            case `pointerout`:
                            case `pointerover`:
                            case `pointerup`:
                                l = Xn;
                                break;
                            case `toggle`:
                            case `beforetoggle`:
                                l = er
                        }
                        var d = (t & 4) != 0,
                            f = !d && (e === `scroll` || e === `scrollend`),
                            p = d ? c === null ? null : c + `Capture` : c;
                        d = [];
                        for (var m = r, h; m !== null;) {
                            var g = m;
                            if (h = g.stateNode, g = g.tag, g !== 5 && g !== 26 && g !== 27 || h === null || p === null || (g = vn(m, p), g != null && d.push(Ed(m, g, h))), f) break;
                            m = m.return
                        }
                        0 < d.length && (c = new l(c, u, null, n, i), s.push({
                            event: c,
                            listeners: d
                        }))
                    }
                }
                if (!(t & 7)) {
                    a: {
                        if (c = e === `mouseover` || e === `pointerover`, l = e === `mouseout` || e === `pointerout`, c && n !== dn && (u = n.relatedTarget || n.fromElement) && (Tt(u) || u[vt])) break a;
                        if ((l || c) && (c = i.window === i ? i : (c = i.ownerDocument) ? c.defaultView || c.parentWindow : window, l ? (u = n.relatedTarget || n.toElement, l = r, u = u ? Tt(u) : null, u !== null && (f = o(u), d = u.tag, u !== f || d !== 5 && d !== 27 && d !== 6) && (u = null)) : (l = null, u = r), l !== u)) {
                            if (d = Rn, g = `onMouseLeave`, p = `onMouseEnter`, m = `mouse`, (e === `pointerout` || e === `pointerover`) && (d = Xn, g = `onPointerLeave`, p = `onPointerEnter`, m = `pointer`), f = l == null ? c : Dt(l), h = u == null ? c : Dt(u), c = new d(g, m + `leave`, l, n, i), c.target = f, c.relatedTarget = h, g = null, Tt(i) === r && (d = new d(p, m + `enter`, u, n, i), d.target = h, d.relatedTarget = f, g = d), f = g, l && u) b: {
                                for (d = Od, p = l, m = u, h = 0, g = p; g; g = d(g)) h++;g = 0;
                                for (var _ = m; _; _ = d(_)) g++;
                                for (; 0 < h - g;) p = d(p),
                                h--;
                                for (; 0 < g - h;) m = d(m),
                                g--;
                                for (; h--;) {
                                    if (p === m || m !== null && p === m.alternate) {
                                        d = p;
                                        break b
                                    }
                                    p = d(p), m = d(m)
                                }
                                d = null
                            }
                            else d = null;
                            l !== null && kd(s, c, l, d, !1), u !== null && f !== null && kd(s, f, u, d, !0)
                        }
                    }
                    a: {
                        if (c = r ? Dt(r) : window, l = c.nodeName && c.nodeName.toLowerCase(), l === `select` || l === `input` && c.type === `file`) var v = vr;
                        else if (fr(c))
                            if (yr) v = Or;
                            else {
                                v = Er;
                                var y = Tr
                            }
                        else l = c.nodeName,
                        !l || l.toLowerCase() !== `input` || c.type !== `checkbox` && c.type !== `radio` ? r && on(r.elementType) && (v = vr) : v = Dr;
                        if (v && = v(e, r)) {
                            pr(s, v, n, i);
                            break a
                        }
                        y && y(e, c, r),
                        e === `focusout` && r && c.type === `number` && r.memoizedProps.value != null && Zt(c, `number`, c.value)
                    }
                    switch (y = r ? Dt(r) : window, e) {
                        case `focusin`:
                            (fr(y) || y.contentEditable === `true`) && (Rr = y, zr = r, Br = null);
                            break;
                        case `focusout`:
                            Br = zr = Rr = null;
                            break;
                        case `mousedown`:
                            Vr = !0;
                            break;
                        case `contextmenu`:
                        case `mouseup`:
                        case `dragend`:
                            Vr = !1, Hr(s, n, i);
                            break;
                        case `selectionchange`:
                            if (Lr) break;
                        case `keydown`:
                        case `keyup`:
                            Hr(s, n, i)
                    }
                    var b;
                    if (nr) b: {
                        switch (e) {
                            case `compositionstart`:
                                var x = `onCompositionStart`;
                                break b;
                            case `compositionend`:
                                x = `onCompositionEnd`;
                                break b;
                            case `compositionupdate`:
                                x = `onCompositionUpdate`;
                                break b
                        }
                        x = void 0
                    }
                    else cr ? j(e, n) && (x = `onCompositionEnd`) : e === `keydown` && n.keyCode === 229 && (x = `onCompositionStart`);x && (ir && n.locale !== `ko` && (cr || x !== `onCompositionStart` ? x === `onCompositionEnd` && cr && (b = Tn()) : (Sn = i, Cn = `value` in Sn ? Sn.value : Sn.textContent, cr = !0)), y = Dd(r, x), 0 < y.length && (x = new Un(x, e, null, n, i), s.push({
                        event: x,
                        listeners: y
                    }), b ? x.data = b : (b = sr(n), b !== null && (x.data = b)))),
                    (b = A ? lr(e, n) : ur(e, n)) && (x = Dd(r, `onBeforeInput`), 0 < x.length && (y = new Un(`onBeforeInput`, `beforeinput`, null, n, i), s.push({
                        event: y,
                        listeners: x
                    }), y.data = b)),
                    hd(s, e, r, n, i)
                }
                bd(s, t)
            })
        }

        function Ed(e, t, n) {
            return {
                instance: e,
                listener: t,
                currentTarget: n
            }
        }

        function Dd(e, t) {
            for (var n = t + `Capture`, r = []; e !== null;) {
                var i = e,
                    a = i.stateNode;
                if (i = i.tag, i !== 5 && i !== 26 && i !== 27 || a === null || (i = vn(e, n), i != null && r.unshift(Ed(e, i, a)), i = vn(e, t), i != null && r.push(Ed(e, i, a))), e.tag === 3) return r;
                e = e.return
            }
            return []
        }

        function Od(e) {
            if (e === null) return null;
            do e = e.return; while (e && e.tag !== 5 && e.tag !== 27);
            return e || null
        }

        function kd(e, t, n, r, i) {
            for (var a = t._reactName, o = []; n !== null && n !== r;) {
                var s = n,
                    c = s.alternate,
                    l = s.stateNode;
                if (s = s.tag, c !== null && c === r) break;
                s !== 5 && s !== 26 && s !== 27 || l === null || (c = l, i ? (l = vn(n, a), l != null && o.unshift(Ed(n, l, c))) : i || (l = vn(n, a), l != null && o.push(Ed(n, l, c)))), n = n.return
            }
            o.length !== 0 && e.push({
                event: t,
                listeners: o
            })
        }
        var Ad = /\r\n?/g,
            jd = /\u0000|\uFFFD/g;

        function Md(e) {
            return (typeof e == `string` ? e : `` + e).replace(Ad, `
`).replace(jd, ``)
        }

        function Nd(e, t) {
            return t = Md(t), Md(e) === t
        }

        function $(e, t, n, r, a, o) {
            switch (n) {
                case `children`:
                    typeof r == `string` ? t === `body` || t === `textarea` && r === `` || tn(e, r) : (typeof r == `number` || typeof r == `bigint`) && t !== `body` && tn(e, `` + r);
                    break;
                case `className`:
                    zt(e, `class`, r);
                    break;
                case `tabIndex`:
                    zt(e, `tabindex`, r);
                    break;
                case `dir`:
                case `role`:
                case `viewBox`:
                case `width`:
                case `height`:
                    zt(e, n, r);
                    break;
                case `style`:
                    an(e, r, o);
                    break;
                case `data`:
                    if (t !== `object`) {
                        zt(e, `data`, r);
                        break
                    }
                case `src`:
                case `href`:
                    if (r === `` && (t !== `a` || n !== `href`)) {
                        e.removeAttribute(n);
                        break
                    }
                    if (r == null || typeof r == `function` || typeof r == `symbol` || typeof r == `boolean`) {
                        e.removeAttribute(n);
                        break
                    }
                    r = ln(`` + r), e.setAttribute(n, r);
                    break;
                case `action`:
                case `formAction`:
                    if (typeof r == `function`) {
                        e.setAttribute(n, `javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')`);
                        break
                    } else typeof o == `function` && (n === `formAction` ? (t !== `input` && $(e, t, `name`, a.name, a, null), $(e, t, `formEncType`, a.formEncType, a, null), $(e, t, `formMethod`, a.formMethod, a, null), $(e, t, `formTarget`, a.formTarget, a, null)) : ($(e, t, `encType`, a.encType, a, null), $(e, t, `method`, a.method, a, null), $(e, t, `target`, a.target, a, null)));
                    if (r == null || typeof r == `symbol` || typeof r == `boolean`) {
                        e.removeAttribute(n);
                        break
                    }
                    r = ln(`` + r), e.setAttribute(n, r);
                    break;
                case `onClick`:
                    r != null && (e.onclick = un);
                    break;
                case `onScroll`:
                    r != null && Q(`scroll`, e);
                    break;
                case `onScrollEnd`:
                    r != null && Q(`scrollend`, e);
                    break;
                case `dangerouslySetInnerHTML`:
                    if (r != null) {
                        if (typeof r != `object` || !(`__html` in r)) throw Error(i(61));
                        if (n = r.__html, n != null) {
                            if (a.children != null) throw Error(i(60));
                            e.innerHTML = n
                        }
                    }
                    break;
                case `multiple`:
                    e.multiple = r && typeof r != `function` && typeof r != `symbol`;
                    break;
                case `muted`:
                    e.muted = r && typeof r != `function` && typeof r != `symbol`;
                    break;
                case `suppressContentEditableWarning`:
                case `suppressHydrationWarning`:
                case `defaultValue`:
                case `defaultChecked`:
                case `innerHTML`:
                case `ref`:
                    break;
                case `autoFocus`:
                    break;
                case `xlinkHref`:
                    if (r == null || typeof r == `function` || typeof r == `boolean` || typeof r == `symbol`) {
                        e.removeAttribute(`xlink:href`);
                        break
                    }
                    n = ln(`` + r), e.setAttributeNS(`http://www.w3.org/1999/xlink`, `xlink:href`, n);
                    break;
                case `contentEditable`:
                case `spellCheck`:
                case `draggable`:
                case `value`:
                case `autoReverse`:
                case `externalResourcesRequired`:
                case `focusable`:
                case `preserveAlpha`:
                    r != null && typeof r != `function` && typeof r != `symbol` ? e.setAttribute(n, `` + r) : e.removeAttribute(n);
                    break;
                case `inert`:
                case `allowFullScreen`:
                case `async`:
                case `autoPlay`:
                case `controls`:
                case `default`:
                case `defer`:
                case `disabled`:
                case `disablePictureInPicture`:
                case `disableRemotePlayback`:
                case `formNoValidate`:
                case `hidden`:
                case `loop`:
                case `noModule`:
                case `noValidate`:
                case `open`:
                case `playsInline`:
                case `readOnly`:
                case `required`:
                case `reversed`:
                case `scoped`:
                case `seamless`:
                case `itemScope`:
                    r && typeof r != `function` && typeof r != `symbol` ? e.setAttribute(n, ``) : e.removeAttribute(n);
                    break;
                case `capture`:
                case `download`:
                    !0 === r ? e.setAttribute(n, ``) : !1 !== r && r != null && typeof r != `function` && typeof r != `symbol` ? e.setAttribute(n, r) : e.removeAttribute(n);
                    break;
                case `cols`:
                case `rows`:
                case `size`:
                case `span`:
                    r != null && typeof r != `function` && typeof r != `symbol` && !isNaN(r) && 1 <= r ? e.setAttribute(n, r) : e.removeAttribute(n);
                    break;
                case `rowSpan`:
                case `start`:
                    r == null || typeof r == `function` || typeof r == `symbol` || isNaN(r) ? e.removeAttribute(n) : e.setAttribute(n, r);
                    break;
                case `popover`:
                    Q(`beforetoggle`, e), Q(`toggle`, e), Rt(e, `popover`, r);
                    break;
                case `xlinkActuate`:
                    Bt(e, `http://www.w3.org/1999/xlink`, `xlink:actuate`, r);
                    break;
                case `xlinkArcrole`:
                    Bt(e, `http://www.w3.org/1999/xlink`, `xlink:arcrole`, r);
                    break;
                case `xlinkRole`:
                    Bt(e, `http://www.w3.org/1999/xlink`, `xlink:role`, r);
                    break;
                case `xlinkShow`:
                    Bt(e, `http://www.w3.org/1999/xlink`, `xlink:show`, r);
                    break;
                case `xlinkTitle`:
                    Bt(e, `http://www.w3.org/1999/xlink`, `xlink:title`, r);
                    break;
                case `xlinkType`:
                    Bt(e, `http://www.w3.org/1999/xlink`, `xlink:type`, r);
                    break;
                case `xmlBase`:
                    Bt(e, `http://www.w3.org/XML/1998/namespace`, `xml:base`, r);
                    break;
                case `xmlLang`:
                    Bt(e, `http://www.w3.org/XML/1998/namespace`, `xml:lang`, r);
                    break;
                case `xmlSpace`:
                    Bt(e, `http://www.w3.org/XML/1998/namespace`, `xml:space`, r);
                    break;
                case `is`:
                    Rt(e, `is`, r);
                    break;
                case `innerText`:
                case `textContent`:
                    break;
                default:
                    (!(2 < n.length) || n[0] !== `o` && n[0] !== `O` || n[1] !== `n` && n[1] !== `N`) && (n = sn.get(n) || n, Rt(e, n, r))
            }
        }

        function Pd(e, t, n, r, a, o) {
            switch (n) {
                case `style`:
                    an(e, r, o);
                    break;
                case `dangerouslySetInnerHTML`:
                    if (r != null) {
                        if (typeof r != `object` || !(`__html` in r)) throw Error(i(61));
                        if (n = r.__html, n != null) {
                            if (a.children != null) throw Error(i(60));
                            e.innerHTML = n
                        }
                    }
                    break;
                case `children`:
                    typeof r == `string` ? tn(e, r) : (typeof r == `number` || typeof r == `bigint`) && tn(e, `` + r);
                    break;
                case `onScroll`:
                    r != null && Q(`scroll`, e);
                    break;
                case `onScrollEnd`:
                    r != null && Q(`scrollend`, e);
                    break;
                case `onClick`:
                    r != null && (e.onclick = un);
                    break;
                case `suppressContentEditableWarning`:
                case `suppressHydrationWarning`:
                case `innerHTML`:
                case `ref`:
                    break;
                case `innerText`:
                case `textContent`:
                    break;
                default:
                    if (!jt.hasOwnProperty(n)) a: {
                        if (n[0] === `o` && n[1] === `n` && (a = n.endsWith(`Capture`), t = n.slice(2, a ? n.length - 7 : void 0), o = e[k] || null, o = o == null ? null : o[n], typeof o == `function` && e.removeEventListener(t, o, a), typeof r == `function`)) {
                            typeof o != `function` && o !== null && (n in e ? e[n] = null : e.hasAttribute(n) && e.removeAttribute(n)), e.addEventListener(t, r, a);
                            break a
                        }
                        n in e ? e[n] = r : !0 === r ? e.setAttribute(n, ``) : Rt(e, n, r)
                    }
            }
        }

        function Fd(e, t, n) {
            switch (t) {
                case `div`:
                case `span`:
                case `svg`:
                case `path`:
                case `a`:
                case `g`:
                case `p`:
                case `li`:
                    break;
                case `img`:
                    Q(`error`, e), Q(`load`, e);
                    var r = !1,
                        a = !1,
                        o;
                    for (o in n)
                        if (n.hasOwnProperty(o)) {
                            var s = n[o];
                            if (s != null) switch (o) {
                                case `src`:
                                    r = !0;
                                    break;
                                case `srcSet`:
                                    a = !0;
                                    break;
                                case `children`:
                                case `dangerouslySetInnerHTML`:
                                    throw Error(i(137, t));
                                default:
                                    $(e, t, o, s, n, null)
                            }
                        }
                    a && $(e, t, `srcSet`, n.srcSet, n, null), r && $(e, t, `src`, n.src, n, null);
                    return;
                case `input`:
                    Q(`invalid`, e);
                    var c = o = s = a = null,
                        l = null,
                        u = null;
                    for (r in n)
                        if (n.hasOwnProperty(r)) {
                            var d = n[r];
                            if (d != null) switch (r) {
                                case `name`:
                                    a = d;
                                    break;
                                case `type`:
                                    s = d;
                                    break;
                                case `checked`:
                                    l = d;
                                    break;
                                case `defaultChecked`:
                                    u = d;
                                    break;
                                case `value`:
                                    o = d;
                                    break;
                                case `defaultValue`:
                                    c = d;
                                    break;
                                case `children`:
                                case `dangerouslySetInnerHTML`:
                                    if (d != null) throw Error(i(137, t));
                                    break;
                                default:
                                    $(e, t, r, d, n, null)
                            }
                        }
                    Xt(e, o, c, l, u, s, a, !1);
                    return;
                case `select`:
                    for (a in Q(`invalid`, e), r = s = o = null, n)
                        if (n.hasOwnProperty(a) && (c = n[a], c != null)) switch (a) {
                            case `value`:
                                o = c;
                                break;
                            case `defaultValue`:
                                s = c;
                                break;
                            case `multiple`:
                                r = c;
                            default:
                                $(e, t, a, c, n, null)
                        }
                    t = o, n = s, e.multiple = !!r, t == null ? n != null && Qt(e, !!r, n, !0) : Qt(e, !!r, t, !1);
                    return;
                case `textarea`:
                    for (s in Q(`invalid`, e), o = a = r = null, n)
                        if (n.hasOwnProperty(s) && (c = n[s], c != null)) switch (s) {
                            case `value`:
                                r = c;
                                break;
                            case `defaultValue`:
                                a = c;
                                break;
                            case `children`:
                                o = c;
                                break;
                            case `dangerouslySetInnerHTML`:
                                if (c != null) throw Error(i(91));
                                break;
                            default:
                                $(e, t, s, c, n, null)
                        }
                    en(e, r, a, o);
                    return;
                case `option`:
                    for (l in n)
                        if (n.hasOwnProperty(l) && (r = n[l], r != null)) switch (l) {
                            case `selected`:
                                e.selected = r && typeof r != `function` && typeof r != `symbol`;
                                break;
                            default:
                                $(e, t, l, r, n, null)
                        }
                    return;
                case `dialog`:
                    Q(`beforetoggle`, e), Q(`toggle`, e), Q(`cancel`, e), Q(`close`, e);
                    break;
                case `iframe`:
                case `object`:
                    Q(`load`, e);
                    break;
                case `video`:
                case `audio`:
                    for (r = 0; r < vd.length; r++) Q(vd[r], e);
                    break;
                case `image`:
                    Q(`error`, e), Q(`load`, e);
                    break;
                case `details`:
                    Q(`toggle`, e);
                    break;
                case `embed`:
                case `source`:
                case `link`:
                    Q(`error`, e), Q(`load`, e);
                case `area`:
                case `base`:
                case `br`:
                case `col`:
                case `hr`:
                case `keygen`:
                case `meta`:
                case `param`:
                case `track`:
                case `wbr`:
                case `menuitem`:
                    for (u in n)
                        if (n.hasOwnProperty(u) && (r = n[u], r != null)) switch (u) {
                            case `children`:
                            case `dangerouslySetInnerHTML`:
                                throw Error(i(137, t));
                            default:
                                $(e, t, u, r, n, null)
                        }
                    return;
                default:
                    if (on(t)) {
                        for (d in n) n.hasOwnProperty(d) && (r = n[d], r !== void 0 && Pd(e, t, d, r, n, void 0));
                        return
                    }
            }
            for (c in n) n.hasOwnProperty(c) && (r = n[c], r != null && $(e, t, c, r, n, null))
        }

        function Id(e, t, n, r) {
            switch (t) {
                case `div`:
                case `span`:
                case `svg`:
                case `path`:
                case `a`:
                case `g`:
                case `p`:
                case `li`:
                    break;
                case `input`:
                    var a = null,
                        o = null,
                        s = null,
                        c = null,
                        l = null,
                        u = null,
                        d = null;
                    for (m in n) {
                        var f = n[m];
                        if (n.hasOwnProperty(m) && f != null) switch (m) {
                            case `checked`:
                                break;
                            case `value`:
                                break;
                            case `defaultValue`:
                                l = f;
                            default:
                                r.hasOwnProperty(m) || $(e, t, m, null, r, f)
                        }
                    }
                    for (var p in r) {
                        var m = r[p];
                        if (f = n[p], r.hasOwnProperty(p) && (m != null || f != null)) switch (p) {
                            case `type`:
                                o = m;
                                break;
                            case `name`:
                                a = m;
                                break;
                            case `checked`:
                                u = m;
                                break;
                            case `defaultChecked`:
                                d = m;
                                break;
                            case `value`:
                                s = m;
                                break;
                            case `defaultValue`:
                                c = m;
                                break;
                            case `children`:
                            case `dangerouslySetInnerHTML`:
                                if (m != null) throw Error(i(137, t));
                                break;
                            default:
                                m !== f && $(e, t, p, m, r, f)
                        }
                    }
                    Yt(e, s, c, l, u, d, o, a);
                    return;
                case `select`:
                    for (o in m = s = c = p = null, n)
                        if (l = n[o], n.hasOwnProperty(o) && l != null) switch (o) {
                            case `value`:
                                break;
                            case `multiple`:
                                m = l;
                            default:
                                r.hasOwnProperty(o) || $(e, t, o, null, r, l)
                        }
                    for (a in r)
                        if (o = r[a], l = n[a], r.hasOwnProperty(a) && (o != null || l != null)) switch (a) {
                            case `value`:
                                p = o;
                                break;
                            case `defaultValue`:
                                c = o;
                                break;
                            case `multiple`:
                                s = o;
                            default:
                                o !== l && $(e, t, a, o, r, l)
                        }
                    t = c, n = s, r = m, p == null ? !!r != !!n && (t == null ? Qt(e, !!n, n ? [] : ``, !1) : Qt(e, !!n, t, !0)) : Qt(e, !!n, p, !1);
                    return;
                case `textarea`:
                    for (c in m = p = null, n)
                        if (a = n[c], n.hasOwnProperty(c) && a != null && !r.hasOwnProperty(c)) switch (c) {
                            case `value`:
                                break;
                            case `children`:
                                break;
                            default:
                                $(e, t, c, null, r, a)
                        }
                    for (s in r)
                        if (a = r[s], o = n[s], r.hasOwnProperty(s) && (a != null || o != null)) switch (s) {
                            case `value`:
                                p = a;
                                break;
                            case `defaultValue`:
                                m = a;
                                break;
                            case `children`:
                                break;
                            case `dangerouslySetInnerHTML`:
                                if (a != null) throw Error(i(91));
                                break;
                            default:
                                a !== o && $(e, t, s, a, r, o)
                        }
                    $t(e, p, m);
                    return;
                case `option`:
                    for (var h in n)
                        if (p = n[h], n.hasOwnProperty(h) && p != null && !r.hasOwnProperty(h)) switch (h) {
                            case `selected`:
                                e.selected = !1;
                                break;
                            default:
                                $(e, t, h, null, r, p)
                        }
                    for (l in r)
                        if (p = r[l], m = n[l], r.hasOwnProperty(l) && p !== m && (p != null || m != null)) switch (l) {
                            case `selected`:
                                e.selected = p && typeof p != `function` && typeof p != `symbol`;
                                break;
                            default:
                                $(e, t, l, p, r, m)
                        }
                    return;
                case `img`:
                case `link`:
                case `area`:
                case `base`:
                case `br`:
                case `col`:
                case `embed`:
                case `hr`:
                case `keygen`:
                case `meta`:
                case `param`:
                case `source`:
                case `track`:
                case `wbr`:
                case `menuitem`:
                    for (var g in n) p = n[g], n.hasOwnProperty(g) && p != null && !r.hasOwnProperty(g) && $(e, t, g, null, r, p);
                    for (u in r)
                        if (p = r[u], m = n[u], r.hasOwnProperty(u) && p !== m && (p != null || m != null)) switch (u) {
                            case `children`:
                            case `dangerouslySetInnerHTML`:
                                if (p != null) throw Error(i(137, t));
                                break;
                            default:
                                $(e, t, u, p, r, m)
                        }
                    return;
                default:
                    if (on(t)) {
                        for (var _ in n) p = n[_], n.hasOwnProperty(_) && p !== void 0 && !r.hasOwnProperty(_) && Pd(e, t, _, void 0, r, p);
                        for (d in r) p = r[d], m = n[d], !r.hasOwnProperty(d) || p === m || p === void 0 && m === void 0 || Pd(e, t, d, p, r, m);
                        return
                    }
            }
            for (var v in n) p = n[v], n.hasOwnProperty(v) && p != null && !r.hasOwnProperty(v) && $(e, t, v, null, r, p);
            for (f in r) p = r[f], m = n[f], !r.hasOwnProperty(f) || p === m || p == null && m == null || $(e, t, f, p, r, m)
        }

        function Ld(e) {
            switch (e) {
                case `css`:
                case `script`:
                case `font`:
                case `img`:
                case `image`:
                case `input`:
                case `link`:
                    return !0;
                default:
                    return !1
            }
        }

        function Rd() {
            if (typeof performance.getEntriesByType == `function`) {
                for (var e = 0, t = 0, n = performance.getEntriesByType(`resource`), r = 0; r < n.length; r++) {
                    var i = n[r],
                        a = i.transferSize,
                        o = i.initiatorType,
                        s = i.duration;
                    if (a && s && Ld(o)) {
                        for (o = 0, s = i.responseEnd, r += 1; r < n.length; r++) {
                            var c = n[r],
                                l = c.startTime;
                            if (l > s) break;
                            var u = c.transferSize,
                                d = c.initiatorType;
                            u && Ld(d) && (c = c.responseEnd, o += u * (c < s ? 1 : (s - l) / (c - l)))
                        }
                        if (--r, t += 8 * (a + o) / (i.duration / 1e3), e++, 10 < e) break
                    }
                }
                if (0 < e) return t / e / 1e6
            }
            return navigator.connection && (e = navigator.connection.downlink, typeof e == `number`) ? e : 5
        }
        var zd = null,
            Bd = null;

        function Vd(e) {
            return e.nodeType === 9 ? e : e.ownerDocument
        }

        function Hd(e) {
            switch (e) {
                case `http://www.w3.org/2000/svg`:
                    return 1;
                case `http://www.w3.org/1998/Math/MathML`:
                    return 2;
                default:
                    return 0
            }
        }

        function Ud(e, t) {
            if (e === 0) switch (t) {
                case `svg`:
                    return 1;
                case `math`:
                    return 2;
                default:
                    return 0
            }
            return e === 1 && t === `foreignObject` ? 0 : e
        }

        function Wd(e, t) {
            return e === `textarea` || e === `noscript` || typeof t.children == `string` || typeof t.children == `number` || typeof t.children == `bigint` || typeof t.dangerouslySetInnerHTML == `object` && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
        }
        var Gd = null;

        function Kd() {
            var e = window.event;
            return e && e.type === `popstate` ? e === Gd ? !1 : (Gd = e, !0) : (Gd = null, !1)
        }
        var qd = typeof setTimeout == `function` ? setTimeout : void 0,
            Jd = typeof clearTimeout == `function` ? clearTimeout : void 0,
            Yd = typeof Promise == `function` ? Promise : void 0,
            Xd = typeof queueMicrotask == `function` ? queueMicrotask : Yd === void 0 ? qd : function(e) {
                return Yd.resolve(null).then(e).catch(Zd)
            };

        function Zd(e) {
            setTimeout(function() {
                throw e
            })
        }

        function Qd(e) {
            return e === `head`
        }

        function $d(e, t) {
            var n = t,
                r = 0;
            do {
                var i = n.nextSibling;
                if (e.removeChild(n), i && i.nodeType === 8)
                    if (n = i.data, n === `/$` || n === `/&`) {
                        if (r === 0) {
                            e.removeChild(i), Pp(t);
                            return
                        }
                        r--
                    } else if (n === `$` || n === `$?` || n === `$~` || n === `$!` || n === `&`) r++;
                else if (n === `html`) mf(e.ownerDocument.documentElement);
                else if (n === `head`) {
                    n = e.ownerDocument.head, mf(n);
                    for (var a = n.firstChild; a;) {
                        var o = a.nextSibling,
                            s = a.nodeName;
                        a[Ct] || s === `SCRIPT` || s === `STYLE` || s === `LINK` && a.rel.toLowerCase() === `stylesheet` || n.removeChild(a), a = o
                    }
                } else n === `body` && mf(e.ownerDocument.body);
                n = i
            } while (n);
            Pp(t)
        }

        function ef(e, t) {
            var n = e;
            e = 0;
            do {
                var r = n.nextSibling;
                if (n.nodeType === 1 ? t ? (n._stashedDisplay = n.style.display, n.style.display = `none`) : (n.style.display = n._stashedDisplay || ``, n.getAttribute(`style`) === `` && n.removeAttribute(`style`)) : n.nodeType === 3 && (t ? (n._stashedText = n.nodeValue, n.nodeValue = ``) : n.nodeValue = n._stashedText || ``), r && r.nodeType === 8)
                    if (n = r.data, n === `/$`) {
                        if (e === 0) break;
                        e--
                    } else n !== `$` && n !== `$?` && n !== `$~` && n !== `$!` || e++;
                n = r
            } while (n)
        }

        function tf(e) {
            var t = e.firstChild;
            for (t && t.nodeType === 10 && (t = t.nextSibling); t;) {
                var n = t;
                switch (t = t.nextSibling, n.nodeName) {
                    case `HTML`:
                    case `HEAD`:
                    case `BODY`:
                        tf(n), wt(n);
                        continue;
                    case `SCRIPT`:
                    case `STYLE`:
                        continue;
                    case `LINK`:
                        if (n.rel.toLowerCase() === `stylesheet`) continue
                }
                e.removeChild(n)
            }
        }

        function nf(e, t, n, r) {
            for (; e.nodeType === 1;) {
                var i = n;
                if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
                    if (!r && (e.nodeName !== `INPUT` || e.type !== `hidden`)) break
                } else if (!r)
                    if (t === `input` && e.type === `hidden`) {
                        var a = i.name == null ? null : `` + i.name;
                        if (i.type === `hidden` && e.getAttribute(`name`) === a) return e
                    } else return e;
                else if (!e[Ct]) switch (t) {
                    case `meta`:
                        if (!e.hasAttribute(`itemprop`)) break;
                        return e;
                    case `link`:
                        if (a = e.getAttribute(`rel`), a === `stylesheet` && e.hasAttribute(`data-precedence`) || a !== i.rel || e.getAttribute(`href`) !== (i.href == null || i.href === `` ? null : i.href) || e.getAttribute(`crossorigin`) !== (i.crossOrigin == null ? null : i.crossOrigin) || e.getAttribute(`title`) !== (i.title == null ? null : i.title)) break;
                        return e;
                    case `style`:
                        if (e.hasAttribute(`data-precedence`)) break;
                        return e;
                    case `script`:
                        if (a = e.getAttribute(`src`), (a !== (i.src == null ? null : i.src) || e.getAttribute(`type`) !== (i.type == null ? null : i.type) || e.getAttribute(`crossorigin`) !== (i.crossOrigin == null ? null : i.crossOrigin)) && a && e.hasAttribute(`async`) && !e.hasAttribute(`itemprop`)) break;
                        return e;
                    default:
                        return e
                }
                if (e = lf(e.nextSibling), e === null) break
            }
            return null
        }

        function rf(e, t, n) {
            if (t === ``) return null;
            for (; e.nodeType !== 3;)
                if ((e.nodeType !== 1 || e.nodeName !== `INPUT` || e.type !== `hidden`) && !n || (e = lf(e.nextSibling), e === null)) return null;
            return e
        }

        function af(e, t) {
            for (; e.nodeType !== 8;)
                if ((e.nodeType !== 1 || e.nodeName !== `INPUT` || e.type !== `hidden`) && !t || (e = lf(e.nextSibling), e === null)) return null;
            return e
        }

        function of (e) {
            return e.data === `$?` || e.data === `$~`
        }

        function sf(e) {
            return e.data === `$!` || e.data === `$?` && e.ownerDocument.readyState !== `loading`
        }

        function cf(e, t) {
            var n = e.ownerDocument;
            if (e.data === `$~`) e._reactRetry = t;
            else if (e.data !== `$?` || n.readyState !== `loading`) t();
            else {
                var r = function() {
                    t(), n.removeEventListener(`DOMContentLoaded`, r)
                };
                n.addEventListener(`DOMContentLoaded`, r), e._reactRetry = r
            }
        }

        function lf(e) {
            for (; e != null; e = e.nextSibling) {
                var t = e.nodeType;
                if (t === 1 || t === 3) break;
                if (t === 8) {
                    if (t = e.data, t === `$` || t === `$!` || t === `$?` || t === `$~` || t === `&` || t === `F!` || t === `F`) break;
                    if (t === `/$` || t === `/&`) return null
                }
            }
            return e
        }
        var uf = null;

        function df(e) {
            e = e.nextSibling;
            for (var t = 0; e;) {
                if (e.nodeType === 8) {
                    var n = e.data;
                    if (n === `/$` || n === `/&`) {
                        if (t === 0) return lf(e.nextSibling);
                        t--
                    } else n !== `$` && n !== `$!` && n !== `$?` && n !== `$~` && n !== `&` || t++
                }
                e = e.nextSibling
            }
            return null
        }

        function ff(e) {
            e = e.previousSibling;
            for (var t = 0; e;) {
                if (e.nodeType === 8) {
                    var n = e.data;
                    if (n === `$` || n === `$!` || n === `$?` || n === `$~` || n === `&`) {
                        if (t === 0) return e;
                        t--
                    } else n !== `/$` && n !== `/&` || t++
                }
                e = e.previousSibling
            }
            return null
        }

        function pf(e, t, n) {
            switch (t = Vd(n), e) {
                case `html`:
                    if (e = t.documentElement, !e) throw Error(i(452));
                    return e;
                case `head`:
                    if (e = t.head, !e) throw Error(i(453));
                    return e;
                case `body`:
                    if (e = t.body, !e) throw Error(i(454));
                    return e;
                default:
                    throw Error(i(451))
            }
        }

        function mf(e) {
            for (var t = e.attributes; t.length;) e.removeAttributeNode(t[0]);
            wt(e)
        }
        var hf = new Map,
            gf = new Set;

        function _f(e) {
            return typeof e.getRootNode == `function` ? e.getRootNode() : e.nodeType === 9 ? e : e.ownerDocument
        }
        var vf = E.d;
        E.d = {
            f: yf,
            r: bf,
            D: Cf,
            C: wf,
            L: Tf,
            m: Ef,
            X: Of,
            S: Df,
            M: kf
        };

        function yf() {
            var e = vf.f(),
                t = xu();
            return e || t
        }

        function bf(e) {
            var t = Et(e);
            t !== null && t.tag === 5 && t.type === `form` ? V(t) : vf.r(e)
        }
        var xf = typeof document > `u` ? null : document;

        function Sf(e, t, n) {
            var r = xf;
            if (r && typeof t == `string` && t) {
                var i = Jt(t);
                i = `link[rel="` + e + `"][href="` + i + `"]`, typeof n == `string` && (i += `[crossorigin="` + n + `"]`), gf.has(i) || (gf.add(i), e = {
                    rel: e,
                    crossOrigin: n,
                    href: t
                }, r.querySelector(i) === null && (t = r.createElement(`link`), Fd(t, `link`, e), kt(t), r.head.appendChild(t)))
            }
        }

        function Cf(e) {
            vf.D(e), Sf(`dns-prefetch`, e, null)
        }

        function wf(e, t) {
            vf.C(e, t), Sf(`preconnect`, e, t)
        }

        function Tf(e, t, n) {
            vf.L(e, t, n);
            var r = xf;
            if (r && e && t) {
                var i = `link[rel="preload"][as="` + Jt(t) + `"]`;
                t === `image` && n && n.imageSrcSet ? (i += `[imagesrcset="` + Jt(n.imageSrcSet) + `"]`, typeof n.imageSizes == `string` && (i += `[imagesizes="` + Jt(n.imageSizes) + `"]`)) : i += `[href="` + Jt(e) + `"]`;
                var a = i;
                switch (t) {
                    case `style`:
                        a = jf(e);
                        break;
                    case `script`:
                        a = Ff(e)
                }
                hf.has(a) || (e = h({
                    rel: `preload`,
                    href: t === `image` && n && n.imageSrcSet ? void 0 : e,
                    as: t
                }, n), hf.set(a, e), r.querySelector(i) !== null || t === `style` && r.querySelector(Mf(a)) || t === `script` && r.querySelector(If(a)) || (t = r.createElement(`link`), Fd(t, `link`, e), kt(t), r.head.appendChild(t)))
            }
        }

        function Ef(e, t) {
            vf.m(e, t);
            var n = xf;
            if (n && e) {
                var r = t && typeof t.as == `string` ? t.as : `script`,
                    i = `link[rel="modulepreload"][as="` + Jt(r) + `"][href="` + Jt(e) + `"]`,
                    a = i;
                switch (r) {
                    case `audioworklet`:
                    case `paintworklet`:
                    case `serviceworker`:
                    case `sharedworker`:
                    case `worker`:
                    case `script`:
                        a = Ff(e)
                }
                if (!hf.has(a) && (e = h({
                        rel: `modulepreload`,
                        href: e
                    }, t), hf.set(a, e), n.querySelector(i) === null)) {
                    switch (r) {
                        case `audioworklet`:
                        case `paintworklet`:
                        case `serviceworker`:
                        case `sharedworker`:
                        case `worker`:
                        case `script`:
                            if (n.querySelector(If(a))) return
                    }
                    r = n.createElement(`link`), Fd(r, `link`, e), kt(r), n.head.appendChild(r)
                }
            }
        }

        function Df(e, t, n) {
            vf.S(e, t, n);
            var r = xf;
            if (r && e) {
                var i = Ot(r).hoistableStyles,
                    a = jf(e);
                t || = `default`;
                var o = i.get(a);
                if (!o) {
                    var s = {
                        loading: 0,
                        preload: null
                    };
                    if (o = r.querySelector(Mf(a))) s.loading = 5;
                    else {
                        e = h({
                            rel: `stylesheet`,
                            href: e,
                            "data-precedence": t
                        }, n), (n = hf.get(a)) && zf(e, n);
                        var c = o = r.createElement(`link`);
                        kt(c), Fd(c, `link`, e), c._p = new Promise(function(e, t) {
                            c.onload = e, c.onerror = t
                        }), c.addEventListener(`load`, function() {
                            s.loading |= 1
                        }), c.addEventListener(`error`, function() {
                            s.loading |= 2
                        }), s.loading |= 4, Rf(o, t, r)
                    }
                    o = {
                        type: `stylesheet`,
                        instance: o,
                        count: 1,
                        state: s
                    }, i.set(a, o)
                }
            }
        }

        function Of(e, t) {
            vf.X(e, t);
            var n = xf;
            if (n && e) {
                var r = Ot(n).hoistableScripts,
                    i = Ff(e),
                    a = r.get(i);
                a || (a = n.querySelector(If(i)), a || (e = h({
                    src: e,
                    async: !0
                }, t), (t = hf.get(i)) && Bf(e, t), a = n.createElement(`script`), kt(a), Fd(a, `link`, e), n.head.appendChild(a)), a = {
                    type: `script`,
                    instance: a,
                    count: 1,
                    state: null
                }, r.set(i, a))
            }
        }

        function kf(e, t) {
            vf.M(e, t);
            var n = xf;
            if (n && e) {
                var r = Ot(n).hoistableScripts,
                    i = Ff(e),
                    a = r.get(i);
                a || (a = n.querySelector(If(i)), a || (e = h({
                    src: e,
                    async: !0,
                    type: `module`
                }, t), (t = hf.get(i)) && Bf(e, t), a = n.createElement(`script`), kt(a), Fd(a, `link`, e), n.head.appendChild(a)), a = {
                    type: `script`,
                    instance: a,
                    count: 1,
                    state: null
                }, r.set(i, a))
            }
        }

        function Af(e, t, n, r) {
            var a = (a = ve.current) ? _f(a) : null;
            if (!a) throw Error(i(446));
            switch (e) {
                case `meta`:
                case `title`:
                    return null;
                case `style`:
                    return typeof n.precedence == `string` && typeof n.href == `string` ? (t = jf(n.href), n = Ot(a).hoistableStyles, r = n.get(t), r || (r = {
                        type: `style`,
                        instance: null,
                        count: 0,
                        state: null
                    }, n.set(t, r)), r) : {
                        type: `void`,
                        instance: null,
                        count: 0,
                        state: null
                    };
                case `link`:
                    if (n.rel === `stylesheet` && typeof n.href == `string` && typeof n.precedence == `string`) {
                        e = jf(n.href);
                        var o = Ot(a).hoistableStyles,
                            s = o.get(e);
                        if (s || (a = a.ownerDocument || a, s = {
                                type: `stylesheet`,
                                instance: null,
                                count: 0,
                                state: {
                                    loading: 0,
                                    preload: null
                                }
                            }, o.set(e, s), (o = a.querySelector(Mf(e))) && !o._p && (s.instance = o, s.state.loading = 5), hf.has(e) || (n = {
                                rel: `preload`,
                                as: `style`,
                                href: n.href,
                                crossOrigin: n.crossOrigin,
                                integrity: n.integrity,
                                media: n.media,
                                hrefLang: n.hrefLang,
                                referrerPolicy: n.referrerPolicy
                            }, hf.set(e, n), o || Pf(a, e, n, s.state))), t && r === null) throw Error(i(528, ``));
                        return s
                    }
                    if (t && r !== null) throw Error(i(529, ``));
                    return null;
                case `script`:
                    return t = n.async, n = n.src, typeof n == `string` && t && typeof t != `function` && typeof t != `symbol` ? (t = Ff(n), n = Ot(a).hoistableScripts, r = n.get(t), r || (r = {
                        type: `script`,
                        instance: null,
                        count: 0,
                        state: null
                    }, n.set(t, r)), r) : {
                        type: `void`,
                        instance: null,
                        count: 0,
                        state: null
                    };
                default:
                    throw Error(i(444, e))
            }
        }

        function jf(e) {
            return `href="` + Jt(e) + `"`
        }

        function Mf(e) {
            return `link[rel="stylesheet"][` + e + `]`
        }

        function Nf(e) {
            return h({}, e, {
                "data-precedence": e.precedence,
                precedence: null
            })
        }

        function Pf(e, t, n, r) {
            e.querySelector(`link[rel="preload"][as="style"][` + t + `]`) ? r.loading = 1 : (t = e.createElement(`link`), r.preload = t, t.addEventListener(`load`, function() {
                return r.loading |= 1
            }), t.addEventListener(`error`, function() {
                return r.loading |= 2
            }), Fd(t, `link`, n), kt(t), e.head.appendChild(t))
        }

        function Ff(e) {
            return `[src="` + Jt(e) + `"]`
        }

        function If(e) {
            return `script[async]` + e
        }

        function Lf(e, t, n) {
            if (t.count++, t.instance === null) switch (t.type) {
                case `style`:
                    var r = e.querySelector(`style[data-href~="` + Jt(n.href) + `"]`);
                    if (r) return t.instance = r, kt(r), r;
                    var a = h({}, n, {
                        "data-href": n.href,
                        "data-precedence": n.precedence,
                        href: null,
                        precedence: null
                    });
                    return r = (e.ownerDocument || e).createElement(`style`), kt(r), Fd(r, `style`, a), Rf(r, n.precedence, e), t.instance = r;
                case `stylesheet`:
                    a = jf(n.href);
                    var o = e.querySelector(Mf(a));
                    if (o) return t.state.loading |= 4, t.instance = o, kt(o), o;
                    r = Nf(n), (a = hf.get(a)) && zf(r, a), o = (e.ownerDocument || e).createElement(`link`), kt(o);
                    var s = o;
                    return s._p = new Promise(function(e, t) {
                        s.onload = e, s.onerror = t
                    }), Fd(o, `link`, r), t.state.loading |= 4, Rf(o, n.precedence, e), t.instance = o;
                case `script`:
                    return o = Ff(n.src), (a = e.querySelector(If(o))) ? (t.instance = a, kt(a), a) : (r = n, (a = hf.get(o)) && (r = h({}, n), Bf(r, a)), e = e.ownerDocument || e, a = e.createElement(`script`), kt(a), Fd(a, `link`, r), e.head.appendChild(a), t.instance = a);
                case `void`:
                    return null;
                default:
                    throw Error(i(443, t.type))
            } else t.type === `stylesheet` && !(t.state.loading & 4) && (r = t.instance, t.state.loading |= 4, Rf(r, n.precedence, e));
            return t.instance
        }

        function Rf(e, t, n) {
            for (var r = n.querySelectorAll(`link[rel="stylesheet"][data-precedence],style[data-precedence]`), i = r.length ? r[r.length - 1] : null, a = i, o = 0; o < r.length; o++) {
                var s = r[o];
                if (s.dataset.precedence === t) a = s;
                else if (a !== i) break
            }
            a ? a.parentNode.insertBefore(e, a.nextSibling) : (t = n.nodeType === 9 ? n.head : n, t.insertBefore(e, t.firstChild))
        }

        function zf(e, t) {
            e.crossOrigin ? ? = t.crossOrigin, e.referrerPolicy ? ? = t.referrerPolicy, e.title ? ? = t.title
        }

        function Bf(e, t) {
            e.crossOrigin ? ? = t.crossOrigin, e.referrerPolicy ? ? = t.referrerPolicy, e.integrity ? ? = t.integrity
        }
        var Vf = null;

        function Hf(e, t, n) {
            if (Vf === null) {
                var r = new Map,
                    i = Vf = new Map;
                i.set(n, r)
            } else i = Vf, r = i.get(n), r || (r = new Map, i.set(n, r));
            if (r.has(e)) return r;
            for (r.set(e, null), n = n.getElementsByTagName(e), i = 0; i < n.length; i++) {
                var a = n[i];
                if (!(a[Ct] || a[_t] || e === `link` && a.getAttribute(`rel`) === `stylesheet`) && a.namespaceURI !== `http://www.w3.org/2000/svg`) {
                    var o = a.getAttribute(t) || ``;
                    o = e + o;
                    var s = r.get(o);
                    s ? s.push(a) : r.set(o, [a])
                }
            }
            return r
        }

        function Uf(e, t, n) {
            e = e.ownerDocument || e, e.head.insertBefore(n, t === `title` ? e.querySelector(`head > title`) : null)
        }

        function Wf(e, t, n) {
            if (n === 1 || t.itemProp != null) return !1;
            switch (e) {
                case `meta`:
                case `title`:
                    return !0;
                case `style`:
                    if (typeof t.precedence != `string` || typeof t.href != `string` || t.href === ``) break;
                    return !0;
                case `link`:
                    if (typeof t.rel != `string` || typeof t.href != `string` || t.href === `` || t.onLoad || t.onError) break;
                    switch (t.rel) {
                        case `stylesheet`:
                            return e = t.disabled, typeof t.precedence == `string` && e == null;
                        default:
                            return !0
                    }
                case `script`:
                    if (t.async && typeof t.async != `function` && typeof t.async != `symbol` && !t.onLoad && !t.onError && t.src && typeof t.src == `string`) return !0
            }
            return !1
        }

        function Gf(e) {
            return !(e.type === `stylesheet` && !(e.state.loading & 3))
        }

        function Kf(e, t, n, r) {
            if (n.type === `stylesheet` && (typeof r.media != `string` || !1 !== matchMedia(r.media).matches) && !(n.state.loading & 4)) {
                if (n.instance === null) {
                    var i = jf(r.href),
                        a = t.querySelector(Mf(i));
                    if (a) {
                        t = a._p, typeof t == `object` && t && typeof t.then == `function` && (e.count++, e = Yf.bind(e), t.then(e, e)), n.state.loading |= 4, n.instance = a, kt(a);
                        return
                    }
                    a = t.ownerDocument || t, r = Nf(r), (i = hf.get(i)) && zf(r, i), a = a.createElement(`link`), kt(a);
                    var o = a;
                    o._p = new Promise(function(e, t) {
                        o.onload = e, o.onerror = t
                    }), Fd(a, `link`, r), n.instance = a
                }
                e.stylesheets === null && (e.stylesheets = new Map), e.stylesheets.set(n, t), (t = n.state.preload) && !(n.state.loading & 3) && (e.count++, n = Yf.bind(e), t.addEventListener(`load`, n), t.addEventListener(`error`, n))
            }
        }
        var qf = 0;

        function Jf(e, t) {
            return e.stylesheets && e.count === 0 && Zf(e, e.stylesheets), 0 < e.count || 0 < e.imgCount ? function(n) {
                var r = setTimeout(function() {
                    if (e.stylesheets && Zf(e, e.stylesheets), e.unsuspend) {
                        var t = e.unsuspend;
                        e.unsuspend = null, t()
                    }
                }, 6e4 + t);
                0 < e.imgBytes && qf === 0 && (qf = 62500 * Rd());
                var i = setTimeout(function() {
                    if (e.waitingForImages = !1, e.count === 0 && (e.stylesheets && Zf(e, e.stylesheets), e.unsuspend)) {
                        var t = e.unsuspend;
                        e.unsuspend = null, t()
                    }
                }, (e.imgBytes > qf ? 50 : 800) + t);
                return e.unsuspend = n,
                    function() {
                        e.unsuspend = null, clearTimeout(r), clearTimeout(i)
                    }
            } : null
        }

        function Yf() {
            if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
                if (this.stylesheets) Zf(this, this.stylesheets);
                else if (this.unsuspend) {
                    var e = this.unsuspend;
                    this.unsuspend = null, e()
                }
            }
        }
        var Xf = null;

        function Zf(e, t) {
            e.stylesheets = null, e.unsuspend !== null && (e.count++, Xf = new Map, t.forEach(Qf, e), Xf = null, Yf.call(e))
        }

        function Qf(e, t) {
            if (!(t.state.loading & 4)) {
                var n = Xf.get(e);
                if (n) var r = n.get(null);
                else {
                    n = new Map, Xf.set(e, n);
                    for (var i = e.querySelectorAll(`link[data-precedence],style[data-precedence]`), a = 0; a < i.length; a++) {
                        var o = i[a];
                        (o.nodeName === `LINK` || o.getAttribute(`media`) !== `not all`) && (n.set(o.dataset.precedence, o), r = o)
                    }
                    r && n.set(null, r)
                }
                i = t.instance, o = i.getAttribute(`data-precedence`), a = n.get(o) || r, a === r && n.set(null, i), n.set(o, i), this.count++, r = Yf.bind(this), i.addEventListener(`load`, r), i.addEventListener(`error`, r), a ? a.parentNode.insertBefore(i, a.nextSibling) : (e = e.nodeType === 9 ? e.head : e, e.insertBefore(i, e.firstChild)), t.state.loading |= 4
            }
        }
        var $f = {
            $$typeof: S,
            Provider: null,
            Consumer: null,
            _currentValue: fe,
            _currentValue2: fe,
            _threadCount: 0
        };

        function ep(e, t, n, r, i, a, o, s, c) {
            this.tag = 1, this.containerInfo = e, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = ot(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = ot(0), this.hiddenUpdates = ot(null), this.identifierPrefix = r, this.onUncaughtError = i, this.onCaughtError = a, this.onRecoverableError = o, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = c, this.incompleteTransitions = new Map
        }

        function tp(e, t, n, r, i, a, o, s, c, l, u, d) {
            return e = new ep(e, t, n, o, c, l, u, d, s), t = 1, !0 === a && (t |= 24), a = gi(3, null, null, t), e.current = a, a.stateNode = e, t = ha(), t.refCount++, e.pooledCache = t, t.refCount++, a.memoizedState = {
                element: r,
                isDehydrated: n,
                cache: t
            }, Ja(a), e
        }

        function np(e) {
            return e ? (e = mi, e) : mi
        }

        function rp(e, t, n, r, i, a) {
            i = np(i), r.context === null ? r.context = i : r.pendingContext = i, r = Xa(t), r.payload = {
                element: n
            }, a = a === void 0 ? null : a, a !== null && (r.callback = a), n = Za(e, r, t), n !== null && (gu(n, e, t), Qa(n, e, t))
        }

        function ip(e, t) {
            if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
                var n = e.retryLane;
                e.retryLane = n !== 0 && n < t ? n : t
            }
        }

        function ap(e, t) {
            ip(e, t), (e = e.alternate) && ip(e, t)
        }

        function op(e) {
            if (e.tag === 13 || e.tag === 31) {
                var t = di(e, 67108864);
                t !== null && gu(t, e, 67108864), ap(e, 67108864)
            }
        }

        function sp(e) {
            if (e.tag === 13 || e.tag === 31) {
                var t = mu();
                t = ft(t);
                var n = di(e, t);
                n !== null && gu(n, e, t), ap(e, t)
            }
        }
        var cp = !0;

        function lp(e, t, n, r) {
            var i = w.T;
            w.T = null;
            var a = E.p;
            try {
                E.p = 2, dp(e, t, n, r)
            } finally {
                E.p = a, w.T = i
            }
        }

        function up(e, t, n, r) {
            var i = w.T;
            w.T = null;
            var a = E.p;
            try {
                E.p = 8, dp(e, t, n, r)
            } finally {
                E.p = a, w.T = i
            }
        }

        function dp(e, t, n, r) {
            if (cp) {
                var i = fp(r);
                if (i === null) Td(e, t, r, pp, n), wp(e, r);
                else if (Ep(i, e, t, n, r)) r.stopPropagation();
                else if (wp(e, r), t & 4 && -1 < Cp.indexOf(e)) {
                    for (; i !== null;) {
                        var a = Et(i);
                        if (a !== null) switch (a.tag) {
                            case 3:
                                if (a = a.stateNode, a.current.memoizedState.isDehydrated) {
                                    var o = tt(a.pendingLanes);
                                    if (o !== 0) {
                                        var s = a;
                                        for (s.pendingLanes |= 2, s.entangledLanes |= 2; o;) {
                                            var c = 1 << 31 - Je(o);
                                            s.entanglements[1] |= c, o &= ~c
                                        }
                                        id(a), !(G & 6) && (nu = Ie() + 500, ad(0, !1))
                                    }
                                }
                                break;
                            case 31:
                            case 13:
                                s = di(a, 2), s !== null && gu(s, a, 2), xu(), ap(a, 2)
                        }
                        if (a = fp(r), a === null && Td(e, t, r, pp, n), a === i) break;
                        i = a
                    }
                    i !== null && r.stopPropagation()
                } else Td(e, t, r, null, n)
            }
        }

        function fp(e) {
            return e = fn(e), mp(e)
        }
        var pp = null;

        function mp(e) {
            if (pp = null, e = Tt(e), e !== null) {
                var t = o(e);
                if (t === null) e = null;
                else {
                    var n = t.tag;
                    if (n === 13) {
                        if (e = s(t), e !== null) return e;
                        e = null
                    } else if (n === 31) {
                        if (e = c(t), e !== null) return e;
                        e = null
                    } else if (n === 3) {
                        if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
                        e = null
                    } else t !== e && (e = null)
                }
            }
            return pp = e, null
        }

        function hp(e) {
            switch (e) {
                case `beforetoggle`:
                case `cancel`:
                case `click`:
                case `close`:
                case `contextmenu`:
                case `copy`:
                case `cut`:
                case `auxclick`:
                case `dblclick`:
                case `dragend`:
                case `dragstart`:
                case `drop`:
                case `focusin`:
                case `focusout`:
                case `input`:
                case `invalid`:
                case `keydown`:
                case `keypress`:
                case `keyup`:
                case `mousedown`:
                case `mouseup`:
                case `paste`:
                case `pause`:
                case `play`:
                case `pointercancel`:
                case `pointerdown`:
                case `pointerup`:
                case `ratechange`:
                case `reset`:
                case `resize`:
                case `seeked`:
                case `submit`:
                case `toggle`:
                case `touchcancel`:
                case `touchend`:
                case `touchstart`:
                case `volumechange`:
                case `change`:
                case `selectionchange`:
                case `textInput`:
                case `compositionstart`:
                case `compositionend`:
                case `compositionupdate`:
                case `beforeblur`:
                case `afterblur`:
                case `beforeinput`:
                case `blur`:
                case `fullscreenchange`:
                case `focus`:
                case `hashchange`:
                case `popstate`:
                case `select`:
                case `selectstart`:
                    return 2;
                case `drag`:
                case `dragenter`:
                case `dragexit`:
                case `dragleave`:
                case `dragover`:
                case `mousemove`:
                case `mouseout`:
                case `mouseover`:
                case `pointermove`:
                case `pointerout`:
                case `pointerover`:
                case `scroll`:
                case `touchmove`:
                case `wheel`:
                case `mouseenter`:
                case `mouseleave`:
                case `pointerenter`:
                case `pointerleave`:
                    return 8;
                case `message`:
                    switch (Le()) {
                        case Re:
                            return 2;
                        case ze:
                            return 8;
                        case Be:
                        case Ve:
                            return 32;
                        case He:
                            return 268435456;
                        default:
                            return 32
                    }
                default:
                    return 32
            }
        }
        var gp = !1,
            _p = null,
            vp = null,
            yp = null,
            bp = new Map,
            xp = new Map,
            Sp = [],
            Cp = `mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset`.split(` `);

        function wp(e, t) {
            switch (e) {
                case `focusin`:
                case `focusout`:
                    _p = null;
                    break;
                case `dragenter`:
                case `dragleave`:
                    vp = null;
                    break;
                case `mouseover`:
                case `mouseout`:
                    yp = null;
                    break;
                case `pointerover`:
                case `pointerout`:
                    bp.delete(t.pointerId);
                    break;
                case `gotpointercapture`:
                case `lostpointercapture`:
                    xp.delete(t.pointerId)
            }
        }

        function Tp(e, t, n, r, i, a) {
            return e === null || e.nativeEvent !== a ? (e = {
                blockedOn: t,
                domEventName: n,
                eventSystemFlags: r,
                nativeEvent: a,
                targetContainers: [i]
            }, t !== null && (t = Et(t), t !== null && op(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, i !== null && t.indexOf(i) === -1 && t.push(i), e)
        }

        function Ep(e, t, n, r, i) {
            switch (t) {
                case `focusin`:
                    return _p = Tp(_p, e, t, n, r, i), !0;
                case `dragenter`:
                    return vp = Tp(vp, e, t, n, r, i), !0;
                case `mouseover`:
                    return yp = Tp(yp, e, t, n, r, i), !0;
                case `pointerover`:
                    var a = i.pointerId;
                    return bp.set(a, Tp(bp.get(a) || null, e, t, n, r, i)), !0;
                case `gotpointercapture`:
                    return a = i.pointerId, xp.set(a, Tp(xp.get(a) || null, e, t, n, r, i)), !0
            }
            return !1
        }

        function Dp(e) {
            var t = Tt(e.target);
            if (t !== null) {
                var n = o(t);
                if (n !== null) {
                    if (t = n.tag, t === 13) {
                        if (t = s(n), t !== null) {
                            e.blockedOn = t, ht(e.priority, function() {
                                sp(n)
                            });
                            return
                        }
                    } else if (t === 31) {
                        if (t = c(n), t !== null) {
                            e.blockedOn = t, ht(e.priority, function() {
                                sp(n)
                            });
                            return
                        }
                    } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
                        e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                        return
                    }
                }
            }
            e.blockedOn = null
        }

        function Op(e) {
            if (e.blockedOn !== null) return !1;
            for (var t = e.targetContainers; 0 < t.length;) {
                var n = fp(e.nativeEvent);
                if (n === null) {
                    n = e.nativeEvent;
                    var r = new n.constructor(n.type, n);
                    dn = r, n.target.dispatchEvent(r), dn = null
                } else return t = Et(n), t !== null && op(t), e.blockedOn = n, !1;
                t.shift()
            }
            return !0
        }

        function kp(e, t, n) {
            Op(e) && n.delete(t)
        }

        function Ap() {
            gp = !1, _p !== null && Op(_p) && (_p = null), vp !== null && Op(vp) && (vp = null), yp !== null && Op(yp) && (yp = null), bp.forEach(kp), xp.forEach(kp)
        }

        function jp(e, n) {
            e.blockedOn === n && (e.blockedOn = null, gp || (gp = !0, t.unstable_scheduleCallback(t.unstable_NormalPriority, Ap)))
        }
        var Mp = null;

        function Np(e) {
            Mp !== e && (Mp = e, t.unstable_scheduleCallback(t.unstable_NormalPriority, function() {
                Mp === e && (Mp = null);
                for (var t = 0; t < e.length; t += 3) {
                    var n = e[t],
                        r = e[t + 1],
                        i = e[t + 2];
                    if (typeof r != `function`) {
                        if (mp(r || n) === null) continue;
                        break
                    }
                    var a = Et(n);
                    a !== null && (e.splice(t, 3), t -= 3, Os(a, {
                        pending: !0,
                        data: i,
                        method: n.method,
                        action: r
                    }, r, i))
                }
            }))
        }

        function Pp(e) {
            function t(t) {
                return jp(t, e)
            }
            _p !== null && jp(_p, e), vp !== null && jp(vp, e), yp !== null && jp(yp, e), bp.forEach(t), xp.forEach(t);
            for (var n = 0; n < Sp.length; n++) {
                var r = Sp[n];
                r.blockedOn === e && (r.blockedOn = null)
            }
            for (; 0 < Sp.length && (n = Sp[0], n.blockedOn === null);) Dp(n), n.blockedOn === null && Sp.shift();
            if (n = (e.ownerDocument || e).$$reactFormReplay, n != null)
                for (r = 0; r < n.length; r += 3) {
                    var i = n[r],
                        a = n[r + 1],
                        o = i[k] || null;
                    if (typeof a == `function`) o || Np(n);
                    else if (o) {
                        var s = null;
                        if (a && a.hasAttribute(`formAction`)) {
                            if (i = a, o = a[k] || null) s = o.formAction;
                            else if (mp(i) !== null) continue
                        } else s = o.action;
                        typeof s == `function` ? n[r + 1] = s : (n.splice(r, 3), r -= 3), Np(n)
                    }
                }
        }

        function Fp() {
            function e(e) {
                e.canIntercept && e.info === `react-transition` && e.intercept({
                    handler: function() {
                        return new Promise(function(e) {
                            return i = e
                        })
                    },
                    focusReset: `manual`,
                    scroll: `manual`
                })
            }

            function t() {
                i !== null && (i(), i = null), r || setTimeout(n, 20)
            }

            function n() {
                if (!r && !navigation.transition) {
                    var e = navigation.currentEntry;
                    e && e.url != null && navigation.navigate(e.url, {
                        state: e.getState(),
                        info: `react-transition`,
                        history: `replace`
                    })
                }
            }
            if (typeof navigation == `object`) {
                var r = !1,
                    i = null;
                return navigation.addEventListener(`navigate`, e), navigation.addEventListener(`navigatesuccess`, t), navigation.addEventListener(`navigateerror`, t), setTimeout(n, 100),
                    function() {
                        r = !0, navigation.removeEventListener(`navigate`, e), navigation.removeEventListener(`navigatesuccess`, t), navigation.removeEventListener(`navigateerror`, t), i !== null && (i(), i = null)
                    }
            }
        }

        function Ip(e) {
            this._internalRoot = e
        }
        Lp.prototype.render = Ip.prototype.render = function(e) {
            var t = this._internalRoot;
            if (t === null) throw Error(i(409));
            var n = t.current;
            rp(n, mu(), e, t, null, null)
        }, Lp.prototype.unmount = Ip.prototype.unmount = function() {
            var e = this._internalRoot;
            if (e !== null) {
                this._internalRoot = null;
                var t = e.containerInfo;
                rp(e.current, 2, null, e, null, null), xu(), t[vt] = null
            }
        };

        function Lp(e) {
            this._internalRoot = e
        }
        Lp.prototype.unstable_scheduleHydration = function(e) {
            if (e) {
                var t = mt();
                e = {
                    blockedOn: null,
                    target: e,
                    priority: t
                };
                for (var n = 0; n < Sp.length && t !== 0 && t < Sp[n].priority; n++);
                Sp.splice(n, 0, e), n === 0 && Dp(e)
            }
        };
        var Rp = n.version;
        if (Rp !== `19.2.5`) throw Error(i(527, Rp, `19.2.5`));
        E.findDOMNode = function(e) {
            var t = e._reactInternals;
            if (t === void 0) throw typeof e.render == `function` ? Error(i(188)) : (e = Object.keys(e).join(`,`), Error(i(268, e)));
            return e = d(t), e = e === null ? null : p(e), e = e === null ? null : e.stateNode, e
        };
        var zp = {
            bundleType: 0,
            version: `19.2.5`,
            rendererPackageName: `react-dom`,
            currentDispatcherRef: w,
            reconcilerVersion: `19.2.5`
        };
        if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < `u`) {
            var Bp = __REACT_DEVTOOLS_GLOBAL_HOOK__;
            if (!Bp.isDisabled && Bp.supportsFiber) try {
                Ge = Bp.inject(zp), Ke = Bp
            } catch {}
        }
        e.hydrateRoot = function(e, t, n) {
            if (!a(e)) throw Error(i(299));
            var r = !1,
                o = ``,
                s = Xs,
                c = Zs,
                l = Qs,
                u = null;
            return n != null && (!0 === n.unstable_strictMode && (r = !0), n.identifierPrefix !== void 0 && (o = n.identifierPrefix), n.onUncaughtError !== void 0 && (s = n.onUncaughtError), n.onCaughtError !== void 0 && (c = n.onCaughtError), n.onRecoverableError !== void 0 && (l = n.onRecoverableError), n.formState !== void 0 && (u = n.formState)), t = tp(e, 1, !0, t, n ? ? null, r, o, u, s, c, l, Fp), t.context = np(null), n = t.current, r = mu(), r = ft(r), o = Xa(r), o.callback = null, Za(n, o, r), n = r, t.current.lanes = n, st(t, n), id(t), e[vt] = t.current, Cd(e), new Lp(t)
        }
    })),
    g = o(((e, t) => {
        function n() {
            if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > `u` || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != `function`)) try {
                __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)
            } catch (e) {
                console.error(e)
            }
        }
        n(), t.exports = h()
    })),
    _ = `__TSS_CONTEXT`,
    v = Symbol.for(`TSS_SERVER_FUNCTION`),
    y = `application/x-tss-framed`,
    b = {
        JSON: 0,
        CHUNK: 1,
        END: 2,
        ERROR: 3
    };
`${y}`;
var x = /;\s*v=(\d+)/;

function ee(e) {
    let t = e.match(x);
    return t ? parseInt(t[1], 10) : void 0
}

function S(e) {
    let t = ee(e);
    if (t !== void 0 && t !== 1) throw Error(`Incompatible framed protocol version: server=${t}, client=1. Please ensure client and server are using compatible versions.`)
}
var C = () => window.__TSS_START_OPTIONS__;

function te(e) {
    return e[e.length - 1]
}

function ne(e) {
    return typeof e == `function`
}

function re(e, t) {
    return ne(e) ? e(t) : e
}
var ie = Object.prototype.hasOwnProperty,
    ae = Object.prototype.propertyIsEnumerable;

function oe(e) {
    for (let t in e)
        if (ie.call(e, t)) return !0;
    return !1
}
var se = () => Object.create(null),
    ce = (e, t) => le(e, t, se);

function le(e, t, n = () => ({}), r = 0) {
    if (e === t) return e;
    if (r > 500) return t;
    let i = t,
        a = E(e) && E(i);
    if (!a && !(de(e) && de(i))) return i;
    let o = a ? e : ue(e);
    if (!o) return i;
    let s = a ? i : ue(i);
    if (!s) return i;
    let c = o.length,
        l = s.length,
        u = a ? Array(l) : n(),
        d = 0;
    for (let t = 0; t < l; t++) {
        let o = a ? t : s[t],
            l = e[o],
            f = i[o];
        if (l === f) {
            u[o] = l, (a ? t < c : ie.call(e, o)) && d++;
            continue
        }
        if (l === null || f === null || typeof l != `object` || typeof f != `object`) {
            u[o] = f;
            continue
        }
        let p = le(l, f, n, r + 1);
        u[o] = p, p === l && d++
    }
    return c === l && d === c ? e : u
}

function ue(e) {
    let t = Object.getOwnPropertyNames(e);
    for (let n of t)
        if (!ae.call(e, n)) return !1;
    let n = Object.getOwnPropertySymbols(e);
    if (n.length === 0) return t;
    let r = t;
    for (let t of n) {
        if (!ae.call(e, t)) return !1;
        r.push(t)
    }
    return r
}

function de(e) {
    if (!w(e)) return !1;
    let t = e.constructor;
    if (t === void 0) return !0;
    let n = t.prototype;
    return !(!w(n) || !n.hasOwnProperty(`isPrototypeOf`))
}

function w(e) {
    return Object.prototype.toString.call(e) === `[object Object]`
}

function E(e) {
    return Array.isArray(e) && e.length === Object.keys(e).length
}

function fe(e, t, n) {
    if (e === t) return !0;
    if (typeof e != typeof t) return !1;
    if (Array.isArray(e) && Array.isArray(t)) {
        if (e.length !== t.length) return !1;
        for (let r = 0, i = e.length; r < i; r++)
            if (!fe(e[r], t[r], n)) return !1;
        return !0
    }
    if (de(e) && de(t)) {
        let r = n ? .ignoreUndefined ? ? !0;
        if (n ? .partial) {
            for (let i in t)
                if ((!r || t[i] !== void 0) && !fe(e[i], t[i], n)) return !1;
            return !0
        }
        let i = 0;
        if (!r) i = Object.keys(e).length;
        else
            for (let t in e) e[t] !== void 0 && i++;
        let a = 0;
        for (let o in t)
            if ((!r || t[o] !== void 0) && (a++, a > i || !fe(e[o], t[o], n))) return !1;
        return i === a
    }
    return !1
}

function pe(e) {
    let t, n, r = new Promise((e, r) => {
        t = e, n = r
    });
    return r.status = `pending`, r.resolve = n => {
        r.status = `resolved`, r.value = n, t(n), e ? .(n)
    }, r.reject = e => {
        r.status = `rejected`, n(e)
    }, r
}

function me(e) {
    return typeof e ? .message == `string` ? e.message.startsWith(`Failed to fetch dynamically imported module`) || e.message.startsWith(`error loading dynamically imported module`) || e.message.startsWith(`Importing a module script failed`) : !1
}

function he(e) {
    return !!(e && typeof e == `object` && typeof e.then == `function`)
}

function D(e) {
    return e.replace(/[\x00-\x1f\x7f]/g, ``)
}

function O(e) {
    let t;
    try {
        t = decodeURI(e)
    } catch {
        t = e.replaceAll(/%[0-9A-F]{2}/gi, e => {
            try {
                return decodeURI(e)
            } catch {
                return e
            }
        })
    }
    return D(t)
}
var ge = [`http:`, `https:`, `mailto:`, `tel:`];

function _e(e, t) {
    if (!e) return !1;
    try {
        let n = new URL(e);
        return !t.has(n.protocol)
    } catch {
        return !1
    }
}
var ve = {
        "&": `\\u0026`,
        ">": `\\u003e`,
        "<": `\\u003c`,
        "\u2028": `\\u2028`,
        "\u2029": `\\u2029`
    },
    ye = /[&><\u2028\u2029]/g;

function be(e) {
    return e.replace(ye, e => ve[e])
}

function xe(e) {
    if (!e || !/[%\\\x00-\x1f\x7f]/.test(e) && !e.startsWith(`//`)) return {
        path: e,
        handledProtocolRelativeURL: !1
    };
    let t = /%25|%5C/gi,
        n = 0,
        r = ``,
        i;
    for (;
        (i = t.exec(e)) !== null;) r += O(e.slice(n, i.index)) + i[0], n = t.lastIndex;
    r += O(n ? e.slice(n) : e);
    let a = !1;
    return r.startsWith(`//`) && (a = !0, r = `/` + r.replace(/^\/+/, ``)), {
        path: r,
        handledProtocolRelativeURL: a
    }
}

function Se(e) {
    return /\s|[^\u0000-\u007F]/.test(e) ? e.replace(/\s|[^\u0000-\u007F]/gu, encodeURIComponent) : e
}

function Ce(e, t) {
    if (e === t) return !0;
    if (e.length !== t.length) return !1;
    for (let n = 0; n < e.length; n++)
        if (e[n] !== t[n]) return !1;
    return !0
}

function we() {
    throw Error(`Invariant failed`)
}

function Te(e) {
    let t = new Map,
        n, r, i = e => {
            e.next && (e.prev ? (e.prev.next = e.next, e.next.prev = e.prev, e.next = void 0, r && (r.next = e, e.prev = r)) : (e.next.prev = void 0, n = e.next, e.next = void 0, r && (e.prev = r, r.next = e)), r = e)
        };
    return {
        get(e) {
            let n = t.get(e);
            if (n) return i(n), n.value
        },
        set(a, o) {
            if (t.size >= e && n) {
                let e = n;
                t.delete(e.key), e.next && (n = e.next, e.next.prev = void 0), e === r && (r = void 0)
            }
            let s = t.get(a);
            if (s) s.value = o, i(s);
            else {
                let e = {
                    key: a,
                    value: o,
                    prev: r
                };
                r && (r.next = e), r = e, n || = e, t.set(a, e)
            }
        },
        clear() {
            t.clear(), n = void 0, r = void 0
        }
    }
}
var Ee = 4,
    De = 5;

function Oe(e) {
    let t = e.indexOf(`{`);
    if (t === -1) return null;
    let n = e.indexOf(`}`, t);
    return n === -1 || t + 1 >= e.length ? null : [t, n]
}

function ke(e, t, n = new Uint16Array(6)) {
    let r = e.indexOf(`/`, t),
        i = r === -1 ? e.length : r,
        a = e.substring(t, i);
    if (!a || !a.includes(`$`)) return n[0] = 0, n[1] = t, n[2] = t, n[3] = i, n[4] = i, n[5] = i, n;
    if (a === `$`) {
        let r = e.length;
        return n[0] = 2, n[1] = t, n[2] = t, n[3] = r, n[4] = r, n[5] = r, n
    }
    if (a.charCodeAt(0) === 36) return n[0] = 1, n[1] = t, n[2] = t + 1, n[3] = i, n[4] = i, n[5] = i, n;
    let o = Oe(a);
    if (o) {
        let [r, s] = o, c = a.charCodeAt(r + 1);
        if (c === 45) {
            if (r + 2 < a.length && a.charCodeAt(r + 2) === 36) {
                let e = r + 3,
                    a = s;
                if (e < a) return n[0] = 3, n[1] = t + r, n[2] = t + e, n[3] = t + a, n[4] = t + s + 1, n[5] = i, n
            }
        } else if (c === 36) {
            let a = r + 1,
                o = r + 2;
            return o === s ? (n[0] = 2, n[1] = t + r, n[2] = t + a, n[3] = t + o, n[4] = t + s + 1, n[5] = e.length, n) : (n[0] = 1, n[1] = t + r, n[2] = t + o, n[3] = t + s, n[4] = t + s + 1, n[5] = i, n)
        }
    }
    return n[0] = 0, n[1] = t, n[2] = t, n[3] = i, n[4] = i, n[5] = i, n
}

function Ae(e, t, n, r, i, a, o) {
    o ? .(n);
    let s = r; {
        let r = n.fullPath ? ? n.from,
            o = r.length,
            c = n.options ? .caseSensitive ? ? e,
            l = n.options ? .params ? .parse ? ? n.options ? .parseParams;
        for (; s < o;) {
            let e = ke(r, s, t),
                o, u = s,
                d = e[5];
            switch (s = d + 1, a++, e[0]) {
                case 0:
                    {
                        let t = r.substring(e[2], e[3]);
                        if (c) {
                            let e = i.static ? .get(t);
                            if (e) o = e;
                            else {
                                i.static ? ? = new Map;
                                let e = Ne(n.fullPath ? ? n.from);
                                e.parent = i, e.depth = a, o = e, i.static.set(t, e)
                            }
                        } else {
                            let e = t.toLowerCase(),
                                r = i.staticInsensitive ? .get(e);
                            if (r) o = r;
                            else {
                                i.staticInsensitive ? ? = new Map;
                                let t = Ne(n.fullPath ? ? n.from);
                                t.parent = i, t.depth = a, o = t, i.staticInsensitive.set(e, t)
                            }
                        }
                        break
                    }
                case 1:
                    {
                        let t = r.substring(u, e[1]),
                            s = r.substring(e[4], d),
                            f = c && !!(t || s),
                            p = t ? f ? t : t.toLowerCase() : void 0,
                            m = s ? f ? s : s.toLowerCase() : void 0,
                            h = !l && i.dynamic ? .find(e => !e.parse && e.caseSensitive === f && e.prefix === p && e.suffix === m);
                        if (h) o = h;
                        else {
                            let e = Pe(1, n.fullPath ? ? n.from, f, p, m);
                            o = e, e.depth = a, e.parent = i, i.dynamic ? ? = [], i.dynamic.push(e)
                        }
                        break
                    }
                case 3:
                    {
                        let t = r.substring(u, e[1]),
                            s = r.substring(e[4], d),
                            f = c && !!(t || s),
                            p = t ? f ? t : t.toLowerCase() : void 0,
                            m = s ? f ? s : s.toLowerCase() : void 0,
                            h = !l && i.optional ? .find(e => !e.parse && e.caseSensitive === f && e.prefix === p && e.suffix === m);
                        if (h) o = h;
                        else {
                            let e = Pe(3, n.fullPath ? ? n.from, f, p, m);
                            o = e, e.parent = i, e.depth = a, i.optional ? ? = [], i.optional.push(e)
                        }
                        break
                    }
                case 2:
                    {
                        let t = r.substring(u, e[1]),
                            s = r.substring(e[4], d),
                            l = c && !!(t || s),
                            f = t ? l ? t : t.toLowerCase() : void 0,
                            p = s ? l ? s : s.toLowerCase() : void 0,
                            m = Pe(2, n.fullPath ? ? n.from, l, f, p);o = m,
                        m.parent = i,
                        m.depth = a,
                        i.wildcard ? ? = [],
                        i.wildcard.push(m)
                    }
            }
            i = o
        }
        if (l && n.children && !n.isRoot && n.id && n.id.charCodeAt(n.id.lastIndexOf(`/`) + 1) === 95) {
            let e = Ne(n.fullPath ? ? n.from);
            e.kind = De, e.parent = i, a++, e.depth = a, i.pathless ? ? = [], i.pathless.push(e), i = e
        }
        let u = (n.path || !n.children) && !n.isRoot;
        if (u && r.endsWith(`/`)) {
            let e = Ne(n.fullPath ? ? n.from);
            e.kind = Ee, e.parent = i, a++, e.depth = a, i.index = e, i = e
        }
        i.parse = l ? ? null, i.priority = n.options ? .params ? .priority ? ? 0, u && !i.route && (i.route = n, i.fullPath = n.fullPath ? ? n.from)
    }
    if (n.children)
        for (let r of n.children) Ae(e, t, r, s, i, a, o)
}

function je(e, t) {
    if (e.parse && !t.parse) return -1;
    if (!e.parse && t.parse) return 1;
    if (e.parse && t.parse && (e.priority || t.priority)) return t.priority - e.priority;
    if (e.prefix && t.prefix && e.prefix !== t.prefix) {
        if (e.prefix.startsWith(t.prefix)) return -1;
        if (t.prefix.startsWith(e.prefix)) return 1
    }
    if (e.suffix && t.suffix && e.suffix !== t.suffix) {
        if (e.suffix.endsWith(t.suffix)) return -1;
        if (t.suffix.endsWith(e.suffix)) return 1
    }
    return e.prefix && !t.prefix ? -1 : !e.prefix && t.prefix ? 1 : e.suffix && !t.suffix ? -1 : !e.suffix && t.suffix ? 1 : e.caseSensitive && !t.caseSensitive ? -1 : !e.caseSensitive && t.caseSensitive ? 1 : 0
}

function Me(e) {
    if (e.pathless)
        for (let t of e.pathless) Me(t);
    if (e.static)
        for (let t of e.static.values()) Me(t);
    if (e.staticInsensitive)
        for (let t of e.staticInsensitive.values()) Me(t);
    if (e.dynamic ? .length) {
        e.dynamic.sort(je);
        for (let t of e.dynamic) Me(t)
    }
    if (e.optional ? .length) {
        e.optional.sort(je);
        for (let t of e.optional) Me(t)
    }
    if (e.wildcard ? .length) {
        e.wildcard.sort(je);
        for (let t of e.wildcard) Me(t)
    }
}

function Ne(e) {
    return {
        kind: 0,
        depth: 0,
        pathless: null,
        index: null,
        static: null,
        staticInsensitive: null,
        dynamic: null,
        optional: null,
        wildcard: null,
        route: null,
        fullPath: e,
        parent: null,
        parse: null,
        priority: 0
    }
}

function Pe(e, t, n, r, i) {
    return {
        kind: e,
        depth: 0,
        pathless: null,
        index: null,
        static: null,
        staticInsensitive: null,
        dynamic: null,
        optional: null,
        wildcard: null,
        route: null,
        fullPath: t,
        parent: null,
        parse: null,
        priority: 0,
        caseSensitive: n,
        prefix: r,
        suffix: i
    }
}

function Fe(e, t) {
    let n = Ne(`/`),
        r = new Uint16Array(6);
    for (let t of e) Ae(!1, r, t, 1, n, 0);
    Me(n), t.masksTree = n, t.flatCache = Te(1e3)
}

function Ie(e, t) {
    e || = `/`;
    let n = t.flatCache.get(e);
    if (n) return n;
    let r = Ve(e, t.masksTree);
    return t.flatCache.set(e, r), r
}

function Le(e, t, n, r, i) {
    e || = `/`, r || = `/`;
    let a = t ? `case\0${e}` : e,
        o = i.singleCache.get(a);
    return o || (o = Ne(`/`), Ae(t, new Uint16Array(6), {
        from: e
    }, 1, o, 0), i.singleCache.set(a, o)), Ve(r, o, n)
}

function Re(e, t, n = !1) {
    let r = n ? e : `nofuzz\0${e}`,
        i = t.matchCache.get(r);
    if (i !== void 0) return i;
    e || = `/`;
    let a;
    try {
        a = Ve(e, t.segmentTree, n)
    } catch (e) {
        if (e instanceof URIError) a = null;
        else throw e
    }
    return a && (a.branch = Ue(a.route)), t.matchCache.set(r, a), a
}

function ze(e) {
    return e === `/` ? e : e.replace(/\/{1,}$/, ``)
}

function Be(e, t = !1, n) {
    let r = Ne(e.fullPath),
        i = new Uint16Array(6),
        a = {},
        o = {},
        s = 0;
    return Ae(t, i, e, 1, r, 0, e => {
        if (n ? .(e, s), e.id in a && we(), a[e.id] = e, s !== 0 && e.path) {
            let t = ze(e.fullPath);
            (!o[t] || e.fullPath.endsWith(`/`)) && (o[t] = e)
        }
        s++
    }), Me(r), {
        processedTree: {
            segmentTree: r,
            singleCache: Te(1e3),
            matchCache: Te(1e3),
            flatCache: null,
            masksTree: null
        },
        routesById: a,
        routesByPath: o
    }
}

function Ve(e, t, n = !1) {
    let r = e.split(`/`),
        i = Ge(e, r, t, n);
    if (!i) return null;
    let [a] = He(e, r, i);
    return {
        route: i.node.route,
        rawParams: a
    }
}

function He(e, t, n) {
    let r = We(n.node),
        i = null,
        a = Object.create(null),
        o = n.extract ? .part ? ? 0,
        s = n.extract ? .node ? ? 0,
        c = n.extract ? .path ? ? 0,
        l = n.extract ? .segment ? ? 0;
    for (; s < r.length; o++, s++, c++, l++) {
        let u = r[s];
        if (u.kind === Ee) break;
        if (u.kind === De) {
            l--, o--, c--;
            continue
        }
        let d = t[o],
            f = c;
        if (d && (c += d.length), u.kind === 1) {
            i ? ? = n.node.fullPath.split(`/`);
            let e = i[l],
                t = u.prefix ? .length ? ? 0;
            if (e.charCodeAt(t) === 123) {
                let n = u.suffix ? .length ? ? 0,
                    r = e.substring(t + 2, e.length - n - 1),
                    i = d.substring(t, d.length - n);
                a[r] = decodeURIComponent(i)
            } else {
                let t = e.substring(1);
                a[t] = decodeURIComponent(d)
            }
        } else if (u.kind === 3) {
            if (n.skipped & 1 << s) {
                o--, c = f - 1;
                continue
            }
            i ? ? = n.node.fullPath.split(`/`);
            let e = i[l],
                t = u.prefix ? .length ? ? 0,
                r = u.suffix ? .length ? ? 0,
                p = e.substring(t + 3, e.length - r - 1),
                m = u.suffix || u.prefix ? d.substring(t, d.length - r) : d;
            m && (a[p] = decodeURIComponent(m))
        } else if (u.kind === 2) {
            let t = u,
                n = e.substring(f + (t.prefix ? .length ? ? 0), e.length - (t.suffix ? .length ? ? 0)),
                r = decodeURIComponent(n);
            a[`*`] = r, a._splat = r;
            break
        }
    }
    return n.rawParams && Object.assign(a, n.rawParams), [a, {
        part: o,
        node: s,
        path: c,
        segment: l
    }]
}

function Ue(e) {
    let t = [e];
    for (; e.parentRoute;) e = e.parentRoute, t.push(e);
    return t.reverse(), t
}

function We(e) {
    let t = Array(e.depth + 1);
    do t[e.depth] = e, e = e.parent; while (e);
    return t
}

function Ge(e, t, n, r) {
    if (e === `/` && n.index) return {
        node: n.index,
        skipped: 0
    };
    let i = !te(t),
        a = i && e !== `/`,
        o = t.length - +!!i,
        s = [{
            node: n,
            index: 1,
            skipped: 0,
            depth: 1,
            statics: 0,
            dynamics: 0,
            optionals: 0
        }],
        c = null,
        l = null;
    for (; s.length;) {
        let n = s.pop(),
            {
                node: i,
                index: u,
                skipped: d,
                depth: f,
                statics: p,
                dynamics: m,
                optionals: h
            } = n,
            {
                extract: g,
                rawParams: _
            } = n;
        if (i.kind === 2 && i.route && !Ye(l, n)) continue;
        if (i.parse) {
            if (!Je(e, t, n)) continue;
            _ = n.rawParams, g = n.extract
        }
        r && i.route && i.kind !== Ee && Ye(c, n) && (c = n);
        let v = u === o;
        if (v && (i.route && (!a || i.kind === Ee || i.kind === 2) && Ye(l, n) && (l = n), !i.optional && !i.wildcard && !i.index && !i.pathless)) continue;
        let y = v ? void 0 : t[u],
            b;
        if (v && i.index) {
            let n = {
                    node: i.index,
                    index: u,
                    skipped: d,
                    depth: f + 1,
                    statics: p,
                    dynamics: m,
                    optionals: h,
                    extract: g,
                    rawParams: _
                },
                r = !0;
            if (i.index.parse && (Je(e, t, n) || (r = !1)), r) {
                if (!m && !h && !d && qe(p, o)) return n;
                Ye(l, n) && (l = n)
            }
        }
        if (i.wildcard)
            for (let e = i.wildcard.length - 1; e >= 0; e--) {
                let n = i.wildcard[e],
                    {
                        prefix: r,
                        suffix: a
                    } = n;
                if (!(r && (v || !(n.caseSensitive ? y : b ? ? = y.toLowerCase()).startsWith(r)))) {
                    if (a) {
                        if (v) continue;
                        let e = t.slice(u).join(`/`).slice(-a.length);
                        if ((n.caseSensitive ? e : e.toLowerCase()) !== a) continue
                    }
                    s.push({
                        node: n,
                        index: o,
                        skipped: d,
                        depth: f + 1,
                        statics: p,
                        dynamics: m,
                        optionals: h,
                        extract: g,
                        rawParams: _
                    })
                }
            }
        if (i.optional) {
            let e = d | 1 << f,
                t = f + 1;
            for (let n = i.optional.length - 1; n >= 0; n--) {
                let r = i.optional[n];
                s.push({
                    node: r,
                    index: u,
                    skipped: e,
                    depth: t,
                    statics: p,
                    dynamics: m,
                    optionals: h,
                    extract: g,
                    rawParams: _
                })
            }
            if (!v)
                for (let e = i.optional.length - 1; e >= 0; e--) {
                    let n = i.optional[e],
                        {
                            prefix: r,
                            suffix: a
                        } = n;
                    if (r || a) {
                        let e = n.caseSensitive ? y : b ? ? = y.toLowerCase();
                        if (r && !e.startsWith(r) || a && !e.endsWith(a)) continue
                    }
                    s.push({
                        node: n,
                        index: u + 1,
                        skipped: d,
                        depth: t,
                        statics: p,
                        dynamics: m,
                        optionals: h + Ke(o, u),
                        extract: g,
                        rawParams: _
                    })
                }
        }
        if (!v && i.dynamic && y)
            for (let e = i.dynamic.length - 1; e >= 0; e--) {
                let t = i.dynamic[e],
                    {
                        prefix: n,
                        suffix: r
                    } = t;
                if (n || r) {
                    let e = t.caseSensitive ? y : b ? ? = y.toLowerCase();
                    if (n && !e.startsWith(n) || r && !e.endsWith(r)) continue
                }
                s.push({
                    node: t,
                    index: u + 1,
                    skipped: d,
                    depth: f + 1,
                    statics: p,
                    dynamics: m + Ke(o, u),
                    optionals: h,
                    extract: g,
                    rawParams: _
                })
            }
        if (!v && i.staticInsensitive) {
            let e = i.staticInsensitive.get(b ? ? = y.toLowerCase());
            e && s.push({
                node: e,
                index: u + 1,
                skipped: d,
                depth: f + 1,
                statics: p + Ke(o, u),
                dynamics: m,
                optionals: h,
                extract: g,
                rawParams: _
            })
        }
        if (!v && i.static) {
            let e = i.static.get(y);
            e && s.push({
                node: e,
                index: u + 1,
                skipped: d,
                depth: f + 1,
                statics: p + Ke(o, u),
                dynamics: m,
                optionals: h,
                extract: g,
                rawParams: _
            })
        }
        if (i.pathless) {
            let e = f + 1;
            for (let t = i.pathless.length - 1; t >= 0; t--) {
                let n = i.pathless[t];
                s.push({
                    node: n,
                    index: u,
                    skipped: d,
                    depth: e,
                    statics: p,
                    dynamics: m,
                    optionals: h,
                    extract: g,
                    rawParams: _
                })
            }
        }
    }
    if (l) return l;
    if (r && c) {
        let n = c.index;
        for (let e = 0; e < c.index; e++) n += t[e].length;
        let r = n === e.length ? `/` : e.slice(n);
        return c.rawParams ? ? = Object.create(null), c.rawParams[`**`] = decodeURIComponent(r), c
    }
    return null
}

function Ke(e, t) {
    return 2 ** (e - t - 1)
}

function qe(e, t) {
    return e === 2 ** (t - 1) - 1
}

function Je(e, t, n) {
    let r, i;
    try {
        [r, i] = He(e, t, n)
    } catch {
        return null
    }
    if (n.rawParams = r, n.extract = i, !n.node.parse) return !0;
    try {
        if (n.node.parse(r) === !1) return null
    } catch {}
    return !0
}

function Ye(e, t) {
    return e ? t.statics > e.statics || t.statics === e.statics && (t.dynamics > e.dynamics || t.dynamics === e.dynamics && (t.optionals > e.optionals || t.optionals === e.optionals && ((t.node.kind === Ee) > (e.node.kind === Ee) || t.node.kind === Ee == (e.node.kind === Ee) && t.depth > e.depth))) : !0
}

function Xe(e) {
    return Ze(e.filter(e => e !== void 0).join(`/`))
}

function Ze(e) {
    return e.replace(/\/{2,}/g, `/`)
}

function Qe(e) {
    return e === `/` ? e : e.replace(/^\/{1,}/, ``)
}

function $e(e) {
    let t = e.length;
    return t > 1 && e[t - 1] === `/` ? e.replace(/\/{1,}$/, ``) : e
}

function et(e) {
    return $e(Qe(e))
}

function tt(e, t) {
    return e ? .endsWith(`/`) && e !== `/` && e !== `${t}/` ? e.slice(0, -1) : e
}

function nt(e, t, n) {
    return tt(e, n) === tt(t, n)
}

function rt({
    base: e,
    to: t,
    trailingSlash: n = `never`,
    cache: r
}) {
    let i = t.startsWith(`/`),
        a = !i && t === `.`,
        o;
    if (r) {
        o = i ? t : a ? e : e + `\0` + t;
        let n = r.get(o);
        if (n) return n
    }
    let s;
    if (a) s = e.split(`/`);
    else if (i) s = t.split(`/`);
    else {
        for (s = e.split(`/`); s.length > 1 && te(s) === ``;) s.pop();
        let n = t.split(`/`);
        for (let e = 0, t = n.length; e < t; e++) {
            let r = n[e];
            r === `` ? e ? e === t - 1 && s.push(r) : s = [r] : r === `..` ? s.pop() : r === `.` || s.push(r)
        }
    }
    s.length > 1 && (te(s) === `` ? n === `never` && s.pop() : n === `always` && s.push(``));
    let c = Ze(s.join(`/`)) || `/`;
    return o && r && r.set(o, c), c
}

function it(e) {
    let t = new Map(e.map(e => [encodeURIComponent(e), e])),
        n = Array.from(t.keys()).map(e => e.replace(/[.*+?^${}()|[\]\\]/g, `\\$&`)).join(`|`),
        r = new RegExp(n, `g`);
    return e => e.replace(r, e => t.get(e) ? ? e)
}

function at(e, t, n) {
    let r = t[e];
    return typeof r == `string` ? e === `_splat` ? /^[a-zA-Z0-9\-._~!/]*$/.test(r) ? r : r.split(`/`).map(e => st(e, n)).join(`/`) : st(r, n) : r
}

function ot({
    path: e,
    params: t,
    decoder: n,
    ...r
}) {
    let i = !1,
        a = Object.create(null);
    if (!e || e === `/`) return {
        interpolatedPath: `/`,
        usedParams: a,
        isMissingParams: i
    };
    if (!e.includes(`$`)) return {
        interpolatedPath: e,
        usedParams: a,
        isMissingParams: i
    };
    let o = e.length,
        s = 0,
        c, l = ``;
    for (; s < o;) {
        let r = s;
        c = ke(e, r, c);
        let o = c[5];
        if (s = o + 1, r === o) continue;
        let u = c[0];
        if (u === 0) {
            l += `/` + e.substring(r, o);
            continue
        }
        if (u === 2) {
            let s = t._splat;
            a._splat = s, a[`*`] = s;
            let u = e.substring(r, c[1]),
                d = e.substring(c[4], o);
            if (!s) {
                i = !0, (u || d) && (l += `/` + u + d);
                continue
            }
            let f = at(`_splat`, t, n);
            l += `/` + u + f + d;
            continue
        }
        if (u === 1) {
            let s = e.substring(c[2], c[3]);
            !i && !(s in t) && (i = !0), a[s] = t[s];
            let u = e.substring(r, c[1]),
                d = e.substring(c[4], o),
                f = at(s, t, n) ? ? `undefined`;
            l += `/` + u + f + d;
            continue
        }
        if (u === 3) {
            let i = e.substring(c[2], c[3]),
                s = t[i];
            if (s == null) continue;
            a[i] = s;
            let u = e.substring(r, c[1]),
                d = e.substring(c[4], o),
                f = at(i, t, n) ? ? ``;
            l += `/` + u + f + d;
            continue
        }
    }
    return e.endsWith(`/`) && (l += `/`), {
        usedParams: a,
        interpolatedPath: l || `/`,
        isMissingParams: i
    }
}

function st(e, t) {
    let n = encodeURIComponent(e);
    return t ? .(n) ? ? n
}

function ct(e) {
    return e ? .isNotFound === !0
}

function lt(e, t = String) {
    let n = new URLSearchParams;
    for (let r in e) {
        let i = e[r];
        i !== void 0 && n.set(r, t(i))
    }
    return n.toString()
}

function ut(e) {
    return e ? e === `false` ? !1 : e === `true` ? !0 : e * 0 == 0 && +e + `` === e ? +e : e : ``
}

function dt(e) {
    let t = new URLSearchParams(e),
        n = Object.create(null);
    for (let [e, r] of t.entries()) {
        let t = n[e];
        t == null ? n[e] = ut(r) : Array.isArray(t) ? t.push(ut(r)) : n[e] = [t, ut(r)]
    }
    return n
}
var ft = mt(JSON.parse),
    pt = ht(JSON.stringify, JSON.parse);

function mt(e) {
    return t => {
        t[0] === `?` && (t = t.substring(1));
        let n = dt(t);
        for (let t in n) {
            let r = n[t];
            if (typeof r == `string`) try {
                n[t] = e(r)
            } catch {}
        }
        return n
    }
}

function ht(e, t) {
    let n = typeof t == `function`;

    function r(r) {
        if (typeof r == `object` && r) try {
            return e(r)
        } catch {} else if (n && typeof r == `string`) try {
            return t(r), e(r)
        } catch {}
        return r
    }
    return e => {
        let t = lt(e, r);
        return t ? `?${t}` : ``
    }
}
var gt = `__root__`;

function _t(e) {
    if (e.statusCode = e.statusCode || e.code || 307, !e._builtLocation && !e.reloadDocument && typeof e.href == `string`) try {
        new URL(e.href), e.reloadDocument = !0
    } catch {}
    let t = new Headers(e.headers);
    e.href && t.get(`Location`) === null && t.set(`Location`, e.href);
    let n = new Response(null, {
        status: e.statusCode,
        headers: t
    });
    if (n.options = e, e.throw) throw n;
    return n
}

function k(e) {
    return e instanceof Response && !!e.options
}

function vt(e) {
    if (typeof e == `object` && e && e.isSerializedRedirect) return _t(e)
}
var yt = e => {
        if (!e.rendered) return e.rendered = !0, e.onReady ? .()
    },
    bt = e => e.stores.matchesId.get().some(t => e.stores.matchStores.get(t) ? .get()._forcePending),
    xt = (e, t) => !!(e.preload && !e.router.stores.matchStores.has(t)),
    St = (e, t, n = !0) => {
        let r = { ...e.router.options.context ? ? {}
            },
            i = n ? t : t - 1;
        for (let t = 0; t <= i; t++) {
            let n = e.matches[t];
            if (!n) continue;
            let i = e.router.getMatch(n.id);
            i && Object.assign(r, i.__routeContext, i.__beforeLoadContext)
        }
        return r
    },
    Ct = (e, t) => {
        if (!e.matches.length) return;
        let n = t.routeId,
            r = e.matches.findIndex(t => t.routeId === e.router.routeTree.id),
            i = r >= 0 ? r : 0,
            a = n ? e.matches.findIndex(e => e.routeId === n) : e.firstBadMatchIndex ? ? e.matches.length - 1;
        a < 0 && (a = i);
        for (let t = a; t >= 0; t--) {
            let n = e.matches[t];
            if (e.router.looseRoutesById[n.routeId].options.notFoundComponent) return t
        }
        return n ? a : i
    },
    wt = (e, t, n) => {
        if (!(!k(n) && !ct(n))) throw k(n) && n.redirectHandled && !n.options.reloadDocument ? n : (t && (t._nonReactive.beforeLoadPromise ? .resolve(), t._nonReactive.loaderPromise ? .resolve(), t._nonReactive.beforeLoadPromise = void 0, t._nonReactive.loaderPromise = void 0, t._nonReactive.error = n, e.updateMatch(t.id, r => ({ ...r,
            status: k(n) ? `redirected` : ct(n) ? `notFound` : r.status === `pending` ? `success` : r.status,
            context: St(e, t.index),
            isFetching: !1,
            error: n
        })), ct(n) && !n.routeId && (n.routeId = t.routeId), t._nonReactive.loadPromise ? .resolve()), k(n) && (e.rendered = !0, n.options._fromLocation = e.location, n.redirectHandled = !0, n = e.router.resolveRedirect(n)), n)
    },
    Tt = (e, t) => {
        let n = e.router.getMatch(t);
        return !!(!n || n._nonReactive.dehydrated)
    },
    Et = (e, t, n) => {
        let r = St(e, n);
        e.updateMatch(t, e => ({ ...e,
            context: r
        }))
    },
    Dt = (e, t, n) => {
        let {
            id: r,
            routeId: i
        } = e.matches[t], a = e.router.looseRoutesById[i];
        if (n instanceof Promise) throw n;
        e.firstBadMatchIndex ? ? = t, wt(e, e.router.getMatch(r), n);
        try {
            a.options.onError ? .(n)
        } catch (t) {
            n = t, wt(e, e.router.getMatch(r), n)
        }
        e.updateMatch(r, e => (e._nonReactive.beforeLoadPromise ? .resolve(), e._nonReactive.beforeLoadPromise = void 0, e._nonReactive.loadPromise ? .resolve(), { ...e,
            error: n,
            status: `error`,
            isFetching: !1,
            updatedAt: Date.now(),
            abortController: new AbortController
        })), !e.preload && !k(n) && !ct(n) && (e.serialError ? ? = n)
    },
    Ot = (e, t, n, r) => {
        if (r._nonReactive.pendingTimeout !== void 0) return;
        let i = n.options.pendingMs ? ? e.router.options.defaultPendingMs;
        if (e.onReady && !xt(e, t) && (n.options.loader || n.options.beforeLoad || zt(n)) && typeof i == `number` && i !== 1 / 0 && (n.options.pendingComponent ? ? e.router.options ? .defaultPendingComponent)) {
            let t = setTimeout(() => {
                yt(e)
            }, i);
            r._nonReactive.pendingTimeout = t
        }
    },
    kt = (e, t, n) => {
        let r = e.router.getMatch(t);
        if (!r._nonReactive.beforeLoadPromise && !r._nonReactive.loaderPromise) return;
        Ot(e, t, n, r);
        let i = () => {
            let n = e.router.getMatch(t);
            n.preload && (n.status === `redirected` || n.status === `notFound`) && wt(e, n, n.error)
        };
        return r._nonReactive.beforeLoadPromise ? r._nonReactive.beforeLoadPromise.then(i) : i()
    },
    At = (e, t, n, r) => {
        let i = e.router.getMatch(t),
            a = i._nonReactive.loadPromise;
        i._nonReactive.loadPromise = pe(() => {
            a ? .resolve(), a = void 0
        });
        let {
            paramsError: o,
            searchError: s
        } = i;
        o && Dt(e, n, o), s && Dt(e, n, s), Ot(e, t, r, i);
        let c = new AbortController,
            l = !1,
            u = () => {
                l || (l = !0, e.updateMatch(t, e => ({ ...e,
                    isFetching: `beforeLoad`,
                    fetchCount: e.fetchCount + 1,
                    abortController: c
                })))
            },
            d = () => {
                i._nonReactive.beforeLoadPromise ? .resolve(), i._nonReactive.beforeLoadPromise = void 0, e.updateMatch(t, e => ({ ...e,
                    isFetching: !1
                }))
            };
        if (!r.options.beforeLoad) {
            e.router.batch(() => {
                u(), d()
            });
            return
        }
        i._nonReactive.beforeLoadPromise = pe();
        let f = { ...St(e, n, !1),
                ...i.__routeContext
            },
            {
                search: p,
                params: m,
                cause: h
            } = i,
            g = xt(e, t),
            _ = {
                search: p,
                abortController: c,
                params: m,
                preload: g,
                context: f,
                location: e.location,
                navigate: t => e.router.navigate({ ...t,
                    _fromLocation: e.location
                }),
                buildLocation: e.router.buildLocation,
                cause: g ? `preload` : h,
                matches: e.matches,
                routeId: r.id,
                ...e.router.options.additionalContext
            },
            v = r => {
                if (r === void 0) {
                    e.router.batch(() => {
                        u(), d()
                    });
                    return
                }(k(r) || ct(r)) && (u(), Dt(e, n, r)), e.router.batch(() => {
                    u(), e.updateMatch(t, e => ({ ...e,
                        __beforeLoadContext: r
                    })), d()
                })
            },
            y;
        try {
            if (y = r.options.beforeLoad(_), he(y)) return u(), y.catch(t => {
                Dt(e, n, t)
            }).then(v)
        } catch (t) {
            u(), Dt(e, n, t)
        }
        v(y)
    },
    jt = (e, t) => {
        let {
            id: n,
            routeId: r
        } = e.matches[t], i = e.router.looseRoutesById[r], a = () => s(), o = () => At(e, n, t, i), s = () => {
            if (Tt(e, n)) return;
            let t = kt(e, n, i);
            return he(t) ? t.then(o) : o()
        };
        return a()
    },
    Mt = (e, t, n) => {
        let r = e.router.getMatch(t);
        if (!r || !n.options.head && !n.options.scripts && !n.options.headers) return;
        let i = {
            ssr: e.router.options.ssr,
            matches: e.matches,
            match: r,
            params: r.params,
            loaderData: r.loaderData
        };
        return Promise.all([n.options.head ? .(i), n.options.scripts ? .(i), n.options.headers ? .(i)]).then(([e, t, n]) => ({
            meta: e ? .meta,
            links: e ? .links,
            headScripts: e ? .scripts,
            headers: n,
            scripts: t,
            styles: e ? .styles
        }))
    },
    Nt = (e, t, n, r, i) => {
        let a = t[r - 1],
            {
                params: o,
                loaderDeps: s,
                abortController: c,
                cause: l
            } = e.router.getMatch(n),
            u = St(e, r),
            d = xt(e, n);
        return {
            params: o,
            deps: s,
            preload: !!d,
            parentMatchPromise: a,
            abortController: c,
            context: u,
            location: e.location,
            navigate: t => e.router.navigate({ ...t,
                _fromLocation: e.location
            }),
            cause: d ? `preload` : l,
            route: i,
            ...e.router.options.additionalContext
        }
    },
    Pt = async (e, t, n, r, i) => {
        try {
            let a = e.router.getMatch(n);
            try {
                Rt(i);
                let o = i.options.loader,
                    s = typeof o == `function` ? o : o ? .handler,
                    c = s ? .(Nt(e, t, n, r, i)),
                    l = !!s && he(c);
                if ((l || i._lazyPromise || i._componentsPromise || i.options.head || i.options.scripts || i.options.headers || a._nonReactive.minPendingPromise) && e.updateMatch(n, e => ({ ...e,
                        isFetching: `loader`
                    })), s) {
                    let t = l ? await c : c;
                    wt(e, e.router.getMatch(n), t), t !== void 0 && e.updateMatch(n, e => ({ ...e,
                        loaderData: t
                    }))
                }
                i._lazyPromise && await i._lazyPromise;
                let u = a._nonReactive.minPendingPromise;
                u && await u, i._componentsPromise && await i._componentsPromise, e.updateMatch(n, t => ({ ...t,
                    error: void 0,
                    context: St(e, r),
                    status: `success`,
                    isFetching: !1,
                    updatedAt: Date.now()
                }))
            } catch (t) {
                let o = t;
                if (o ? .name === `AbortError`) {
                    if (a.abortController.signal.aborted) {
                        a._nonReactive.loaderPromise ? .resolve(), a._nonReactive.loaderPromise = void 0;
                        return
                    }
                    e.updateMatch(n, t => ({ ...t,
                        status: t.status === `pending` ? `success` : t.status,
                        isFetching: !1,
                        context: St(e, r)
                    }));
                    return
                }
                let s = a._nonReactive.minPendingPromise;
                s && await s, ct(t) && await i.options.notFoundComponent ? .preload ? .(), wt(e, e.router.getMatch(n), t);
                try {
                    i.options.onError ? .(t)
                } catch (t) {
                    o = t, wt(e, e.router.getMatch(n), t)
                }!k(o) && !ct(o) && await Rt(i, [`errorComponent`]), e.updateMatch(n, t => ({ ...t,
                    error: o,
                    context: St(e, r),
                    status: `error`,
                    isFetching: !1
                }))
            }
        } catch (t) {
            let r = e.router.getMatch(n);
            r && (r._nonReactive.loaderPromise = void 0), wt(e, r, t)
        }
    },
    Ft = async (e, t, n) => {
        async function r(r, a, c, l, d) {
            let f = Date.now() - a.updatedAt,
                p = r ? d.options.preloadStaleTime ? ? e.router.options.defaultPreloadStaleTime ? ? 3e4 : d.options.staleTime ? ? e.router.options.defaultStaleTime ? ? 0,
                m = d.options.shouldReload,
                h = typeof m == `function` ? m(Nt(e, t, i, n, d)) : m,
                {
                    status: g,
                    invalid: _
                } = l,
                v = f >= p && (!!e.forceStaleReload || l.cause === `enter` || c !== void 0 && c !== l.id);
            o = g === `success` && (_ || (h ? ? v)), r && d.options.preload === !1 || (o && !e.sync && u ? (s = !0, (async () => {
                try {
                    await Pt(e, t, i, n, d);
                    let r = e.router.getMatch(i);
                    r._nonReactive.loaderPromise ? .resolve(), r._nonReactive.loadPromise ? .resolve(), r._nonReactive.loaderPromise = void 0, r._nonReactive.loadPromise = void 0
                } catch (t) {
                    k(t) && await e.router.navigate(t.options)
                }
            })()) : g !== `success` || o ? await Pt(e, t, i, n, d) : Et(e, i, n))
        }
        let {
            id: i,
            routeId: a
        } = e.matches[n], o = !1, s = !1, c = e.router.looseRoutesById[a], l = c.options.loader, u = ((typeof l == `function` ? void 0 : l ? .staleReloadMode) ? ? e.router.options.defaultStaleReloadMode) !== `blocking`;
        if (Tt(e, i)) {
            if (!e.router.getMatch(i)) return e.matches[n];
            Et(e, i, n)
        } else {
            let t = e.router.getMatch(i),
                o = e.router.stores.matchesId.get()[n],
                s = (o && e.router.stores.matchStores.get(o) || null) ? .routeId === a ? o : e.router.stores.matches.get().find(e => e.routeId === a) ? .id,
                l = xt(e, i);
            if (t._nonReactive.loaderPromise) {
                if (t.status === `success` && !e.sync && !t.preload && u) return t;
                await t._nonReactive.loaderPromise;
                let n = e.router.getMatch(i),
                    a = n._nonReactive.error || n.error;
                a && wt(e, n, a), n.status === `pending` && await r(l, t, s, n, c)
            } else {
                let n = l && !e.router.stores.matchStores.has(i),
                    a = e.router.getMatch(i);
                a._nonReactive.loaderPromise = pe(), n !== a.preload && e.updateMatch(i, e => ({ ...e,
                    preload: n
                })), await r(l, t, s, a, c)
            }
        }
        let d = e.router.getMatch(i);
        s || (d._nonReactive.loaderPromise ? .resolve(), d._nonReactive.loadPromise ? .resolve(), d._nonReactive.loadPromise = void 0), clearTimeout(d._nonReactive.pendingTimeout), d._nonReactive.pendingTimeout = void 0, s || (d._nonReactive.loaderPromise = void 0), d._nonReactive.dehydrated = void 0;
        let f = s ? d.isFetching : !1;
        return f !== d.isFetching || d.invalid !== !1 ? (e.updateMatch(i, e => ({ ...e,
            isFetching: f,
            invalid: !1
        })), e.router.getMatch(i)) : d
    };
async function It(e) {
    let t = e,
        n = [];
    bt(t.router) && yt(t);
    let r;
    for (let e = 0; e < t.matches.length; e++) {
        try {
            let n = jt(t, e);
            he(n) && await n
        } catch (e) {
            if (k(e)) throw e;
            if (ct(e)) r = e;
            else if (!t.preload) throw e;
            break
        }
        if (t.serialError || t.firstBadMatchIndex != null) break
    }
    let i = t.firstBadMatchIndex ? ? t.matches.length,
        a = r && !t.preload ? Ct(t, r) : void 0,
        o = r && t.preload ? 0 : a === void 0 ? i : Math.min(a + 1, i),
        s, c;
    for (let e = 0; e < o; e++) n.push(Ft(t, n, e));
    try {
        await Promise.all(n)
    } catch {
        let e = await Promise.allSettled(n);
        for (let t of e) {
            if (t.status !== `rejected`) continue;
            let e = t.reason;
            if (k(e)) throw e;
            ct(e) ? s ? ? = e : c ? ? = e
        }
        if (c !== void 0) throw c
    }
    let l = s ? ? (r && !t.preload ? r : void 0),
        u = t.firstBadMatchIndex === void 0 ? t.matches.length - 1 : t.firstBadMatchIndex;
    if (!l && r && t.preload) return t.matches;
    if (l) {
        let e = Ct(t, l);
        e === void 0 && we();
        let n = t.matches[e],
            r = t.router.looseRoutesById[n.routeId],
            i = t.router.options ? .defaultNotFoundComponent;
        !r.options.notFoundComponent && i && (r.options.notFoundComponent = i), l.routeId = n.routeId;
        let a = n.routeId === t.router.routeTree.id;
        t.updateMatch(n.id, e => ({ ...e,
            ...a ? {
                status: `success`,
                globalNotFound: !0,
                error: void 0
            } : {
                status: `notFound`,
                error: l
            },
            isFetching: !1
        })), u = e, await Rt(r, [`notFoundComponent`])
    } else if (!t.preload) {
        let e = t.matches[0];
        e.globalNotFound || t.router.getMatch(e.id) ? .globalNotFound && t.updateMatch(e.id, e => ({ ...e,
            globalNotFound: !1,
            error: void 0
        }))
    }
    if (t.serialError && t.firstBadMatchIndex !== void 0) {
        let e = t.router.looseRoutesById[t.matches[t.firstBadMatchIndex].routeId];
        await Rt(e, [`errorComponent`])
    }
    for (let e = 0; e <= u; e++) {
        let {
            id: n,
            routeId: r
        } = t.matches[e], i = t.router.looseRoutesById[r];
        try {
            let e = Mt(t, n, i);
            if (e) {
                let r = await e;
                t.updateMatch(n, e => ({ ...e,
                    ...r
                }))
            }
        } catch (e) {
            console.error(`Error executing head for route ${r}:`, e)
        }
    }
    let d = yt(t);
    if (he(d) && await d, l) throw l;
    if (t.serialError && !t.preload && !t.onReady) throw t.serialError;
    return t.matches
}

function Lt(e, t) {
    let n = t.map(t => e.options[t] ? .preload ? .()).filter(Boolean);
    if (n.length !== 0) return Promise.all(n)
}

function Rt(e, t = Bt) {
    !e._lazyLoaded && e._lazyPromise === void 0 && (e.lazyFn ? e._lazyPromise = e.lazyFn().then(t => {
        let {
            id: n,
            ...r
        } = t.options;
        Object.assign(e.options, r), e._lazyLoaded = !0, e._lazyPromise = void 0
    }) : e._lazyLoaded = !0);
    let n = () => e._componentsLoaded ? void 0 : t === Bt ? (() => {
        if (e._componentsPromise === void 0) {
            let t = Lt(e, Bt);
            t ? e._componentsPromise = t.then(() => {
                e._componentsLoaded = !0, e._componentsPromise = void 0
            }) : e._componentsLoaded = !0
        }
        return e._componentsPromise
    })() : Lt(e, t);
    return e._lazyPromise ? e._lazyPromise.then(n) : n()
}

function zt(e) {
    for (let t of Bt)
        if (e.options[t] ? .preload) return !0;
    return !1
}
var Bt = [`component`, `errorComponent`, `pendingComponent`, `notFoundComponent`];

function Vt(e) {
    return {
        input: ({
            url: t
        }) => {
            for (let n of e) t = Ut(n, t);
            return t
        },
        output: ({
            url: t
        }) => {
            for (let n = e.length - 1; n >= 0; n--) t = Wt(e[n], t);
            return t
        }
    }
}

function Ht(e) {
    let t = et(e.basepath),
        n = `/${t}`,
        r = e.caseSensitive ? n : n.toLowerCase(),
        i = `${r}/`;
    return {
        input: ({
            url: t
        }) => {
            let a = e.caseSensitive ? t.pathname : t.pathname.toLowerCase();
            return a === r ? t.pathname = `/` : a.startsWith(i) && (t.pathname = t.pathname.slice(n.length)), t
        },
        output: ({
            url: e
        }) => (e.pathname = Xe([`/`, t, e.pathname]), e)
    }
}

function Ut(e, t) {
    let n = e ? .input ? .({
        url: t
    });
    if (n) {
        if (typeof n == `string`) return new URL(n);
        if (n instanceof URL) return n
    }
    return t
}

function Wt(e, t) {
    let n = e ? .output ? .({
        url: t
    });
    if (n) {
        if (typeof n == `string`) return new URL(n);
        if (n instanceof URL) return n
    }
    return t
}

function Gt(e, t) {
    let {
        createMutableStore: n,
        createReadonlyStore: r,
        batch: i,
        init: a
    } = t, o = new Map, s = new Map, c = new Map, l = n(e.status), u = n(e.loadedAt), d = n(e.isLoading), f = n(e.isTransitioning), p = n(e.location), m = n(e.resolvedLocation), h = n(e.statusCode), g = n(e.redirect), _ = n([]), v = n([]), y = n([]), b = r(() => Kt(o, _.get())), x = r(() => Kt(s, v.get())), ee = r(() => Kt(c, y.get())), S = r(() => _.get()[0]), C = r(() => _.get().some(e => o.get(e) ? .get().status === `pending`)), te = r(() => ({
        locationHref: p.get().href,
        resolvedLocationHref: m.get() ? .href,
        status: l.get()
    })), ne = r(() => ({
        status: l.get(),
        loadedAt: u.get(),
        isLoading: d.get(),
        isTransitioning: f.get(),
        matches: b.get(),
        location: p.get(),
        resolvedLocation: m.get(),
        statusCode: h.get(),
        redirect: g.get()
    })), re = Te(64);

    function ie(e) {
        let t = re.get(e);
        return t || (t = r(() => {
            let t = _.get();
            for (let n of t) {
                let t = o.get(n);
                if (t && t.routeId === e) return t.get()
            }
        }), re.set(e, t)), t
    }
    let ae = {
        status: l,
        loadedAt: u,
        isLoading: d,
        isTransitioning: f,
        location: p,
        resolvedLocation: m,
        statusCode: h,
        redirect: g,
        matchesId: _,
        pendingIds: v,
        cachedIds: y,
        matches: b,
        pendingMatches: x,
        cachedMatches: ee,
        firstId: S,
        hasPending: C,
        matchRouteDeps: te,
        matchStores: o,
        pendingMatchStores: s,
        cachedMatchStores: c,
        __store: ne,
        getRouteMatchStore: ie,
        setMatches: oe,
        setPending: se,
        setCached: ce
    };
    oe(e.matches), a ? .(ae);

    function oe(e) {
        qt(e, o, _, n, i)
    }

    function se(e) {
        qt(e, s, v, n, i)
    }

    function ce(e) {
        qt(e, c, y, n, i)
    }
    return ae
}

function Kt(e, t) {
    let n = [];
    for (let r of t) {
        let t = e.get(r);
        t && n.push(t.get())
    }
    return n
}

function qt(e, t, n, r, i) {
    let a = e.map(e => e.id),
        o = new Set(a);
    i(() => {
        for (let e of t.keys()) o.has(e) || t.delete(e);
        for (let n of e) {
            let e = t.get(n.id);
            if (!e) {
                let e = r(n);
                e.routeId = n.routeId, t.set(n.id, e);
                continue
            }
            e.routeId = n.routeId, e.get() !== n && e.set(n)
        }
        Ce(n.get(), a) || n.set(a)
    })
}
var Jt = `__TSR_index`,
    Yt = `popstate`,
    Xt = `beforeunload`;

function Zt(e) {
    let t = e.getLocation(),
        n = new Set,
        r = r => {
            t = e.getLocation(), n.forEach(e => e({
                location: t,
                action: r
            }))
        },
        i = n => {
            e.notifyOnIndexChange ? ? !0 ? r(n) : t = e.getLocation()
        },
        a = async ({
            task: n,
            navigateOpts: r,
            ...i
        }) => {
            if (r ? .ignoreBlocker ? ? !1) {
                n();
                return
            }
            let a = e.getBlockers ? .() ? ? [],
                o = i.type === `PUSH` || i.type === `REPLACE`;
            if (typeof document < `u` && a.length && o)
                for (let n of a) {
                    let r = tn(i.path, i.state);
                    if (await n.blockerFn({
                            currentLocation: t,
                            nextLocation: r,
                            action: i.type
                        })) {
                        e.onBlocked ? .();
                        return
                    }
                }
            n()
        };
    return {
        get location() {
            return t
        },
        get length() {
            return e.getLength()
        },
        subscribers: n,
        subscribe: e => (n.add(e), () => {
            n.delete(e)
        }),
        push: (n, i, o) => {
            let s = t.state[Jt];
            i = Qt(s + 1, i), a({
                task: () => {
                    e.pushState(n, i), r({
                        type: `PUSH`
                    })
                },
                navigateOpts: o,
                type: `PUSH`,
                path: n,
                state: i
            })
        },
        replace: (n, i, o) => {
            let s = t.state[Jt];
            i = Qt(s, i), a({
                task: () => {
                    e.replaceState(n, i), r({
                        type: `REPLACE`
                    })
                },
                navigateOpts: o,
                type: `REPLACE`,
                path: n,
                state: i
            })
        },
        go: (t, n) => {
            a({
                task: () => {
                    e.go(t), i({
                        type: `GO`,
                        index: t
                    })
                },
                navigateOpts: n,
                type: `GO`
            })
        },
        back: t => {
            a({
                task: () => {
                    e.back(t ? .ignoreBlocker ? ? !1), i({
                        type: `BACK`
                    })
                },
                navigateOpts: t,
                type: `BACK`
            })
        },
        forward: t => {
            a({
                task: () => {
                    e.forward(t ? .ignoreBlocker ? ? !1), i({
                        type: `FORWARD`
                    })
                },
                navigateOpts: t,
                type: `FORWARD`
            })
        },
        canGoBack: () => t.state[Jt] !== 0,
        createHref: t => e.createHref(t),
        block: t => {
            if (!e.setBlockers) return () => {};
            let n = e.getBlockers ? .() ? ? [];
            return e.setBlockers([...n, t]), () => {
                let n = e.getBlockers ? .() ? ? [];
                e.setBlockers ? .(n.filter(e => e !== t))
            }
        },
        flush: () => e.flush ? .(),
        destroy: () => e.destroy ? .(),
        notify: r
    }
}

function Qt(e, t) {
    t || = {};
    let n = nn();
    return { ...t,
        key: n,
        __TSR_key: n,
        [Jt]: e
    }
}

function $t(e) {
    let t = e ? .window ? ? (typeof document < `u` ? window : void 0),
        n = t.history.pushState,
        r = t.history.replaceState,
        i = [],
        a = () => i,
        o = e => i = e,
        s = e ? .createHref ? ? (e => e),
        c = e ? .parseLocation ? ? (() => tn(`${t.location.pathname}${t.location.search}${t.location.hash}`, t.history.state));
    if (!t.history.state ? .__TSR_key && !t.history.state ? .key) {
        let e = nn();
        t.history.replaceState({
            [Jt]: 0,
            key: e,
            __TSR_key: e
        }, ``)
    }
    let l = c(),
        u, d = !1,
        f = !1,
        p = !1,
        m = !1,
        h = () => l,
        g, _, v = () => {
            g && (S._ignoreSubscribers = !0, (g.isPush ? t.history.pushState : t.history.replaceState)(g.state, ``, g.href), S._ignoreSubscribers = !1, g = void 0, _ = void 0, u = void 0)
        },
        y = (e, t, n) => {
            let r = s(t);
            _ || (u = l), l = tn(t, n), g = {
                href: r,
                state: n,
                isPush: g ? .isPush || e === `push`
            }, _ || = Promise.resolve().then(() => v())
        },
        b = e => {
            l = c(), S.notify({
                type: e
            })
        },
        x = async () => {
            if (f) {
                f = !1;
                return
            }
            let e = c(),
                n = e.state[Jt] - l.state[Jt],
                r = n === 1,
                i = n === -1,
                o = !r && !i || d;
            d = !1;
            let s = o ? `GO` : i ? `BACK` : `FORWARD`,
                u = o ? {
                    type: `GO`,
                    index: n
                } : {
                    type: i ? `BACK` : `FORWARD`
                };
            if (p) p = !1;
            else {
                let n = a();
                if (typeof document < `u` && n.length) {
                    for (let r of n)
                        if (await r.blockerFn({
                                currentLocation: l,
                                nextLocation: e,
                                action: s
                            })) {
                            f = !0, t.history.go(1), S.notify(u);
                            return
                        }
                }
            }
            l = c(), S.notify(u)
        },
        ee = e => {
            if (m) {
                m = !1;
                return
            }
            let t = !1,
                n = a();
            if (typeof document < `u` && n.length)
                for (let e of n) {
                    let n = e.enableBeforeUnload ? ? !0;
                    if (n === !0) {
                        t = !0;
                        break
                    }
                    if (typeof n == `function` && n() === !0) {
                        t = !0;
                        break
                    }
                }
            if (t) return e.preventDefault(), e.returnValue = ``
        },
        S = Zt({
            getLocation: h,
            getLength: () => t.history.length,
            pushState: (e, t) => y(`push`, e, t),
            replaceState: (e, t) => y(`replace`, e, t),
            back: e => (e && (p = !0), m = !0, t.history.back()),
            forward: e => {
                e && (p = !0), m = !0, t.history.forward()
            },
            go: e => {
                d = !0, t.history.go(e)
            },
            createHref: e => s(e),
            flush: v,
            destroy: () => {
                t.history.pushState = n, t.history.replaceState = r, t.removeEventListener(Xt, ee, {
                    capture: !0
                }), t.removeEventListener(Yt, x)
            },
            onBlocked: () => {
                u && l !== u && (l = u)
            },
            getBlockers: a,
            setBlockers: o,
            notifyOnIndexChange: !1
        });
    return t.addEventListener(Xt, ee, {
        capture: !0
    }), t.addEventListener(Yt, x), t.history.pushState = function(...e) {
        let r = n.apply(t.history, e);
        return S._ignoreSubscribers || b(`PUSH`), r
    }, t.history.replaceState = function(...e) {
        let n = r.apply(t.history, e);
        return S._ignoreSubscribers || b(`REPLACE`), n
    }, S
}

function en(e) {
    let t = e.replace(/[\x00-\x1f\x7f]/g, ``);
    return t.startsWith(`//`) && (t = `/` + t.replace(/^\/+/, ``)), t
}

function tn(e, t) {
    let n = en(e),
        r = n.indexOf(`#`),
        i = n.indexOf(`?`),
        a = nn();
    return {
        href: n,
        pathname: n.substring(0, r > 0 ? i > 0 ? Math.min(r, i) : r : i > 0 ? i : n.length),
        hash: r > -1 ? n.substring(r) : ``,
        search: i > -1 ? n.slice(i, r === -1 ? void 0 : r) : ``,
        state: t || {
            [Jt]: 0,
            key: a,
            __TSR_key: a
        }
    }
}

function nn() {
    return (Math.random() + 1).toString(36).substring(7)
}

function rn(e) {
    return e instanceof Error ? {
        name: e.name,
        message: e.message
    } : {
        data: e
    }
}

function an(e, t) {
    let n = t,
        r = e;
    return {
        fromLocation: n,
        toLocation: r,
        pathChanged: n ? .pathname !== r.pathname,
        hrefChanged: n ? .href !== r.href,
        hashChanged: n ? .hash !== r.hash
    }
}
var on = new WeakMap,
    sn = class {
        constructor(e, t) {
            this.tempLocationKey = `${Math.round(Math.random()*1e7)}`, this._scroll = {
                next: !0
            }, this.shouldViewTransition = void 0, this.isViewTransitionTypesSupported = void 0, this.subscribers = new Set, this.routeBranchCache = new WeakMap, this.startTransition = e => e(), this.update = e => {
                let t = this.options,
                    n = this.basepath ? ? t ? .basepath ? ? `/`,
                    r = this.basepath === void 0,
                    i = t ? .rewrite;
                if (this.options = { ...t,
                        ...e
                    }, this.isServer = this.options.isServer ? ? typeof document > `u`, this.protocolAllowlist = new Set(this.options.protocolAllowlist), this.options.pathParamsAllowedCharacters && (this.pathParamsDecoder = it(this.options.pathParamsAllowedCharacters)), (!this.history || this.options.history && this.options.history !== this.history) && (this.options.history ? this.history = this.options.history : this.history = $t()), this.origin = this.options.origin, this.origin || (window ? .origin && window.origin !== `null` ? this.origin = window.origin : this.origin = `http://localhost`), this.history && this.updateLatestLocation(), this.options.routeTree !== this.routeTree) {
                    this.routeTree = this.options.routeTree;
                    let e;
                    this.resolvePathCache = Te(1e3), e = this.buildRouteTree(), this.setRoutes(e)
                }
                if (!this.stores && this.latestLocation) {
                    let e = this.getStoreConfig(this);
                    this.batch = e.batch, this.stores = Gt(un(this.latestLocation), e), An(this)
                }
                let a = !1,
                    o = this.options.basepath ? ? `/`,
                    s = this.options.rewrite;
                if (r || n !== o || i !== s) {
                    this.basepath = o;
                    let e = [],
                        t = et(o);
                    t && t !== `/` && e.push(Ht({
                        basepath: o
                    })), s && e.push(s), this.rewrite = e.length === 0 ? void 0 : e.length === 1 ? e[0] : Vt(e), this.history && this.updateLatestLocation(), a = !0
                }
                a && this.stores && this.stores.location.set(this.latestLocation), typeof window < `u` && `CSS` in window && typeof window.CSS ? .supports == `function` && (this.isViewTransitionTypesSupported = window.CSS.supports(`selector(:active-view-transition-type(a))`))
            }, this.updateLatestLocation = () => {
                this.latestLocation = this.parseLocation(this.history.location, this.latestLocation)
            }, this.buildRouteTree = () => {
                let e = Be(this.routeTree, this.options.caseSensitive, (e, t) => {
                    e.init({
                        originalIndex: t
                    })
                });
                return this.options.routeMasks && Fe(this.options.routeMasks, e.processedTree), e
            }, this.subscribe = (e, t) => {
                let n = {
                    eventType: e,
                    fn: t
                };
                return this.subscribers.add(n), () => {
                    this.subscribers.delete(n)
                }
            }, this.emit = e => {
                this.subscribers.forEach(t => {
                    t.eventType === e.type && t.fn(e)
                })
            }, this.parseLocation = (e, t) => {
                let n = ({
                        pathname: e,
                        search: n,
                        hash: r,
                        href: i,
                        state: a
                    }) => {
                        if (!this.rewrite && !/[ \x00-\x1f\x7f\u0080-\uffff]/.test(e)) {
                            let i = this.options.parseSearch(n),
                                o = this.options.stringifySearch(i);
                            return {
                                href: e + o + r,
                                publicHref: e + o + r,
                                pathname: xe(e).path,
                                external: !1,
                                searchStr: o,
                                search: ce(t ? .search, i),
                                hash: xe(r.slice(1)).path,
                                state: le(t ? .state, a)
                            }
                        }
                        let o = new URL(i, this.origin),
                            s = Ut(this.rewrite, o),
                            c = this.options.parseSearch(s.search),
                            l = this.options.stringifySearch(c);
                        return s.search = l, {
                            href: s.href.replace(s.origin, ``),
                            publicHref: i,
                            pathname: xe(s.pathname).path,
                            external: !!this.rewrite && s.origin !== this.origin,
                            searchStr: l,
                            search: ce(t ? .search, c),
                            hash: xe(s.hash.slice(1)).path,
                            state: le(t ? .state, a)
                        }
                    },
                    r = n(e),
                    {
                        __tempLocation: i,
                        __tempKey: a
                    } = r.state;
                if (i && (!a || a === this.tempLocationKey)) {
                    let e = n(i);
                    return e.state.key = r.state.key, e.state.__TSR_key = r.state.__TSR_key, delete e.state.__tempLocation, { ...e,
                        maskedLocation: r
                    }
                }
                return r
            }, this.resolvePathWithBase = (e, t) => rt({
                base: e,
                to: t.includes(`//`) ? Ze(t) : t,
                trailingSlash: this.options.trailingSlash,
                cache: this.resolvePathCache
            }), this.matchRoutes = (e, t, n) => typeof e == `string` ? this.matchRoutesInternal({
                pathname: e,
                search: t
            }, n) : this.matchRoutesInternal(e, t), this.getMatchedRoutes = e => fn({
                pathname: e,
                routesById: this.routesById,
                processedTree: this.processedTree
            }), this.cancelMatch = e => {
                let t = this.getMatch(e);
                t && (t.abortController.abort(), clearTimeout(t._nonReactive.pendingTimeout), t._nonReactive.pendingTimeout = void 0)
            }, this.cancelMatches = () => {
                this.stores.pendingIds.get().forEach(e => {
                    this.cancelMatch(e)
                }), this.stores.matchesId.get().forEach(e => {
                    if (this.stores.pendingMatchStores.has(e)) return;
                    let t = this.stores.matchStores.get(e) ? .get();
                    t && (t.status === `pending` || t.isFetching === `loader`) && this.cancelMatch(e)
                })
            }, this.buildLocation = e => {
                let t = (t = {}) => {
                        let n = t._fromLocation || this.pendingBuiltLocation || this.latestLocation,
                            r = this.matchRoutesLightweight(n);
                        t.from;
                        let i = t.unsafeRelative === `path` ? n.pathname : t.from ? ? r.fullPath,
                            a = t.to ? `${t.to}` : void 0,
                            o = r.search,
                            s = Object.assign(Object.create(null), r.params),
                            c = a ? .charCodeAt(0) === 47 ? `/` : this.resolvePathWithBase(i, `.`),
                            l = a ? this.resolvePathWithBase(c, a) : c,
                            u = t.params === !1 || t.params === null ? Object.create(null) : (t.params ? ? !0) === !0 ? s : Object.assign(s, re(t.params, s)),
                            d = this.routesByPath[$e(l)],
                            f;
                        if (d) f = this.getRouteBranch(d);
                        else if (l.includes(`$`)) f = [];
                        else {
                            let e = this.getMatchedRoutes(l);
                            f = e.matchedRoutes, this.options.notFoundRoute && (!e.foundRoute || e.foundRoute.path !== `/` && e.routeParams[`**`]) && (f = [...f, this.options.notFoundRoute])
                        }
                        if (f.length && oe(u))
                            for (let e of f) {
                                let t = e.options.params ? .stringify ? ? e.options.stringifyParams;
                                if (t) try {
                                    Object.assign(u, t(u))
                                } catch {}
                            }
                        let p = e.leaveParams ? l : xe(ot({
                                path: l,
                                params: u,
                                decoder: this.pathParamsDecoder,
                                server: this.isServer
                            }).interpolatedPath).path,
                            m = o;
                        if (e._includeValidateSearch && this.options.search ? .strict) {
                            let e = {};
                            f.forEach(t => {
                                if (t.options.validateSearch) try {
                                    Object.assign(e, dn(t.options.validateSearch, { ...e,
                                        ...m
                                    }))
                                } catch {}
                            }), m = e
                        }
                        m = pn({
                            search: m,
                            dest: t,
                            destRoutes: f,
                            _includeValidateSearch: e._includeValidateSearch
                        }), m = ce(o, m);
                        let h = this.options.stringifySearch(m),
                            g = t.hash === !0 ? n.hash : t.hash ? re(t.hash, n.hash) : void 0,
                            _ = g ? `#${g}` : ``,
                            v = t.state === !0 ? n.state : t.state ? re(t.state, n.state) : {};
                        v = le(n.state, v);
                        let y = `${p}${h}${_}`,
                            b, x, ee = !1;
                        if (this.rewrite) {
                            let e = new URL(y, this.origin),
                                t = Wt(this.rewrite, e);
                            b = e.href.replace(e.origin, ``), t.origin === this.origin ? x = t.pathname + t.search + t.hash : (x = t.href, ee = !0)
                        } else b = Se(y), x = b;
                        return {
                            publicHref: x,
                            href: b,
                            pathname: p,
                            search: m,
                            searchStr: h,
                            state: v,
                            hash: g ? ? ``,
                            external: ee,
                            unmaskOnReload: t.unmaskOnReload
                        }
                    },
                    n = (n = {}, r) => {
                        let i = t(n),
                            a = r ? t(r) : void 0;
                        if (!a) {
                            let n = Object.create(null);
                            if (this.options.routeMasks) {
                                let o = Ie(i.pathname, this.processedTree);
                                if (o) {
                                    Object.assign(n, o.rawParams);
                                    let {
                                        from: i,
                                        params: s,
                                        ...c
                                    } = o.route, l = s === !1 || s === null ? Object.create(null) : (s ? ? !0) === !0 ? n : Object.assign(n, re(s, n));
                                    r = {
                                        from: e.from,
                                        ...c,
                                        params: l
                                    }, a = t(r)
                                }
                            }
                        }
                        return a && (i.maskedLocation = a), i
                    };
                return e.mask ? n(e, {
                    from: e.from,
                    ...e.mask
                }) : n(e)
            }, this.commitLocation = async ({
                viewTransition: e,
                ignoreBlocker: t,
                ...n
            }) => {
                let r, i = () => {
                        let e = [`key`, `__TSR_key`, `__TSR_index`, `__hashScrollIntoViewOptions`];
                        e.forEach(e => {
                            n.state[e] = this.latestLocation.state[e]
                        });
                        let t = fe(n.state, this.latestLocation.state);
                        return e.forEach(e => {
                            delete n.state[e]
                        }), t
                    },
                    a = $e(this.latestLocation.href) === $e(n.href),
                    o = this.commitLocationPromise;
                if (this.commitLocationPromise = pe(() => {
                        o ? .resolve(), o = void 0
                    }), a && i()) this.load();
                else {
                    let {
                        maskedLocation: i,
                        hashScrollIntoView: a,
                        ...o
                    } = n;
                    i && (o = { ...i,
                        state: { ...i.state,
                            __tempKey: void 0,
                            __tempLocation: { ...o,
                                search: o.searchStr,
                                state: { ...o.state,
                                    __tempKey: void 0,
                                    __tempLocation: void 0,
                                    __TSR_key: void 0,
                                    key: void 0
                                }
                            }
                        }
                    }, (o.unmaskOnReload ? ? this.options.unmaskOnReload ? ? !1) && (o.state.__tempKey = this.tempLocationKey)), o.state.__hashScrollIntoViewOptions = a ? ? this.options.defaultHashScrollIntoView ? ? !0, this.shouldViewTransition = e, r = n.replace ? `REPLACE` : `PUSH`, this.history[r === `REPLACE` ? `replace` : `push`](o.publicHref, o.state, {
                        ignoreBlocker: t
                    })
                }
                return this._scroll.next = n.resetScroll ? ? !0, this.history.subscribers.size || this.load(r ? {
                    action: {
                        type: r
                    }
                } : void 0), this.commitLocationPromise
            }, this.buildAndCommitLocation = ({
                replace: e,
                resetScroll: t,
                hashScrollIntoView: n,
                viewTransition: r,
                ignoreBlocker: i,
                href: a,
                ...o
            } = {}) => {
                if (a) {
                    let t = this.history.location.state.__TSR_index,
                        n = tn(a, {
                            __TSR_index: e ? t : t + 1
                        }),
                        r = new URL(n.pathname, this.origin);
                    o.to = Ut(this.rewrite, r).pathname, o.search = this.options.parseSearch(n.search), o.hash = n.hash.slice(1)
                }
                let s = this.buildLocation({ ...o,
                    _includeValidateSearch: !0
                });
                this.pendingBuiltLocation = s;
                let c = this.commitLocation({ ...s,
                    viewTransition: r,
                    replace: e,
                    resetScroll: t,
                    hashScrollIntoView: n,
                    ignoreBlocker: i
                });
                return Promise.resolve().then(() => {
                    this.pendingBuiltLocation === s && (this.pendingBuiltLocation = void 0)
                }), c
            }, this.navigate = async ({
                to: e,
                reloadDocument: t,
                href: n,
                publicHref: r,
                ...i
            }) => {
                let a = !1;
                if (n) try {
                    new URL(`${n}`), a = !0
                } catch {}
                if (a && !t && (t = !0), t) {
                    if (e !== void 0 || !n) {
                        let t = this.buildLocation({
                            to: e,
                            ...i
                        });
                        n ? ? = t.publicHref, r ? ? = t.publicHref
                    }
                    let t = !a && r ? r : n;
                    if (_e(t, this.protocolAllowlist)) return Promise.resolve();
                    if (!i.ignoreBlocker) {
                        let e = this.history.getBlockers ? .() ? ? [];
                        for (let t of e)
                            if (t ? .blockerFn && await t.blockerFn({
                                    currentLocation: this.latestLocation,
                                    nextLocation: this.latestLocation,
                                    action: `PUSH`
                                })) return Promise.resolve()
                    }
                    return i.replace ? window.location.replace(t) : window.location.href = t, Promise.resolve()
                }
                return this.buildAndCommitLocation({ ...i,
                    href: n,
                    to: e,
                    _isNavigate: !0
                })
            }, this.beforeLoad = () => {
                this.cancelMatches(), this.updateLatestLocation();
                let e = this.matchRoutes(this.latestLocation),
                    t = this.stores.cachedMatches.get().filter(t => !e.some(e => e.id === t.id));
                this.batch(() => {
                    this.stores.status.set(`pending`), this.stores.statusCode.set(200), this.stores.isLoading.set(!0), this.stores.location.set(this.latestLocation), this.stores.setPending(e), this.stores.setCached(t)
                })
            }, this.load = async e => {
                let t = e ? .action ? .type,
                    n, r, i, a = this.stores.resolvedLocation.get() ? ? this.stores.location.get();
                for (i = new Promise(o => {
                        this.startTransition(async () => {
                            try {
                                this.beforeLoad(), t ? on.set(this.latestLocation, t) : on.delete(this.latestLocation);
                                let n = this.latestLocation,
                                    r = an(n, this.stores.resolvedLocation.get());
                                this.stores.redirect.get() || this.emit({
                                    type: `onBeforeNavigate`,
                                    ...r
                                }), this.emit({
                                    type: `onBeforeLoad`,
                                    ...r
                                }), await It({
                                    router: this,
                                    sync: e ? .sync,
                                    forceStaleReload: a.href === n.href,
                                    matches: this.stores.pendingMatches.get(),
                                    location: n,
                                    updateMatch: this.updateMatch,
                                    onReady: async () => {
                                        this.startTransition(() => {
                                            this.startViewTransition(async () => {
                                                let e = null,
                                                    t = null,
                                                    n = null,
                                                    r = null;
                                                this.batch(() => {
                                                    let i = this.stores.pendingMatches.get(),
                                                        a = i.length,
                                                        o = this.stores.matches.get();
                                                    e = a ? o.filter(e => !this.stores.pendingMatchStores.has(e.id)) : null;
                                                    let s = new Set;
                                                    for (let e of this.stores.pendingMatchStores.values()) e.routeId && s.add(e.routeId);
                                                    let c = new Set;
                                                    for (let e of this.stores.matchStores.values()) e.routeId && c.add(e.routeId);
                                                    t = a ? o.filter(e => !s.has(e.routeId)) : null, n = a ? i.filter(e => !c.has(e.routeId)) : null, r = a ? i.filter(e => c.has(e.routeId)) : o, this.stores.isLoading.set(!1), this.stores.loadedAt.set(Date.now()), a && (this.stores.setMatches(i), this.stores.setPending([]), this.stores.setCached([...this.stores.cachedMatches.get(), ...e.filter(e => e.status !== `error` && e.status !== `notFound` && e.status !== `redirected`)]), this.clearExpiredCache())
                                                });
                                                for (let [e, i] of [
                                                        [t, `onLeave`],
                                                        [n, `onEnter`],
                                                        [r, `onStay`]
                                                    ])
                                                    if (e)
                                                        for (let t of e) this.looseRoutesById[t.routeId].options[i] ? .(t)
                                            })
                                        })
                                    }
                                })
                            } catch (e) {
                                k(e) ? (n = e, this.navigate({ ...n.options,
                                    replace: !0,
                                    ignoreBlocker: !0
                                })) : ct(e) && (r = e);
                                let t = n ? n.status : r ? 404 : this.stores.matches.get().some(e => e.status === `error`) ? 500 : 200;
                                this.batch(() => {
                                    this.stores.statusCode.set(t), this.stores.redirect.set(n)
                                })
                            }
                            this.latestLoadPromise === i && (this.commitLocationPromise ? .resolve(), this.latestLoadPromise = void 0, this.commitLocationPromise = void 0), o()
                        })
                    }), this.latestLoadPromise = i, await i; this.latestLoadPromise && i !== this.latestLoadPromise;) await this.latestLoadPromise;
                let o;
                this.hasNotFoundMatch() ? o = 404 : this.stores.matches.get().some(e => e.status === `error`) && (o = 500), o !== void 0 && this.stores.statusCode.set(o)
            }, this.startViewTransition = e => {
                let t = this.shouldViewTransition ? ? this.options.defaultViewTransition;
                if (this.shouldViewTransition = void 0, t && typeof document < `u` && `startViewTransition` in document && typeof document.startViewTransition == `function`) {
                    let n;
                    if (typeof t == `object` && this.isViewTransitionTypesSupported) {
                        let r = this.latestLocation,
                            i = this.stores.resolvedLocation.get(),
                            a = typeof t.types == `function` ? t.types(an(r, i)) : t.types;
                        if (a === !1) {
                            e();
                            return
                        }
                        n = {
                            update: e,
                            types: a
                        }
                    } else n = e;
                    document.startViewTransition(n)
                } else e()
            }, this.updateMatch = (e, t) => {
                this.startTransition(() => {
                    let n = this.stores.pendingMatchStores.get(e);
                    if (n) {
                        n.set(t);
                        return
                    }
                    let r = this.stores.matchStores.get(e);
                    if (r) {
                        r.set(t);
                        return
                    }
                    let i = this.stores.cachedMatchStores.get(e);
                    if (i) {
                        let n = t(i.get());
                        n.status === `redirected` ? this.stores.cachedMatchStores.delete(e) && this.stores.cachedIds.set(t => t.filter(t => t !== e)) : i.set(n)
                    }
                })
            }, this.getMatch = e => this.stores.cachedMatchStores.get(e) ? .get() ? ? this.stores.pendingMatchStores.get(e) ? .get() ? ? this.stores.matchStores.get(e) ? .get(), this.invalidate = e => {
                let t = t => e ? .filter ? .(t) ? ? !0 ? { ...t,
                    invalid: !0,
                    ...e ? .forcePending || t.status === `error` || t.status === `notFound` ? {
                        status: `pending`,
                        error: void 0
                    } : void 0
                } : t;
                return this.batch(() => {
                    this.stores.setMatches(this.stores.matches.get().map(t)), this.stores.setCached(this.stores.cachedMatches.get().map(t)), this.stores.setPending(this.stores.pendingMatches.get().map(t))
                }), this.shouldViewTransition = !1, this.load({
                    sync: e ? .sync
                })
            }, this.getParsedLocationHref = e => e.publicHref || `/`, this.resolveRedirect = e => {
                let t = e.headers.get(`Location`);
                if (!e.options.href || e.options._builtLocation) {
                    let t = e.options._builtLocation ? ? this.buildLocation(e.options),
                        n = this.getParsedLocationHref(t);
                    e.options.href = n, e.headers.set(`Location`, n)
                } else if (t) try {
                    let n = new URL(t);
                    if (this.origin && n.origin === this.origin) {
                        let t = n.pathname + n.search + n.hash;
                        e.options.href = t, e.headers.set(`Location`, t)
                    }
                } catch {}
                if (e.options.href && !e.options._builtLocation && _e(e.options.href, this.protocolAllowlist)) throw Error(`Redirect blocked: unsafe protocol`);
                return e.headers.get(`Location`) || e.headers.set(`Location`, e.options.href), e
            }, this.clearCache = e => {
                let t = e ? .filter;
                t === void 0 ? this.stores.setCached([]) : this.stores.setCached(this.stores.cachedMatches.get().filter(e => !t(e)))
            }, this.clearExpiredCache = () => {
                let e = Date.now();
                this.clearCache({
                    filter: t => {
                        let n = this.looseRoutesById[t.routeId];
                        if (!n.options.loader) return !0;
                        let r = (t.preload ? n.options.preloadGcTime ? ? this.options.defaultPreloadGcTime : n.options.gcTime ? ? this.options.defaultGcTime) ? ? 300 * 1e3;
                        return t.status === `error` ? !0 : e - t.updatedAt >= r
                    }
                })
            }, this.loadRouteChunk = Rt, this.preloadRoute = async e => {
                let t = e._builtLocation ? ? this.buildLocation(e),
                    n = this.matchRoutes(t, {
                        throwOnError: !0,
                        preload: !0,
                        dest: e
                    }),
                    r = new Set([...this.stores.matchesId.get(), ...this.stores.pendingIds.get()]),
                    i = new Set([...r, ...this.stores.cachedIds.get()]),
                    a = n.filter(e => !i.has(e.id));
                if (a.length) {
                    let e = this.stores.cachedMatches.get();
                    this.stores.setCached([...e, ...a])
                }
                try {
                    return n = await It({
                        router: this,
                        matches: n,
                        location: t,
                        preload: !0,
                        updateMatch: (e, t) => {
                            r.has(e) ? n = n.map(n => n.id === e ? t(n) : n) : this.updateMatch(e, t)
                        }
                    }), n
                } catch (e) {
                    if (k(e)) return e.options.reloadDocument ? void 0 : await this.preloadRoute({ ...e.options,
                        _fromLocation: t
                    });
                    ct(e) || console.error(e);
                    return
                }
            }, this.matchRoute = (e, t) => {
                let n = { ...e,
                        to: e.to ? this.resolvePathWithBase(e.from || ``, e.to) : void 0,
                        params: e.params || {},
                        leaveParams: !0
                    },
                    r = this.buildLocation(n);
                if (t ? .pending && this.stores.status.get() !== `pending`) return !1;
                let i = (t ? .pending === void 0 ? !this.stores.isLoading.get() : t.pending) ? this.latestLocation : this.stores.resolvedLocation.get() || this.stores.location.get(),
                    a = Le(r.pathname, t ? .caseSensitive ? ? !1, t ? .fuzzy ? ? !1, i.pathname, this.processedTree);
                return !a || e.params && !fe(a.rawParams, e.params, {
                    partial: !0
                }) ? !1 : t ? .includeSearch ? ? !0 ? fe(i.search, r.search, {
                    partial: !0
                }) ? a.rawParams : !1 : a.rawParams
            }, this.hasNotFoundMatch = () => this.stores.matches.get().some(e => e.status === `notFound` || e.globalNotFound), this.getStoreConfig = t, this.update({
                defaultPreloadDelay: 50,
                defaultPendingMs: 1e3,
                defaultPendingMinMs: 500,
                context: void 0,
                ...e,
                caseSensitive: e.caseSensitive ? ? !1,
                notFoundMode: e.notFoundMode ? ? `fuzzy`,
                stringifySearch: e.stringifySearch ? ? pt,
                parseSearch: e.parseSearch ? ? ft,
                protocolAllowlist: e.protocolAllowlist ? ? ge
            }), typeof document < `u` && (self.__TSR_ROUTER__ = this)
        }
        isShell() {
            return !!this.options.isShell
        }
        isPrerendering() {
            return !!this.options.isPrerendering
        }
        get state() {
            return this.stores.__store.get()
        }
        setRoutes({
            routesById: e,
            routesByPath: t,
            processedTree: n
        }) {
            this.routesById = e, this.routesByPath = t, this.processedTree = n;
            let r = this.options.notFoundRoute;
            r && (r.init({
                originalIndex: 99999999999
            }), this.routesById[r.id] = r)
        }
        getRouteBranch(e) {
            let t = this.routeBranchCache.get(e);
            return t || (t = Ue(e), this.routeBranchCache.set(e, t)), t
        }
        get looseRoutesById() {
            return this.routesById
        }
        getParentContext(e) {
            return e ? .id ? e.context ? ? this.options.context ? ? void 0 : this.options.context ? ? void 0
        }
        matchRoutesInternal(e, t) {
            let n = this.getMatchedRoutes(e.pathname),
                {
                    foundRoute: r,
                    routeParams: i
                } = n,
                {
                    matchedRoutes: a
                } = n,
                o = !1;
            (r ? r.path !== `/` && i[`**`] : $e(e.pathname)) && (this.options.notFoundRoute ? a = [...a, this.options.notFoundRoute] : o = !0);
            let s = o ? hn(this.options.notFoundMode, a) : void 0,
                c = Array(a.length),
                l = new Map;
            for (let e of this.stores.matchStores.values()) e.routeId && l.set(e.routeId, e.get());
            for (let n = 0; n < a.length; n++) {
                let r = a[n],
                    o = c[n - 1],
                    u, d, f; {
                    let n = o ? .search ? ? e.search,
                        i = o ? ._strictSearch ? ? void 0;
                    try {
                        let e = dn(r.options.validateSearch, { ...n
                        }) ? ? void 0;
                        u = { ...n,
                            ...e
                        }, d = { ...i,
                            ...e
                        }, f = void 0
                    } catch (e) {
                        let r = e;
                        if (e instanceof cn || (r = new cn(e.message, {
                                cause: e
                            })), t ? .throwOnError) throw r;
                        u = n, d = {}, f = r
                    }
                }
                let p = r.options.loaderDeps ? .({
                        search: u
                    }) ? ? ``,
                    m = p ? JSON.stringify(p) : ``,
                    {
                        interpolatedPath: h,
                        usedParams: g
                    } = ot({
                        path: r.fullPath,
                        params: i,
                        decoder: this.pathParamsDecoder,
                        server: this.isServer
                    }),
                    _ = r.id + h + m,
                    v = this.getMatch(_),
                    y = l.get(r.id),
                    b = v ? ._strictParams ? ? g,
                    x;
                if (!v) try {
                    gn(r, b)
                } catch (e) {
                    if (x = ct(e) || k(e) ? e : new ln(e.message, {
                            cause: e
                        }), t ? .throwOnError) throw x
                }
                Object.assign(i, b);
                let ee = y ? `stay` : `enter`,
                    S;
                if (v) S = { ...v,
                    cause: ee,
                    params: y ? .params ? ? i,
                    _strictParams: b,
                    search: ce(y ? y.search : v.search, u),
                    _strictSearch: d
                };
                else {
                    let e = r.options.loader || r.options.beforeLoad || r.lazyFn || zt(r) ? `pending` : `success`;
                    S = {
                        id: _,
                        ssr: r.options.ssr,
                        index: n,
                        routeId: r.id,
                        params: y ? .params ? ? i,
                        _strictParams: b,
                        pathname: h,
                        updatedAt: Date.now(),
                        search: y ? ce(y.search, u) : u,
                        _strictSearch: d,
                        searchError: void 0,
                        status: e,
                        isFetching: !1,
                        error: void 0,
                        paramsError: x,
                        __routeContext: void 0,
                        _nonReactive: {
                            loadPromise: pe()
                        },
                        __beforeLoadContext: void 0,
                        context: {},
                        abortController: new AbortController,
                        fetchCount: 0,
                        cause: ee,
                        loaderDeps: y ? le(y.loaderDeps, p) : p,
                        invalid: !1,
                        preload: !1,
                        links: void 0,
                        scripts: void 0,
                        headScripts: void 0,
                        meta: void 0,
                        staticData: r.options.staticData || {},
                        fullPath: r.fullPath
                    }
                }
                t ? .preload || (S.globalNotFound = s === r.id), S.searchError = f;
                let C = this.getParentContext(o);
                S.context = { ...C,
                    ...S.__routeContext,
                    ...S.__beforeLoadContext
                }, c[n] = S
            }
            for (let t = 0; t < c.length; t++) {
                let n = c[t],
                    r = this.looseRoutesById[n.routeId],
                    a = this.getMatch(n.id),
                    o = l.get(n.routeId);
                if (n.params = o ? ce(o.params, i) : i, !a) {
                    let i = c[t - 1],
                        a = this.getParentContext(i);
                    if (r.options.context) {
                        let t = {
                            deps: n.loaderDeps,
                            params: n.params,
                            context: a ? ? {},
                            location: e,
                            navigate: t => this.navigate({ ...t,
                                _fromLocation: e
                            }),
                            buildLocation: this.buildLocation,
                            cause: n.cause,
                            abortController: n.abortController,
                            preload: !!n.preload,
                            matches: c,
                            routeId: r.id
                        };
                        n.__routeContext = r.options.context(t) ? ? void 0
                    }
                    n.context = { ...a,
                        ...n.__routeContext,
                        ...n.__beforeLoadContext
                    }
                }
            }
            return c
        }
        matchRoutesLightweight(e) {
            let {
                matchedRoutes: t,
                routeParams: n
            } = this.getMatchedRoutes(e.pathname), r = te(t), i = { ...e.search
            };
            for (let e of t) try {
                Object.assign(i, dn(e.options.validateSearch, i))
            } catch {}
            let a = te(this.stores.matchesId.get()),
                o = a && this.stores.matchStores.get(a) ? .get(),
                s = o && o.routeId === r.id && o.pathname === e.pathname,
                c;
            if (s) c = o.params;
            else {
                let e = Object.assign(Object.create(null), n);
                for (let n of t) try {
                    gn(n, e)
                } catch {}
                c = e
            }
            return {
                matchedRoutes: t,
                fullPath: r.fullPath,
                search: i,
                params: c
            }
        }
    },
    cn = class extends Error {},
    ln = class extends Error {};

function un(e) {
    return {
        loadedAt: 0,
        isLoading: !1,
        isTransitioning: !1,
        status: `idle`,
        resolvedLocation: void 0,
        location: e,
        matches: [],
        statusCode: 200
    }
}

function dn(e, t) {
    if (e == null) return {};
    if (`~standard` in e) {
        let n = e[`~standard`].validate(t);
        if (n instanceof Promise) throw new cn(`Async validation not supported`);
        if (n.issues) throw new cn(JSON.stringify(n.issues, void 0, 2), {
            cause: n
        });
        return n.value
    }
    return `parse` in e ? e.parse(t) : typeof e == `function` ? e(t) : {}
}

function fn({
    pathname: e,
    routesById: t,
    processedTree: n
}) {
    let r = Object.create(null),
        i = $e(e),
        a, o = Re(i, n, !0);
    return o && (a = o.route, Object.assign(r, o.rawParams)), {
        matchedRoutes: o ? .branch || [t.__root__],
        routeParams: r,
        foundRoute: a
    }
}

function pn({
    search: e,
    dest: t,
    destRoutes: n,
    _includeValidateSearch: r
}) {
    return mn(n)(e, t, r ? ? !1)
}

function mn(e) {
    let t, n, r = [];
    for (let t of e) {
        let e = t.options;
        `search` in e ? e.search ? .middlewares && r.push(...e.search.middlewares) : (e.preSearchFilters || e.postSearchFilters) && r.push(({
            search: t,
            next: n
        }) => {
            let r = n(e.preSearchFilters ? e.preSearchFilters.reduce((e, t) => t(e), t) : t);
            return e.postSearchFilters ? e.postSearchFilters.reduce((e, t) => t(e), r) : r
        });
        let i = e.validateSearch;
        i && r.push(({
            search: e,
            next: t,
            meta: r
        }) => {
            let a = t(e);
            if (n) try {
                let e = dn(i, a);
                if (r && e)
                    for (let t in e) t in a || (r.defaulted || = new Map).set(t, e[t]);
                return { ...a,
                    ...e
                }
            } catch {}
            return a
        })
    }
    let i = (e, n, a) => {
        if (e >= r.length) {
            if (!t.search) return {};
            if (t.search === !0) return n;
            let e = re(t.search, n);
            return a && (a.explicit = e), e
        }
        return r[e]({
            search: n,
            next: (t, n) => {
                if (n) {
                    let n = a || {};
                    return {
                        search: i(e + 1, t, n),
                        meta: n
                    }
                }
                return i(e + 1, t, a)
            },
            meta: a
        })
    };
    return function(e, r, a) {
        return t = r, n = a, i(0, e)
    }
}

function hn(e, t) {
    if (e !== `root`)
        for (let e = t.length - 1; e >= 0; e--) {
            let n = t[e];
            if (n.children) return n.id
        }
    return gt
}

function gn(e, t) {
    let n = e.options.params ? .parse ? ? e.options.parseParams;
    if (n) {
        let e = n(t);
        if (e === !1) throw Error(`Route params.parse returned false for a matched route`);
        Object.assign(t, e)
    }
}

function _n() {
    try {
        return sessionStorage
    } catch {
        return
    }
}
var vn = `tsr-scroll-restoration-v1_3`,
    yn = _n();

function bn() {
    try {
        return JSON.parse(yn ? .getItem(`tsr-scroll-restoration-v1_3`) || `{}`)
    } catch {
        return {}
    }
}

function xn() {
    try {
        yn ? .setItem(vn, JSON.stringify(Sn))
    } catch {}
}
var Sn = bn(),
    Cn = `data-scroll-restoration-id`,
    wn = e => e.state.__TSR_key || e.href;

function Tn(e) {
    let t = e.getAttribute(Cn);
    if (t) return `[${Cn}="${t}"]`;
    let n = ``,
        r = e,
        i;
    for (; i = r.parentNode;) {
        let e = 1,
            t = r;
        for (; t = t.previousElementSibling;) e++;
        let a = `${r.localName}:nth-child(${e})`;
        n = n ? `${a} > ${n}` : a, r = i
    }
    return n
}
var En = !1,
    Dn = `window`;

function On(e) {
    try {
        return typeof e == `function` ? e() : document.querySelector(e)
    } catch {}
}

function kn(e) {
    let t = [];
    for (let n of e) {
        if (n === Dn) continue;
        let e = On(n);
        e && t.push(e)
    }
    return t
}

function An(e, t) {
    let n = t ? ? e.options.scrollRestoration,
        r = e._scroll;
    n && (r.restoring = !0);
    let i = e.options.getScrollRestorationKey || wn,
        a = new Map,
        o = (e, t, n) => {
            let r = a.get(e) || {};
            r.scrollX = t, r.scrollY = n, a.set(e, r)
        },
        s = e => {
            if (!(En || !r.restoring))
                if (e.target === document) o(Dn, scrollX, scrollY);
                else {
                    let t = e.target;
                    o(t, t.scrollLeft, t.scrollTop)
                }
        },
        c = e => {
            if (!r.restoring) return;
            let t = Sn[e] || = {};
            for (let [e, n] of a) e === Dn ? t[Dn] = n : e.isConnected && (t[Tn(e)] = n)
        };
    n && !r.restoration && (r.restoration = !0, En = !1, history.scrollRestoration = `manual`, document.addEventListener(`scroll`, s, !0), e.subscribe(`onBeforeLoad`, e => {
        e.fromLocation && c(i(e.fromLocation)), a.clear()
    }), addEventListener(`pagehide`, () => {
        c(i(e.stores.resolvedLocation.get() ? ? e.stores.location.get())), xn()
    })), !r.reset && (r.reset = !0, e.subscribe(`onRendered`, t => {
        let n = e.options.scrollRestorationBehavior,
            o = e.options.scrollToTopSelectors,
            s = r.next,
            c;
        if (a.clear(), s || (r.next = !0), typeof e.options.scrollRestoration == `function` && !e.options.scrollRestoration({
                location: e.latestLocation
            })) return;
        let l = i(t.toLocation),
            u = t.fromLocation && i(t.fromLocation);
        if (r.restoring && u && u !== l) {
            let e = Sn[u];
            if (e) {
                let t = Sn[l];
                for (let n in e) {
                    if (n === Dn) {
                        if (s) continue
                    } else {
                        let e = On(n);
                        if (!e || s && o && (c ? ? = kn(o), c.includes(e))) continue
                    }
                    t || = Sn[l] = {}, t[n] ? ? = e[n]
                }
            }
        }
        En = !0;
        try {
            let e = t.toLocation.hash,
                i = t.toLocation.state.__hashScrollIntoViewOptions ? ? !0,
                a = !1;
            if (s) {
                let s = on.get(t.toLocation),
                    u = e && i && (s === `PUSH` || s === `REPLACE`),
                    d = r.restoring ? Sn[l] : void 0;
                if (d)
                    for (let e in d) {
                        let {
                            scrollX: t,
                            scrollY: r
                        } = d[e];
                        if (e === Dn) {
                            if (u) continue;
                            scrollTo({
                                top: r,
                                left: t,
                                behavior: n
                            }), a = !0
                        } else {
                            let n = On(e);
                            n && (n.scrollLeft = t, n.scrollTop = r)
                        }
                    }
                if (!a && !e) {
                    let e = {
                        top: 0,
                        left: 0,
                        behavior: n
                    };
                    if (scrollTo(e), o) {
                        c ? ? = kn(o);
                        for (let t of c) t.scrollTo(e)
                    }
                }
            }!a && e && i && document.getElementById(e) ? .scrollIntoView(i)
        } finally {
            En = !1
        }
    }))
}
var jn = Symbol.for(`TSR_DEFERRED_PROMISE`);

function Mn(e, t) {
    let n = e;
    return n[jn] ? n : (n[jn] = {
        status: `pending`
    }, n.then(e => {
        n[jn].status = `success`, n[jn].data = e
    }).catch(e => {
        n[jn].status = `error`, n[jn].error = {
            data: (t ? .serializeError ? ? rn)(e),
            __isServerError: !0
        }
    }), n)
}
var Nn = `Error preloading route! ☝️`;

function Pn(e, t) {
    if (e) return typeof e == `string` ? e : e[t]
}

function Fn(e) {
    return e ? .scriptFormat ? ? `module`
}

function In(e, t, n) {
    let r = Ln(t),
        i = Pn(n, `script`) ? ? r.crossOrigin;
    return { ...Fn(e) === `iife` ? {
            rel: `preload`,
            as: `script`
        } : {
            rel: `modulepreload`
        },
        href: r.href,
        ...i ? {
            crossOrigin: i
        } : {}
    }
}

function Ln(e) {
    return typeof e == `string` ? {
        href: e,
        crossOrigin: void 0
    } : e
}

function Rn(e, t) {
    if (t.length === 0) return;
    if (t.length === 1) {
        e.push(t[0]);
        return
    }
    let n = new Set;
    for (let r of t) {
        let t = JSON.stringify(r);
        n.has(t) || (n.add(t), e.push(r))
    }
}

function zn(e) {
    return typeof e == `string` ? {
        href: e,
        crossOrigin: void 0
    } : e
}
var Bn = class {
        get to() {
            return this._to
        }
        get id() {
            return this._id
        }
        get path() {
            return this._path
        }
        get fullPath() {
            return this._fullPath
        }
        constructor(e) {
            if (this.init = e => {
                    this.originalIndex = e.originalIndex;
                    let t = this.options,
                        n = !t ? .path && !t ? .id;
                    this.parentRoute = this.options.getParentRoute ? .(), n ? this._path = gt : this.parentRoute || we();
                    let r = n ? gt : t ? .path;
                    r && r !== `/` && (r = Qe(r));
                    let i = t ? .id || r,
                        a = n ? gt : Xe([this.parentRoute.id === `__root__` ? `` : this.parentRoute.id, i]);
                    r === `__root__` && (r = `/`), a !== `__root__` && (a = Xe([`/`, a]));
                    let o = a === `__root__` ? `/` : Xe([this.parentRoute.fullPath, r]);
                    this._path = r, this._id = a, this._fullPath = o, this._to = $e(o)
                }, this.addChildren = e => this._addFileChildren(e), this._addFileChildren = e => (Array.isArray(e) && (this.children = e), typeof e == `object` && e && (this.children = Object.values(e)), this), this._addFileTypes = () => this, this.updateLoader = e => (Object.assign(this.options, e), this), this.update = e => (Object.assign(this.options, e), this), this.lazy = e => (this.lazyFn = e, this), this.redirect = e => _t({
                    from: this.fullPath,
                    ...e
                }), this.options = e || {}, this.isRoot = !e ? .getParentRoute, e ? .id && e ? .path) throw Error(`Route cannot have both an 'id' and a 'path' option.`)
        }
    },
    Vn = class extends Bn {
        constructor(e) {
            super(e)
        }
    },
    Hn = (e => (e[e.AggregateError = 1] = `AggregateError`, e[e.ArrowFunction = 2] = `ArrowFunction`, e[e.ErrorPrototypeStack = 4] = `ErrorPrototypeStack`, e[e.ObjectAssign = 8] = `ObjectAssign`, e[e.BigIntTypedArray = 16] = `BigIntTypedArray`, e[e.RegExp = 32] = `RegExp`, e))(Hn || {}),
    Un = Symbol.asyncIterator,
    Wn = Symbol.hasInstance,
    Gn = Symbol.isConcatSpreadable,
    Kn = Symbol.iterator,
    qn = Symbol.match,
    Jn = Symbol.matchAll,
    Yn = Symbol.replace,
    Xn = Symbol.search,
    Zn = Symbol.species,
    Qn = Symbol.split,
    $n = Symbol.toPrimitive,
    er = Symbol.toStringTag,
    tr = Symbol.unscopables,
    nr = {
        [Un]: 0,
        [Wn]: 1,
        [Gn]: 2,
        [Kn]: 3,
        [qn]: 4,
        [Jn]: 5,
        [Yn]: 6,
        [Xn]: 7,
        [Zn]: 8,
        [Qn]: 9,
        [$n]: 10,
        [er]: 11,
        [tr]: 12
    },
    rr = {
        0: Un,
        1: Wn,
        2: Gn,
        3: Kn,
        4: qn,
        5: Jn,
        6: Yn,
        7: Xn,
        8: Zn,
        9: Qn,
        10: $n,
        11: er,
        12: tr
    },
    A = void 0,
    ir = {
        2: !0,
        3: !1,
        1: A,
        0: null,
        4: -0,
        5: 1 / 0,
        6: -1 / 0,
        7: NaN
    },
    ar = {
        0: `Error`,
        1: `EvalError`,
        2: `RangeError`,
        3: `ReferenceError`,
        4: `SyntaxError`,
        5: `TypeError`,
        6: `URIError`
    },
    or = {
        0: Error,
        1: EvalError,
        2: RangeError,
        3: ReferenceError,
        4: SyntaxError,
        5: TypeError,
        6: URIError
    };

function j(e, t, n, r, i, a, o, s, c, l, u, d) {
    return {
        t: e,
        i: t,
        s: n,
        c: r,
        m: i,
        p: a,
        e: o,
        a: s,
        f: c,
        b: l,
        o: u,
        l: d
    }
}

function sr(e) {
    return j(2, A, e, A, A, A, A, A, A, A, A, A)
}
var cr = sr(2),
    lr = sr(3),
    ur = sr(1),
    dr = sr(0),
    fr = sr(4),
    pr = sr(5),
    mr = sr(6),
    hr = sr(7);

function gr(e) {
    switch (e) {
        case `"`:
            return `\\"`;
        case `\\`:
            return `\\\\`;
        case `
`:
            return `\\n`;
        case `\r`:
            return `\\r`;
        case `\b`:
            return `\\b`;
        case `	`:
            return `\\t`;
        case `\f`:
            return `\\f`;
        case `<`:
            return `\\x3C`;
        case `\u2028`:
            return `\\u2028`;
        case `\u2029`:
            return `\\u2029`;
        default:
            return A
    }
}

function _r(e) {
    let t = ``,
        n = 0,
        r;
    for (let i = 0, a = e.length; i < a; i++) r = gr(e[i]), r && (t += e.slice(n, i) + r, n = i + 1);
    return n === 0 ? t = e : t += e.slice(n), t
}

function vr(e) {
    switch (e) {
        case `\\\\`:
            return `\\`;
        case `\\"`:
            return `"`;
        case `\\n`:
            return `
`;
        case `\\r`:
            return `\r`;
        case `\\b`:
            return `\b`;
        case `\\t`:
            return `	`;
        case `\\f`:
            return `\f`;
        case `\\x3C`:
            return `<`;
        case `\\u2028`:
            return `\u2028`;
        case `\\u2029`:
            return `\u2029`;
        default:
            return e
    }
}

function yr(e) {
    return e.replace(/(\\\\|\\"|\\n|\\r|\\b|\\t|\\f|\\u2028|\\u2029|\\x3C)/g, vr)
}
var br = `__SEROVAL_REFS__`,
    xr = new Map,
    Sr = new Map;

function Cr(e) {
    return xr.has(e)
}

function wr(e) {
    return Sr.has(e)
}

function Tr(e) {
    if (Cr(e)) return xr.get(e);
    throw new pi(e)
}

function Er(e) {
    if (wr(e)) return Sr.get(e);
    throw new mi(e)
}
typeof globalThis < `u` ? Object.defineProperty(globalThis, br, {
    value: Sr,
    configurable: !0,
    writable: !1,
    enumerable: !1
}) : typeof window < `u` ? Object.defineProperty(window, br, {
    value: Sr,
    configurable: !0,
    writable: !1,
    enumerable: !1
}) : typeof self < `u` ? Object.defineProperty(self, br, {
    value: Sr,
    configurable: !0,
    writable: !1,
    enumerable: !1
}) : typeof global < `u` && Object.defineProperty(global, br, {
    value: Sr,
    configurable: !0,
    writable: !1,
    enumerable: !1
});

function Dr(e) {
    return e instanceof EvalError ? 1 : e instanceof RangeError ? 2 : e instanceof ReferenceError ? 3 : e instanceof SyntaxError ? 4 : e instanceof TypeError ? 5 : e instanceof URIError ? 6 : 0
}

function Or(e) {
    let t = ar[Dr(e)];
    return e.name === t ? e.constructor.name === t ? {} : {
        name: e.constructor.name
    } : {
        name: e.name
    }
}

function kr(e, t) {
    let n = Or(e),
        r = Object.getOwnPropertyNames(e);
    for (let i = 0, a = r.length, o; i < a; i++) o = r[i], o !== `name` && o !== `message` && (o === `stack` ? t & 4 && (n || = {}, n[o] = e[o]) : (n || = {}, n[o] = e[o]));
    return n
}

function Ar(e) {
    return Object.isFrozen(e) ? 3 : Object.isSealed(e) ? 2 : +!Object.isExtensible(e)
}

function jr(e) {
    switch (e) {
        case 1 / 0:
            return pr;
        case -1 / 0:
            return mr
    }
    return e === e ? Object.is(e, -0) ? fr : j(0, A, e, A, A, A, A, A, A, A, A, A) : hr
}

function Mr(e) {
    return j(1, A, _r(e), A, A, A, A, A, A, A, A, A)
}

function Nr(e) {
    return j(3, A, `` + e, A, A, A, A, A, A, A, A, A)
}

function Pr(e) {
    return j(4, e, A, A, A, A, A, A, A, A, A, A)
}

function Fr(e, t) {
    let n = t.valueOf();
    return j(5, e, n === n ? t.toISOString() : ``, A, A, A, A, A, A, A, A, A)
}

function Ir(e, t) {
    return j(6, e, A, _r(t.source), t.flags, A, A, A, A, A, A, A)
}

function Lr(e, t) {
    return j(17, e, nr[t], A, A, A, A, A, A, A, A, A)
}

function Rr(e, t) {
    return j(18, e, _r(Tr(t)), A, A, A, A, A, A, A, A, A)
}

function zr(e, t, n) {
    return j(25, e, n, _r(t), A, A, A, A, A, A, A, A)
}

function Br(e, t, n) {
    return j(9, e, A, A, A, A, A, n, A, A, Ar(t), A)
}

function Vr(e, t) {
    return j(21, e, A, A, A, A, A, A, t, A, A, A)
}

function Hr(e, t, n) {
    return j(15, e, A, t.constructor.name, A, A, A, A, n, t.byteOffset, A, t.length)
}

function Ur(e, t, n) {
    return j(16, e, A, t.constructor.name, A, A, A, A, n, t.byteOffset, A, t.byteLength)
}

function Wr(e, t, n) {
    return j(20, e, A, A, A, A, A, A, n, t.byteOffset, A, t.byteLength)
}

function Gr(e, t, n) {
    return j(13, e, Dr(t), A, _r(t.message), n, A, A, A, A, A, A)
}

function Kr(e, t, n) {
    return j(14, e, Dr(t), A, _r(t.message), n, A, A, A, A, A, A)
}

function qr(e, t) {
    return j(7, e, A, A, A, A, A, t, A, A, A, A)
}

function Jr(e, t) {
    return j(28, A, A, A, A, A, A, [e, t], A, A, A, A)
}

function Yr(e, t) {
    return j(30, A, A, A, A, A, A, [e, t], A, A, A, A)
}

function Xr(e, t, n) {
    return j(31, e, A, A, A, A, A, n, t, A, A, A)
}

function Zr(e, t) {
    return j(32, e, A, A, A, A, A, A, t, A, A, A)
}

function Qr(e, t) {
    return j(33, e, A, A, A, A, A, A, t, A, A, A)
}

function $r(e, t) {
    return j(34, e, A, A, A, A, A, A, t, A, A, A)
}

function ei(e, t, n, r) {
    return j(35, e, n, A, A, A, A, t, A, A, A, r)
}
var {
    toString: ti
} = Object.prototype, ni = {
    parsing: 1,
    serialization: 2,
    deserialization: 3
};

function ri(e) {
    return `Seroval Error (step: ${ni[e]})`
}
var ii = (e, t) => ri(e),
    ai = class extends Error {
        constructor(e, t) {
            super(ii(e, t)), this.cause = t
        }
    },
    oi = class extends ai {
        constructor(e) {
            super(`parsing`, e)
        }
    },
    si = class extends ai {
        constructor(e) {
            super(`deserialization`, e)
        }
    };

function ci(e) {
    return `Seroval Error (specific: ${e})`
}
var li = class extends Error {
        constructor(e) {
            super(ci(1)), this.value = e
        }
    },
    ui = class extends Error {
        constructor(e) {
            super(ci(2))
        }
    },
    di = class extends Error {
        constructor(e) {
            super(ci(3))
        }
    },
    fi = class extends Error {
        constructor(e) {
            super(ci(4))
        }
    },
    pi = class extends Error {
        constructor(e) {
            super(ci(5)), this.value = e
        }
    },
    mi = class extends Error {
        constructor(e) {
            super(ci(6))
        }
    },
    hi = class extends Error {
        constructor(e) {
            super(ci(7))
        }
    },
    gi = class extends Error {
        constructor(e) {
            super(ci(8))
        }
    },
    _i = class extends Error {
        constructor(e) {
            super(ci(9))
        }
    },
    vi = class {
        constructor(e, t) {
            this.value = e, this.replacement = t
        }
    },
    yi = () => {
        let e = {
            p: 0,
            s: 0,
            f: 0
        };
        return e.p = new Promise((t, n) => {
            e.s = t, e.f = n
        }), e
    };
yi.toString(), ((e, t) => {
    e.s(t), e.p.s = 1, e.p.v = t
}).toString(), ((e, t) => {
    e.f(t), e.p.s = 2, e.p.v = t
}).toString();
var bi = () => {
    let e = [],
        t = [],
        n = !0,
        r = !1,
        i = 0,
        a = (e, n, r) => {
            for (r = 0; r < i; r++) t[r] && t[r][n](e)
        },
        o = (t, i, a, o) => {
            for (i = 0, a = e.length; i < a; i++) o = e[i], !n && i === a - 1 ? t[r ? `return` : `throw`](o) : t.next(o)
        },
        s = (e, r) => (n && (r = i++, t[r] = e), o(e), () => {
            n && (t[r] = t[i], t[i--] = void 0)
        });
    return {
        __SEROVAL_STREAM__: !0,
        on: e => s(e),
        next: t => {
            n && (e.push(t), a(t, `next`))
        },
        throw: i => {
            n && (e.push(i), a(i, `throw`), n = !1, r = !1, t.length = 0)
        },
        return: i => {
            n && (e.push(i), a(i, `return`), n = !1, r = !0, t.length = 0)
        }
    }
};
bi.toString();
var xi = e => t => () => {
    let n = 0,
        r = {
            [e]: () => r,
            next: () => {
                if (n > t.d) return {
                    done: !0,
                    value: void 0
                };
                let e = n++,
                    r = t.v[e];
                if (e === t.t) throw r;
                return {
                    done: e === t.d,
                    value: r
                }
            }
        };
    return r
};
xi.toString();
var Si = (e, t) => n => () => {
    let r = 0,
        i = -1,
        a = !1,
        o = [],
        s = [],
        c = (e = 0, t = s.length) => {
            for (; e < t; e++) s[e].s({
                done: !0,
                value: void 0
            })
        };
    n.on({
        next: e => {
            let t = s.shift();
            t && t.s({
                done: !1,
                value: e
            }), o.push(e)
        },
        throw: e => {
            let t = s.shift();
            t && t.f(e), c(), i = o.length, a = !0, o.push(e)
        },
        return: e => {
            let t = s.shift();
            t && t.s({
                done: !0,
                value: e
            }), c(), i = o.length, o.push(e)
        }
    });
    let l = {
        [e]: () => l,
        next: () => {
            if (i === -1) {
                let e = r++;
                if (e >= o.length) {
                    let e = t();
                    return s.push(e), e.p
                }
                return {
                    done: !1,
                    value: o[e]
                }
            }
            if (r > i) return {
                done: !0,
                value: void 0
            };
            let e = r++,
                n = o[e];
            if (e !== i) return {
                done: !1,
                value: n
            };
            if (a) throw n;
            return {
                done: !0,
                value: n
            }
        }
    };
    return l
};
Si.toString();
var Ci = e => {
    let t = atob(e),
        n = t.length,
        r = new Uint8Array(n);
    for (let e = 0; e < n; e++) r[e] = t.charCodeAt(e);
    return r.buffer
};
Ci.toString();

function wi(e) {
    return `__SEROVAL_SEQUENCE__` in e
}

function Ti(e, t, n) {
    return {
        __SEROVAL_SEQUENCE__: !0,
        v: e,
        t,
        d: n
    }
}

function Ei(e) {
    let t = [],
        n = -1,
        r = -1,
        i = e[Kn]();
    for (;;) try {
        let e = i.next();
        if (t.push(e.value), e.done) {
            r = t.length - 1;
            break
        }
    } catch (e) {
        n = t.length, t.push(e)
    }
    return Ti(t, n, r)
}
var Di = xi(Kn);

function Oi(e) {
    return Di(e)
}
var ki = {},
    Ai = {},
    ji = {
        0: {},
        1: {},
        2: {},
        3: {},
        4: {},
        5: {}
    };

function Mi(e) {
    return `__SEROVAL_STREAM__` in e
}

function Ni() {
    return bi()
}

function Pi(e) {
    let t = Ni(),
        n = e[Un]();
    async function r() {
        try {
            let e = await n.next();
            e.done ? t.return(e.value) : (t.next(e.value), await r())
        } catch (e) {
            t.throw(e)
        }
    }
    return r().catch(() => {}), t
}
var Fi = Si(Un, yi);

function Ii(e) {
    return Fi(e)
}
async function Li(e) {
    try {
        return [1, await e]
    } catch (e) {
        return [0, e]
    }
}

function Ri(e, t) {
    return {
        plugins: t.plugins,
        mode: e,
        marked: new Set,
        features: 63 ^ (t.disabledFeatures || 0),
        refs: t.refs || new Map,
        depthLimit: t.depthLimit || 1e3
    }
}

function zi(e, t) {
    e.marked.add(t)
}

function Bi(e, t) {
    let n = e.refs.size;
    return e.refs.set(t, n), n
}

function Vi(e, t) {
    let n = e.refs.get(t);
    return n == null ? {
        type: 0,
        value: Bi(e, t)
    } : (zi(e, n), {
        type: 1,
        value: Pr(n)
    })
}

function M(e, t) {
    let n = Vi(e, t);
    return n.type === 1 ? n : Cr(t) ? {
        type: 2,
        value: Rr(n.value, t)
    } : n
}

function N(e, t) {
    let n = M(e, t);
    if (n.type !== 0) return n.value;
    if (t in nr) return Lr(n.value, t);
    throw new li(t)
}

function Hi(e, t) {
    let n = Vi(e, ji[t]);
    return n.type === 1 ? n.value : j(26, n.value, t, A, A, A, A, A, A, A, A, A)
}

function Ui(e) {
    let t = Vi(e, ki);
    return t.type === 1 ? t.value : j(27, t.value, A, A, A, A, A, A, N(e, Kn), A, A, A)
}

function Wi(e) {
    let t = Vi(e, Ai);
    return t.type === 1 ? t.value : j(29, t.value, A, A, A, A, A, [Hi(e, 1), N(e, Un)], A, A, A, A)
}

function Gi(e, t, n, r) {
    return j(n ? 11 : 10, e, A, A, A, r, A, A, A, A, Ar(t), A)
}

function Ki(e, t, n, r) {
    return j(8, t, A, A, A, A, {
        k: n,
        v: r
    }, A, Hi(e, 0), A, A, A)
}

function qi(e, t, n) {
    let r = new Uint8Array(n),
        i = ``;
    for (let e = 0, t = r.length; e < t; e++) i += String.fromCharCode(r[e]);
    return j(19, t, _r(btoa(i)), A, A, A, A, A, Hi(e, 5), A, A, A)
}

function Ji(e, t) {
    return {
        base: Ri(e, t),
        child: void 0
    }
}
var Yi = class {
    constructor(e, t) {
        this._p = e, this.depth = t
    }
    parse(e) {
        return ha(this._p, this.depth, e)
    }
};
async function Xi(e, t, n) {
    let r = [];
    for (let i = 0, a = n.length; i < a; i++) i in n ? r[i] = await ha(e, t, n[i]) : r[i] = 0;
    return r
}
async function Zi(e, t, n, r) {
    return Br(n, r, await Xi(e, t, r))
}
async function Qi(e, t, n) {
    let r = Object.entries(n),
        i = [],
        a = [];
    for (let n = 0, o = r.length; n < o; n++) i.push(_r(r[n][0])), a.push(await ha(e, t, r[n][1]));
    return Kn in n && (i.push(N(e.base, Kn)), a.push(Jr(Ui(e.base), await ha(e, t, Ei(n))))), Un in n && (i.push(N(e.base, Un)), a.push(Yr(Wi(e.base), await ha(e, t, Pi(n))))), er in n && (i.push(N(e.base, er)), a.push(Mr(n[er]))), Gn in n && (i.push(N(e.base, Gn)), a.push(n[Gn] ? cr : lr)), {
        k: i,
        v: a
    }
}
async function $i(e, t, n, r, i) {
    return Gi(n, r, i, await Qi(e, t, r))
}
async function ea(e, t, n, r) {
    return Vr(n, await ha(e, t, r.valueOf()))
}
async function ta(e, t, n, r) {
    return Hr(n, r, await ha(e, t, r.buffer))
}
async function na(e, t, n, r) {
    return Ur(n, r, await ha(e, t, r.buffer))
}
async function ra(e, t, n, r) {
    return Wr(n, r, await ha(e, t, r.buffer))
}
async function ia(e, t, n, r) {
    let i = kr(r, e.base.features);
    return Gr(n, r, i ? await Qi(e, t, i) : A)
}
async function aa(e, t, n, r) {
    let i = kr(r, e.base.features);
    return Kr(n, r, i ? await Qi(e, t, i) : A)
}
async function oa(e, t, n, r) {
    let i = [],
        a = [];
    for (let [n, o] of r.entries()) i.push(await ha(e, t, n)), a.push(await ha(e, t, o));
    return Ki(e.base, n, i, a)
}
async function sa(e, t, n, r) {
    let i = [];
    for (let n of r.keys()) i.push(await ha(e, t, n));
    return qr(n, i)
}
async function ca(e, t, n, r) {
    let i = e.base.plugins;
    if (i)
        for (let a = 0, o = i.length; a < o; a++) {
            let o = i[a];
            if (o.parse.async && o.test(r)) return zr(n, o.tag, await o.parse.async(r, new Yi(e, t), {
                id: n
            }))
        }
    return A
}
async function la(e, t, n, r) {
    let [i, a] = await Li(r);
    return j(12, n, i, A, A, A, A, A, await ha(e, t, a), A, A, A)
}

function ua(e, t, n, r, i) {
    let a = [],
        o = n.on({
            next: n => {
                zi(this.base, t), ha(this, e, n).then(e => {
                    a.push(Zr(t, e))
                }, e => {
                    i(e), o()
                })
            },
            throw: n => {
                zi(this.base, t), ha(this, e, n).then(e => {
                    a.push(Qr(t, e)), r(a), o()
                }, e => {
                    i(e), o()
                })
            },
            return: n => {
                zi(this.base, t), ha(this, e, n).then(e => {
                    a.push($r(t, e)), r(a), o()
                }, e => {
                    i(e), o()
                })
            }
        })
}
async function da(e, t, n, r) {
    return Xr(n, Hi(e.base, 4), await new Promise(ua.bind(e, t, n, r)))
}
async function fa(e, t, n, r) {
    let i = [];
    for (let n = 0, a = r.v.length; n < a; n++) i[n] = await ha(e, t, r.v[n]);
    return ei(n, i, r.t, r.d)
}
async function pa(e, t, n, r) {
    if (Array.isArray(r)) return Zi(e, t, n, r);
    if (Mi(r)) return da(e, t, n, r);
    if (wi(r)) return fa(e, t, n, r);
    let i = r.constructor;
    if (i === vi) return ha(e, t, r.replacement);
    let a = await ca(e, t, n, r);
    if (a) return a;
    switch (i) {
        case Object:
            return $i(e, t, n, r, !1);
        case A:
            return $i(e, t, n, r, !0);
        case Date:
            return Fr(n, r);
        case Error:
        case EvalError:
        case RangeError:
        case ReferenceError:
        case SyntaxError:
        case TypeError:
        case URIError:
            return ia(e, t, n, r);
        case Number:
        case Boolean:
        case String:
        case BigInt:
            return ea(e, t, n, r);
        case ArrayBuffer:
            return qi(e.base, n, r);
        case Int8Array:
        case Int16Array:
        case Int32Array:
        case Uint8Array:
        case Uint16Array:
        case Uint32Array:
        case Uint8ClampedArray:
        case Float32Array:
        case Float64Array:
            return ta(e, t, n, r);
        case DataView:
            return ra(e, t, n, r);
        case Map:
            return oa(e, t, n, r);
        case Set:
            return sa(e, t, n, r);
        default:
            break
    }
    if (i === Promise || r instanceof Promise) return la(e, t, n, r);
    let o = e.base.features;
    if (o & 32 && i === RegExp) return Ir(n, r);
    if (o & 16) switch (i) {
        case BigInt64Array:
        case BigUint64Array:
            return na(e, t, n, r);
        default:
            break
    }
    if (o & 1 && typeof AggregateError < `u` && (i === AggregateError || r instanceof AggregateError)) return aa(e, t, n, r);
    if (r instanceof Error) return ia(e, t, n, r);
    if (Kn in r || Un in r) return $i(e, t, n, r, !!i);
    throw new li(r)
}
async function ma(e, t, n) {
    let r = M(e.base, n);
    if (r.type !== 0) return r.value;
    let i = await ca(e, t, r.value, n);
    if (i) return i;
    throw new li(n)
}
async function ha(e, t, n) {
    switch (typeof n) {
        case `boolean`:
            return n ? cr : lr;
        case `undefined`:
            return ur;
        case `string`:
            return Mr(n);
        case `number`:
            return jr(n);
        case `bigint`:
            return Nr(n);
        case `object`:
            if (n) {
                let r = M(e.base, n);
                return r.type === 0 ? await pa(e, t + 1, r.value, n) : r.value
            }
            return dr;
        case `symbol`:
            return N(e.base, n);
        case `function`:
            return ma(e, t, n);
        default:
            throw new li(n)
    }
}
async function ga(e, t) {
    try {
        return await ha(e, 0, t)
    } catch (e) {
        throw e instanceof oi ? e : new oi(e)
    }
}
var _a = (e => (e[e.Vanilla = 1] = `Vanilla`, e[e.Cross = 2] = `Cross`, e))(_a || {});

function va(e) {
    return e
}

function ya(e, t) {
    for (let n = 0, r = t.length; n < r; n++) {
        let r = t[n];
        e.has(r) || (e.add(r), r.extends && ya(e, r.extends))
    }
}

function ba(e) {
    if (e) {
        let t = new Set;
        return ya(t, e), [...t]
    }
}

function xa(e) {
    switch (e) {
        case `Int8Array`:
            return Int8Array;
        case `Int16Array`:
            return Int16Array;
        case `Int32Array`:
            return Int32Array;
        case `Uint8Array`:
            return Uint8Array;
        case `Uint16Array`:
            return Uint16Array;
        case `Uint32Array`:
            return Uint32Array;
        case `Uint8ClampedArray`:
            return Uint8ClampedArray;
        case `Float32Array`:
            return Float32Array;
        case `Float64Array`:
            return Float64Array;
        case `BigInt64Array`:
            return BigInt64Array;
        case `BigUint64Array`:
            return BigUint64Array;
        default:
            throw new hi(e)
    }
}
var Sa = 1e6,
    Ca = 1e4,
    wa = 2e4;

function Ta(e, t) {
    switch (t) {
        case 3:
            return Object.freeze(e);
        case 1:
            return Object.preventExtensions(e);
        case 2:
            return Object.seal(e);
        default:
            return e
    }
}
var Ea = 1e3;

function Da(e, t) {
    let n = t.refs || new Map;
    return `types` in n || Object.assign(n, {
        types: new Map
    }), {
        mode: e,
        plugins: t.plugins,
        refs: n,
        features: t.features ? ? 63 ^ (t.disabledFeatures || 0),
        depthLimit: t.depthLimit || Ea
    }
}

function Oa(e) {
    return {
        mode: 2,
        base: Da(2, e),
        child: A
    }
}
var ka = class {
    constructor(e, t) {
        this._p = e, this.depth = t
    }
    deserialize(e) {
        return P(this._p, this.depth, e)
    }
};

function Aa(e, t) {
    if (t < 0 || !Number.isFinite(t) || !Number.isInteger(t)) throw new gi({
        t: 4,
        i: t
    });
    if (e.refs.has(t)) throw Error(`Conflicted ref id: ` + t)
}

function ja(e, t, n) {
    return Aa(e.base, t), e.state.marked.has(t) && e.base.refs.set(t, n), n
}

function Ma(e, t, n) {
    return Aa(e.base, t), e.base.refs.set(t, n), n
}

function Na(e, t, n) {
    return e.mode === 1 ? ja(e, t, n) : Ma(e, t, n)
}

function Pa(e, t, n) {
    if (Object.hasOwn(t, n)) return t[n];
    throw new gi(e)
}

function Fa(e, t) {
    return Na(e, t.i, Er(yr(t.s)))
}

function Ia(e, t, n) {
    let r = n.a,
        i = r.length,
        a = Na(e, n.i, Array(i));
    for (let n = 0, o; n < i; n++) o = r[n], o && (a[n] = P(e, t, o));
    return Ta(a, n.o), a
}

function La(e) {
    switch (e) {
        case `constructor`:
        case `__proto__`:
        case `prototype`:
        case `__defineGetter__`:
        case `__defineSetter__`:
        case `__lookupGetter__`:
        case `__lookupSetter__`:
            return !1;
        default:
            return !0
    }
}

function Ra(e) {
    switch (e) {
        case Un:
        case Gn:
        case er:
        case Kn:
            return !0;
        default:
            return !1
    }
}

function za(e, t, n) {
    La(t) ? e[t] = n : Object.defineProperty(e, t, {
        value: n,
        configurable: !0,
        enumerable: !0,
        writable: !0
    })
}

function Ba(e, t, n, r, i) {
    if (typeof r == `string`) za(n, yr(r), P(e, t, i));
    else {
        let a = P(e, t, r);
        switch (typeof a) {
            case `string`:
                za(n, a, P(e, t, i));
                break;
            case `symbol`:
                Ra(a) && (n[a] = P(e, t, i));
                break;
            default:
                throw new gi(r)
        }
    }
}

function Va(e, t, n) {
    e.base.refs.types.set(t, n)
}

function Ha(e, t, n, r) {
    if (e.base.refs.types.get(n) !== r) throw new gi(t)
}

function Ua(e, t, n, r) {
    let i = n.k;
    if (i.length > 0)
        for (let a = 0, o = n.v, s = i.length; a < s; a++) Ba(e, t, r, i[a], o[a]);
    return r
}

function Wa(e, t, n) {
    let r = Na(e, n.i, n.t === 10 ? {} : Object.create(null));
    return Ua(e, t, n.p, r), Ta(r, n.o), r
}

function Ga(e, t) {
    return Na(e, t.i, new Date(t.s))
}

function Ka(e, t) {
    if (e.base.features & 32) {
        let n = yr(t.c);
        if (n.length > wa) throw new gi(t);
        return Na(e, t.i, new RegExp(n, t.m))
    }
    throw new ui(t)
}

function qa(e, t, n) {
    let r = Na(e, n.i, new Set);
    for (let i = 0, a = n.a, o = a.length; i < o; i++) r.add(P(e, t, a[i]));
    return r
}

function Ja(e, t, n) {
    let r = Na(e, n.i, new Map);
    for (let i = 0, a = n.e.k, o = n.e.v, s = a.length; i < s; i++) r.set(P(e, t, a[i]), P(e, t, o[i]));
    return r
}

function Ya(e, t) {
    if (t.s.length > Sa) throw new gi(t);
    return Na(e, t.i, Ci(yr(t.s)))
}

function Xa(e, t, n) {
    let r = xa(n.c),
        i = P(e, t, n.f),
        a = n.b ? ? 0;
    if (a < 0 || a > i.byteLength) throw new gi(n);
    return Na(e, n.i, new r(i, a, n.l))
}

function Za(e, t, n) {
    let r = P(e, t, n.f),
        i = n.b ? ? 0;
    if (i < 0 || i > r.byteLength) throw new gi(n);
    return Na(e, n.i, new DataView(r, i, n.l))
}

function Qa(e, t, n, r) {
    if (n.p) {
        let i = Ua(e, t, n.p, {});
        Object.defineProperties(r, Object.getOwnPropertyDescriptors(i))
    }
    return r
}

function $a(e, t, n) {
    return Qa(e, t, n, Na(e, n.i, AggregateError([], yr(n.m))))
}

function eo(e, t, n) {
    let r = Pa(n, or, n.s);
    return Qa(e, t, n, Na(e, n.i, new r(yr(n.m))))
}

function to(e, t, n) {
    let r = yi(),
        i = Na(e, n.i, r.p),
        a = P(e, t, n.f);
    return n.s ? r.s(a) : r.f(a), i
}

function no(e, t, n) {
    return Na(e, n.i, Object(P(e, t, n.f)))
}

function ro(e, t, n) {
    let r = e.base.plugins;
    if (r) {
        let i = yr(n.c);
        for (let a = 0, o = r.length; a < o; a++) {
            let o = r[a];
            if (o.tag === i) return Na(e, n.i, o.deserialize(n.s, new ka(e, t), {
                id: n.i
            }))
        }
    }
    throw new di(n.c)
}

function io(e, t) {
    let n = Na(e, t.i, Na(e, t.s, yi()).p);
    return Va(e, t.s, 22), n
}

function ao(e, t, n) {
    let r = e.base.refs.get(n.i);
    if (r) return Ha(e, n, n.i, 22), r.s(P(e, t, n.a[1])), A;
    throw new fi(`Promise`)
}

function oo(e, t, n) {
    let r = e.base.refs.get(n.i);
    if (r) return Ha(e, n, n.i, 22), r.f(P(e, t, n.a[1])), A;
    throw new fi(`Promise`)
}

function so(e, t, n) {
    return P(e, t, n.a[0]), Oi(P(e, t, n.a[1]))
}

function co(e, t, n) {
    return P(e, t, n.a[0]), Ii(P(e, t, n.a[1]))
}

function lo(e, t, n) {
    let r = Na(e, n.i, Ni());
    Va(e, n.i, 31);
    let i = n.a,
        a = i.length;
    if (a)
        for (let n = 0; n < a; n++) P(e, t, i[n]);
    return r
}

function uo(e, t, n) {
    let r = e.base.refs.get(n.i);
    if (r) return Ha(e, n, n.i, 31), r.next(P(e, t, n.f)), A;
    throw new fi(`Stream`)
}

function fo(e, t, n) {
    let r = e.base.refs.get(n.i);
    if (r) return Ha(e, n, n.i, 31), r.throw(P(e, t, n.f)), A;
    throw new fi(`Stream`)
}

function po(e, t, n) {
    let r = e.base.refs.get(n.i);
    if (r) return Ha(e, n, n.i, 31), r.return(P(e, t, n.f)), A;
    throw new fi(`Stream`)
}

function mo(e, t, n) {
    return P(e, t, n.f), A
}

function ho(e, t, n) {
    return P(e, t, n.a[1]), A
}

function go(e, t, n) {
    let r = Na(e, n.i, Ti([], n.s, n.l));
    for (let i = 0, a = n.a.length; i < a; i++) r.v[i] = P(e, t, n.a[i]);
    return r
}

function P(e, t, n) {
    if (t > e.base.depthLimit) throw new _i(e.base.depthLimit);
    switch (t += 1, n.t) {
        case 2:
            return Pa(n, ir, n.s);
        case 0:
            return Number(n.s);
        case 1:
            return yr(String(n.s));
        case 3:
            if (String(n.s).length > Ca) throw new gi(n);
            return BigInt(n.s);
        case 4:
            return e.base.refs.get(n.i);
        case 18:
            return Fa(e, n);
        case 9:
            return Ia(e, t, n);
        case 10:
        case 11:
            return Wa(e, t, n);
        case 5:
            return Ga(e, n);
        case 6:
            return Ka(e, n);
        case 7:
            return qa(e, t, n);
        case 8:
            return Ja(e, t, n);
        case 19:
            return Ya(e, n);
        case 16:
        case 15:
            return Xa(e, t, n);
        case 20:
            return Za(e, t, n);
        case 14:
            return $a(e, t, n);
        case 13:
            return eo(e, t, n);
        case 12:
            return to(e, t, n);
        case 17:
            return Pa(n, rr, n.s);
        case 21:
            return no(e, t, n);
        case 25:
            return ro(e, t, n);
        case 22:
            return io(e, n);
        case 23:
            return ao(e, t, n);
        case 24:
            return oo(e, t, n);
        case 28:
            return so(e, t, n);
        case 30:
            return co(e, t, n);
        case 31:
            return lo(e, t, n);
        case 32:
            return uo(e, t, n);
        case 33:
            return fo(e, t, n);
        case 34:
            return po(e, t, n);
        case 27:
            return mo(e, t, n);
        case 29:
            return ho(e, t, n);
        case 35:
            return go(e, t, n);
        default:
            throw new ui(n)
    }
}

function _o(e, t) {
    try {
        return P(e, 0, t)
    } catch (e) {
        throw new si(e)
    }
}
var vo = (() => T).toString();
/=>/.test(vo);

function yo(e, t) {
    return _o(Oa({
        plugins: ba(t.plugins),
        refs: t.refs,
        features: t.features,
        disabledFeatures: t.disabledFeatures,
        depthLimit: t.depthLimit
    }), e)
}
async function F(e, t = {}) {
    let n = Ji(1, {
        plugins: ba(t.plugins),
        disabledFeatures: t.disabledFeatures
    });
    return {
        t: await ga(n, e),
        f: n.base.features,
        m: Array.from(n.base.marked)
    }
}

function I(e) {
    return e
}

function bo(e) {
    return va({
        tag: `$TSR/t/` + e.key,
        test: e.test,
        parse: {
            sync(t, n, r) {
                return {
                    v: n.parse(e.toSerializable(t))
                }
            },
            async async (t, n, r) {
                return {
                    v: await n.parse(e.toSerializable(t))
                }
            },
            stream(t, n, r) {
                return {
                    v: n.parse(e.toSerializable(t))
                }
            }
        },
        serialize: void 0,
        deserialize(t, n, r) {
            return e.fromSerializable(n.deserialize(t.v))
        }
    })
}
var xo = class {
        constructor(e, t) {
            this.stream = e, this.hint = t ? .hint ? ? `binary`
        }
    },
    So = globalThis.Buffer,
    Co = !!So && typeof So.from == `function`;

function wo(e) {
    if (e.length === 0) return ``;
    if (Co) return So.from(e).toString(`base64`);
    let t = 32768,
        n = [];
    for (let r = 0; r < e.length; r += t) {
        let i = e.subarray(r, r + t);
        n.push(String.fromCharCode.apply(null, i))
    }
    return btoa(n.join(``))
}

function To(e) {
    if (e.length === 0) return new Uint8Array;
    if (Co) {
        let t = So.from(e, `base64`);
        return new Uint8Array(t.buffer, t.byteOffset, t.byteLength)
    }
    let t = atob(e),
        n = new Uint8Array(t.length);
    for (let e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
    return n
}
var Eo = Object.create(null),
    Do = Object.create(null),
    L = e => new ReadableStream({
        start(t) {
            e.on({
                next(e) {
                    try {
                        t.enqueue(To(e))
                    } catch {}
                },
                throw (e) {
                    t.error(e)
                },
                return () {
                    try {
                        t.close()
                    } catch {}
                }
            })
        }
    }),
    Oo = new TextEncoder,
    ko = e => new ReadableStream({
        start(t) {
            e.on({
                next(e) {
                    try {
                        typeof e == `string` ? t.enqueue(Oo.encode(e)) : t.enqueue(To(e.$b64))
                    } catch {}
                },
                throw (e) {
                    t.error(e)
                },
                return () {
                    try {
                        t.close()
                    } catch {}
                }
            })
        }
    }),
    Ao = `(s=>new ReadableStream({start(c){s.on({next(b){try{const d=atob(b),a=new Uint8Array(d.length);for(let i=0;i<d.length;i++)a[i]=d.charCodeAt(i);c.enqueue(a)}catch(_){}},throw(e){c.error(e)},return(){try{c.close()}catch(_){}}})}}))`,
    jo = `(s=>{const e=new TextEncoder();return new ReadableStream({start(c){s.on({next(v){try{if(typeof v==='string'){c.enqueue(e.encode(v))}else{const d=atob(v.$b64),a=new Uint8Array(d.length);for(let i=0;i<d.length;i++)a[i]=d.charCodeAt(i);c.enqueue(a)}}catch(_){}},throw(x){c.error(x)},return(){try{c.close()}catch(_){}}})}})})`;

function Mo(e) {
    let t = Ni(),
        n = e.getReader();
    return (async () => {
        try {
            for (;;) {
                let {
                    done: e,
                    value: r
                } = await n.read();
                if (e) {
                    t.return(void 0);
                    break
                }
                t.next(wo(r))
            }
        } catch (e) {
            t.throw(e)
        } finally {
            n.releaseLock()
        }
    })(), t
}

function No(e) {
    let t = Ni(),
        n = e.getReader(),
        r = new TextDecoder(`utf-8`, {
            fatal: !0
        });
    return (async () => {
        try {
            for (;;) {
                let {
                    done: e,
                    value: i
                } = await n.read();
                if (e) {
                    try {
                        let e = r.decode();
                        e.length > 0 && t.next(e)
                    } catch {}
                    t.return(void 0);
                    break
                }
                try {
                    let e = r.decode(i, {
                        stream: !0
                    });
                    e.length > 0 && t.next(e)
                } catch {
                    t.next({
                        $b64: wo(i)
                    })
                }
            }
        } catch (e) {
            t.throw(e)
        } finally {
            n.releaseLock()
        }
    })(), t
}
var Po = va({
    tag: `tss/RawStream`,
    extends: [va({
        tag: `tss/RawStreamFactory`,
        test(e) {
            return e === Eo
        },
        parse: {
            sync(e, t, n) {
                return {}
            },
            async async (e, t, n) {
                return {}
            },
            stream(e, t, n) {
                return {}
            }
        },
        serialize(e, t, n) {
            return Ao
        },
        deserialize(e, t, n) {
            return Eo
        }
    }), va({
        tag: `tss/RawStreamFactoryText`,
        test(e) {
            return e === Do
        },
        parse: {
            sync(e, t, n) {
                return {}
            },
            async async (e, t, n) {
                return {}
            },
            stream(e, t, n) {
                return {}
            }
        },
        serialize(e, t, n) {
            return jo
        },
        deserialize(e, t, n) {
            return Do
        }
    })],
    test(e) {
        return e instanceof xo
    },
    parse: {
        sync(e, t, n) {
            let r = e.hint === `text` ? Do : Eo;
            return {
                hint: t.parse(e.hint),
                factory: t.parse(r),
                stream: t.parse(Ni())
            }
        },
        async async (e, t, n) {
            let r = e.hint === `text` ? Do : Eo,
                i = e.hint === `text` ? No(e.stream) : Mo(e.stream);
            return {
                hint: await t.parse(e.hint),
                factory: await t.parse(r),
                stream: await t.parse(i)
            }
        },
        stream(e, t, n) {
            let r = e.hint === `text` ? Do : Eo,
                i = e.hint === `text` ? No(e.stream) : Mo(e.stream);
            return {
                hint: t.parse(e.hint),
                factory: t.parse(r),
                stream: t.parse(i)
            }
        }
    },
    serialize(e, t, n) {
        return `(` + t.serialize(e.factory) + `)(` + t.serialize(e.stream) + `)`
    },
    deserialize(e, t, n) {
        let r = t.deserialize(e.stream);
        return t.deserialize(e.hint) === `text` ? ko(r) : L(r)
    }
});

function Fo(e) {
    return va({
        tag: `tss/RawStream`,
        test: () => !1,
        parse: {},
        serialize() {
            throw Error(`RawStreamDeserializePlugin.serialize should not be called. Client only deserializes.`)
        },
        deserialize(t, n, r) {
            return e(typeof n ? .deserialize == `function` ? n.deserialize(t.streamId) : t.streamId)
        }
    })
}
var Io = va({
        tag: `$TSR/Error`,
        test(e) {
            return e instanceof Error
        },
        parse: {
            sync(e, t) {
                return {
                    message: t.parse(e.message)
                }
            },
            async async (e, t) {
                return {
                    message: await t.parse(e.message)
                }
            },
            stream(e, t) {
                return {
                    message: t.parse(e.message)
                }
            }
        },
        serialize(e, t) {
            return `new Error(` + t.serialize(e.message) + `)`
        },
        deserialize(e, t) {
            return Error(t.deserialize(e.message))
        }
    }),
    R = {},
    Lo = e => new ReadableStream({
        start: t => {
            e.on({
                next: e => {
                    try {
                        t.enqueue(e)
                    } catch {}
                },
                throw: e => {
                    t.error(e)
                },
                return: () => {
                    try {
                        t.close()
                    } catch {}
                }
            })
        }
    }),
    Ro = va({
        tag: `seroval-plugins/web/ReadableStreamFactory`,
        test(e) {
            return e === R
        },
        parse: {
            sync() {
                return R
            },
            async async () {
                return await Promise.resolve(R)
            },
            stream() {
                return R
            }
        },
        serialize() {
            return Lo.toString()
        },
        deserialize() {
            return R
        }
    });

function zo(e) {
    let t = Ni(),
        n = e.getReader();
    async function r() {
        try {
            let e = await n.read();
            e.done ? t.return(e.value) : (t.next(e.value), await r())
        } catch (e) {
            t.throw(e)
        }
    }
    return r().catch(() => {}), t
}
var Bo = [Io, Po, va({
    tag: `seroval/plugins/web/ReadableStream`,
    extends: [Ro],
    test(e) {
        return typeof ReadableStream > `u` ? !1 : e instanceof ReadableStream
    },
    parse: {
        sync(e, t) {
            return {
                factory: t.parse(R),
                stream: t.parse(Ni())
            }
        },
        async async (e, t) {
            return {
                factory: await t.parse(R),
                stream: await t.parse(zo(e))
            }
        },
        stream(e, t) {
            return {
                factory: t.parse(R),
                stream: t.parse(zo(e))
            }
        }
    },
    serialize(e, t) {
        return `(` + t.serialize(e.factory) + `)(` + t.serialize(e.stream) + `)`
    },
    deserialize(e, t) {
        return Lo(t.deserialize(e.stream))
    }
})];

function Vo() {
    return [...(C() ? .serializationAdapters) ? .map(bo) ? ? [], ...Bo]
}
var Ho = new TextDecoder,
    Uo = new Uint8Array,
    Wo = 16 * 1024 * 1024,
    Go = 32 * 1024 * 1024,
    Ko = 1024,
    qo = 1e5;

function Jo(e) {
    let t = new Map,
        n = new Map,
        r = new Set,
        i = !1,
        a = null,
        o = 0,
        s, c = new ReadableStream({
            start(e) {
                s = e
            },
            cancel() {
                i = !0;
                try {
                    a ? .cancel()
                } catch {}
                t.forEach(e => {
                    try {
                        e.error(Error(`Framed response cancelled`))
                    } catch {}
                }), t.clear(), n.clear(), r.clear()
            }
        });

    function l(e) {
        let i = n.get(e);
        if (i) return i;
        if (r.has(e)) return new ReadableStream({
            start(e) {
                e.close()
            }
        });
        if (n.size >= Ko) throw Error(`Too many raw streams in framed response (max ${Ko})`);
        let a = new ReadableStream({
            start(n) {
                t.set(e, n)
            },
            cancel() {
                r.add(e), t.delete(e), n.delete(e)
            }
        });
        return n.set(e, a), a
    }

    function u(e) {
        return l(e), t.get(e)
    }
    return (async () => {
        let n = e.getReader();
        a = n;
        let c = [],
            l = 0;

        function d() {
            if (l < 9) return null;
            let e = c[0];
            if (e.length >= 9) return {
                type: e[0],
                streamId: (e[1] << 24 | e[2] << 16 | e[3] << 8 | e[4]) >>> 0,
                length: (e[5] << 24 | e[6] << 16 | e[7] << 8 | e[8]) >>> 0
            };
            let t = new Uint8Array(9),
                n = 0,
                r = 9;
            for (let e = 0; e < c.length && r > 0; e++) {
                let i = c[e],
                    a = Math.min(i.length, r);
                t.set(i.subarray(0, a), n), n += a, r -= a
            }
            return {
                type: t[0],
                streamId: (t[1] << 24 | t[2] << 16 | t[3] << 8 | t[4]) >>> 0,
                length: (t[5] << 24 | t[6] << 16 | t[7] << 8 | t[8]) >>> 0
            }
        }

        function f(e) {
            if (e === 0) return Uo;
            let t = new Uint8Array(e),
                n = 0,
                r = e;
            for (; r > 0 && c.length > 0;) {
                let e = c[0];
                if (!e) break;
                let i = Math.min(e.length, r);
                t.set(e.subarray(0, i), n), n += i, r -= i, i === e.length ? c.shift() : c[0] = e.subarray(i)
            }
            return l -= e, t
        }
        try {
            for (;;) {
                let {
                    done: e,
                    value: a
                } = await n.read();
                if (i || e) break;
                if (a) {
                    if (l + a.length > Go) throw Error(`Framed response buffer exceeded ${Go} bytes`);
                    for (c.push(a), l += a.length;;) {
                        let e = d();
                        if (!e) break;
                        let {
                            type: n,
                            streamId: i,
                            length: a
                        } = e;
                        if (n !== b.JSON && n !== b.CHUNK && n !== b.END && n !== b.ERROR) throw Error(`Unknown frame type: ${n}`);
                        if (n === b.JSON) {
                            if (i !== 0) throw Error(`Invalid JSON frame streamId (expected 0)`)
                        } else if (i === 0) throw Error(`Invalid raw frame streamId (expected non-zero)`);
                        if (a > Wo) throw Error(`Frame payload too large: ${a} bytes (max ${Wo})`);
                        let c = 9 + a;
                        if (l < c) break;
                        if (++o > qo) throw Error(`Too many frames in framed response (max ${qo})`);
                        f(9);
                        let p = f(a);
                        switch (n) {
                            case b.JSON:
                                try {
                                    s.enqueue(Ho.decode(p))
                                } catch {}
                                break;
                            case b.CHUNK:
                                {
                                    let e = u(i);e && e.enqueue(p);
                                    break
                                }
                            case b.END:
                                {
                                    let e = u(i);
                                    if (r.add(i), e) {
                                        try {
                                            e.close()
                                        } catch {}
                                        t.delete(i)
                                    }
                                    break
                                }
                            case b.ERROR:
                                {
                                    let e = u(i);
                                    if (r.add(i), e) {
                                        let n = Ho.decode(p);
                                        e.error(Error(n)), t.delete(i)
                                    }
                                    break
                                }
                        }
                    }
                }
            }
            if (l !== 0) throw Error(`Incomplete frame at end of framed response`);
            try {
                s.close()
            } catch {}
            t.forEach(e => {
                try {
                    e.close()
                } catch {}
            }), t.clear()
        } catch (e) {
            try {
                s.error(e)
            } catch {}
            t.forEach(t => {
                try {
                    t.error(e)
                } catch {}
            }), t.clear()
        } finally {
            try {
                n.releaseLock()
            } catch {}
            a = null
        }
    })(), {
        getOrCreateStream: l,
        jsonChunks: c
    }
}
var Yo = null;
async function Xo(e) {
    e.length > 0 && await Promise.allSettled(e)
}
var Zo = Object.prototype.hasOwnProperty;

function Qo(e) {
    for (let t in e)
        if (Zo.call(e, t)) return !0;
    return !1
}
async function $o(e, t, n) {
    Yo || = Vo();
    let r = t[0],
        i = r.fetch ? ? n,
        a = r.data instanceof FormData ? `formData` : `payload`,
        o = r.headers ? new Headers(r.headers) : new Headers;
    if (o.set(`x-tsr-serverFn`, `true`), a === `payload` && o.set(`accept`, `${y}, application/x-ndjson, application/json`), r.method === `GET`) {
        if (a === `formData`) throw Error(`FormData is not supported with GET requests`);
        let t = await es(r);
        if (t !== void 0) {
            let n = lt({
                payload: t
            });
            e.includes(`?`) ? e += `&${n}` : e += `?${n}`
        }
    }
    let s;
    if (r.method === `POST`) {
        let e = await ns(r);
        e ? .contentType && o.set(`content-type`, e.contentType), s = e ? .body
    }
    return await rs(async () => i(e, {
        method: r.method,
        headers: o,
        signal: r.signal,
        body: s
    }))
}
async function es(e) {
    let t = !1,
        n = {};
    if (e.data !== void 0 && (t = !0, n.data = e.data), e.context && Qo(e.context) && (t = !0, n.context = e.context), t) return ts(n)
}
async function ts(e) {
    return JSON.stringify(await Promise.resolve(F(e, {
        plugins: Yo
    })))
}
async function ns(e) {
    if (e.data instanceof FormData) {
        let t;
        return e.context && Qo(e.context) && (t = await ts(e.context)), t !== void 0 && e.data.set(_, t), {
            body: e.data
        }
    }
    let t = await es(e);
    if (t) return {
        body: t,
        contentType: `application/json`
    }
}
async function rs(e) {
    let t;
    try {
        t = await e()
    } catch (e) {
        if (e instanceof Response) t = e;
        else throw console.log(e), e
    }
    if (t.headers.get(`x-tss-raw`) === `true`) return t;
    let n = t.headers.get(`content-type`);
    if (n || we(), t.headers.get(`x-tss-serialized`)) {
        let e;
        if (n.includes(`application/x-tss-framed`)) {
            if (S(n), !t.body) throw Error(`No response body for framed response`);
            let {
                getOrCreateStream: r,
                jsonChunks: i
            } = Jo(t.body), a = [Fo(r), ...Yo || []], o = new Map;
            e = await is({
                jsonStream: i,
                onMessage: e => yo(e, {
                    refs: o,
                    plugins: a
                }),
                onError(e, t) {
                    console.error(e, t)
                }
            })
        } else if (n.includes(`application/json`)) {
            let n = await t.json(),
                r = [];
            try {
                e = yo(n, {
                    plugins: Yo
                })
            } finally {}
            await Xo(r)
        }
        if (e || we(), e instanceof Error) throw e;
        return e
    }
    if (n.includes(`application/json`)) {
        let e = await t.json(),
            n = vt(e);
        if (n) throw n;
        if (ct(e)) throw e;
        return e
    }
    if (!t.ok) throw Error(await t.text());
    return t
}
async function is({
    jsonStream: e,
    onMessage: t,
    onError: n
}) {
    let r = e.getReader(),
        {
            value: i,
            done: a
        } = await r.read();
    if (a || !i) throw Error(`Stream ended before first object`);
    let o = JSON.parse(i),
        s = !1,
        c = (async () => {
            try {
                for (;;) {
                    let {
                        value: e,
                        done: i
                    } = await r.read();
                    if (i) break;
                    if (e) try {
                        let n = [];
                        try {
                            t(JSON.parse(e))
                        } finally {}
                        await Xo(n)
                    } catch (t) {
                        n ? .(`Invalid JSON: ${e}`, t)
                    }
                }
            } catch (e) {
                s || n ? .(`Stream processing error:`, e)
            }
        })(),
        l, u = [];
    try {
        l = t(o)
    } catch (e) {
        throw s = !0, r.cancel().catch(() => {}), e
    }
    return await Xo(u), Promise.resolve(l).catch(() => {
        s = !0, r.cancel().catch(() => {})
    }), c.finally(() => {
        try {
            r.releaseLock()
        } catch {}
    }), l
}

function as(e) {
    let t = `/_serverFn/` + e;
    return Object.assign((...e) => {
        let n = C() ? .serverFns ? .fetch;
        return $o(t, e, n ? ? fetch)
    }, {
        url: t,
        serverFnMeta: {
            id: e
        },
        [v]: !0
    })
}
var os = I({
    key: `$TSS/serverfn`,
    test: e => typeof e != `function` || !(v in e) ? !1 : !!e[v],
    toSerializable: ({
        serverFnMeta: e
    }) => ({
        functionId: e.id
    }),
    fromSerializable: ({
        functionId: e
    }) => as(e)
});

function ss(e) {
    return e.replaceAll(`\0`, `/`).replaceAll(`�`, `/`)
}

function cs(e, t) {
    e.id = t.i, e.__beforeLoadContext = t.b, e.loaderData = t.l, e.status = t.s, e.ssr = t.ssr, e.updatedAt = t.u, e.error = t.e, t.g !== void 0 && (e.globalNotFound = t.g)
}
async function ls(e) {
    window.$_TSR || we();
    let t = e.options.serializationAdapters;
    if (t ? .length) {
        let e = new Map;
        t.forEach(t => {
            e.set(t.key, t.fromSerializable)
        }), window.$_TSR.t = e, window.$_TSR.buffer.forEach(e => e())
    }
    window.$_TSR.initialized = !0, window.$_TSR.router || we();
    let n = window.$_TSR.router;
    n.matches.forEach(e => {
        e.i = ss(e.i)
    }), n.lastMatchId && = ss(n.lastMatchId);
    let {
        manifest: r,
        dehydratedData: i,
        lastMatchId: a
    } = n;
    e.ssr = {
        manifest: r
    };
    let o = document.querySelector(`meta[property="csp-nonce"]`) ? .content;
    e.options.ssr = {
        nonce: o
    }, await e.options.hydrate ? .(i);
    let s = e.matchRoutes(e.stores.location.get()),
        c = Promise.all(s.map(t => e.loadRouteChunk(e.looseRoutesById[t.routeId])));

    function l(t) {
        let n = e.looseRoutesById[t.routeId].options.pendingMinMs ? ? e.options.defaultPendingMinMs;
        if (n) {
            let r = pe();
            t._nonReactive.minPendingPromise = r, t._forcePending = !0, setTimeout(() => {
                r.resolve(), e.updateMatch(t.id, e => (e._nonReactive.minPendingPromise = void 0, { ...e,
                    _forcePending: void 0
                }))
            }, n)
        }
    }

    function u(t) {
        let n = e.looseRoutesById[t.routeId];
        n && (n.options.ssr = t.ssr)
    }
    let d;
    s.forEach(e => {
        let t = n.matches.find(t => t.i === e.id);
        if (!t) {
            e._nonReactive.dehydrated = !1, e.ssr = !1, u(e);
            return
        }
        cs(e, t), u(e), e._nonReactive.dehydrated = e.ssr !== !1, (e.ssr === `data-only` || e.ssr === !1) && d === void 0 && (d = e.index, l(e))
    }), e.stores.setMatches(s);
    let f = e.stores.matches.get(),
        p = e.stores.location.get();
    await Promise.all(f.map(async t => {
        try {
            let n = e.looseRoutesById[t.routeId],
                r = f[t.index - 1] ? .context ? ? e.options.context;
            if (n.options.context) {
                let i = {
                    deps: t.loaderDeps,
                    params: t.params,
                    context: r ? ? {},
                    location: p,
                    navigate: t => e.navigate({ ...t,
                        _fromLocation: p
                    }),
                    buildLocation: e.buildLocation,
                    cause: t.cause,
                    abortController: t.abortController,
                    preload: !1,
                    matches: s,
                    routeId: n.id
                };
                t.__routeContext = n.options.context(i) ? ? void 0
            }
            t.context = { ...r,
                ...t.__routeContext,
                ...t.__beforeLoadContext
            };
            let i = {
                    ssr: e.options.ssr,
                    matches: f,
                    match: t,
                    params: t.params,
                    loaderData: t.loaderData
                },
                a = await n.options.head ? .(i),
                o = await n.options.scripts ? .(i);
            t.meta = a ? .meta, t.links = a ? .links, t.headScripts = a ? .scripts, t.styles = a ? .styles, t.scripts = o
        } catch (e) {
            if (ct(e)) t.error = {
                isNotFound: !0
            }, console.error(`NotFound error during hydration for routeId: ${t.routeId}`, e);
            else throw t.error = e, console.error(`Error during hydration for route ${t.routeId}:`, e), e
        }
    }));
    let m = s[s.length - 1].id !== a;
    if (!s.some(e => e.ssr === !1) && !m) return s.forEach(e => {
        e._nonReactive.dehydrated = void 0
    }), e.stores.resolvedLocation.set(e.stores.location.get()), c;
    let h = Promise.resolve().then(() => e.load()).catch(e => {
        console.error(`Error during router hydration:`, e)
    });
    if (m) {
        let t = s[1];
        t || we(), l(t), t._displayPending = !0, t._nonReactive.displayPendingPromise = h, h.then(() => {
            e.batch(() => {
                e.stores.status.get() === `pending` && (e.stores.status.set(`idle`), e.stores.resolvedLocation.set(e.stores.location.get())), e.updateMatch(t.id, e => ({ ...e,
                    _displayPending: void 0,
                    displayPendingPromise: void 0
                }))
            })
        })
    }
    return c
}
var z = c(u(), 1),
    us = z.use,
    ds = typeof window < `u` ? z.useLayoutEffect : z.useEffect;

function fs(e) {
    let t = z.useRef({
            value: e,
            prev: null
        }),
        n = t.current.value;
    return e !== n && (t.current = {
        value: e,
        prev: n
    }), t.current.prev
}

function ps(e, t, n = {}, r = {}) {
    z.useEffect(() => {
        if (!e.current || r.disabled || typeof IntersectionObserver != `function`) return;
        let i = new IntersectionObserver(([e]) => {
            t(e)
        }, n);
        return i.observe(e.current), () => {
            i.disconnect()
        }
    }, [t, n, r.disabled, e])
}

function ms(e) {
    let t = z.useRef(null);
    return z.useImperativeHandle(e, () => t.current, []), t
}
var hs = o((e => {
        var t = Symbol.for(`react.transitional.element`),
            n = Symbol.for(`react.fragment`);

        function r(e, n, r) {
            var i = null;
            if (r !== void 0 && (i = `` + r), n.key !== void 0 && (i = `` + n.key), `key` in n)
                for (var a in r = {}, n) a !== `key` && (r[a] = n[a]);
            else r = n;
            return n = r.ref, {
                $$typeof: t,
                type: e,
                key: i,
                ref: n === void 0 ? null : n,
                props: r
            }
        }
        e.Fragment = n, e.jsx = r, e.jsxs = r
    })),
    gs = o(((e, t) => {
        t.exports = hs()
    })),
    B = gs();

function _s({
    promise: e
}) {
    if (us) return us(e);
    let t = Mn(e);
    if (t[jn].status === `pending`) throw t;
    if (t[jn].status === `error`) throw t[jn].error;
    return t[jn].data
}

function vs(e) {
    let t = (0, B.jsx)(ys, { ...e
    });
    return e.fallback ? (0, B.jsx)(z.Suspense, {
        fallback: e.fallback,
        children: t
    }) : t
}

function ys(e) {
    let t = _s(e);
    return e.children(t)
}

function bs(e) {
    let t = e.errorComponent ? ? Ss;
    return (0, B.jsx)(xs, {
        getResetKey: e.getResetKey,
        onCatch: e.onCatch,
        children: ({
            error: n,
            reset: r
        }) => n ? z.createElement(t, {
            error: n,
            reset: r
        }) : e.children
    })
}
var xs = class extends z.Component {
    constructor(...e) {
        super(...e), this.state = {
            error: null
        }
    }
    static getDerivedStateFromProps(e, t) {
        let n = e.getResetKey();
        return t.error && t.resetKey !== n ? {
            resetKey: n,
            error: null
        } : {
            resetKey: n
        }
    }
    static getDerivedStateFromError(e) {
        return {
            error: e
        }
    }
    reset() {
        this.setState({
            error: null
        })
    }
    componentDidCatch(e, t) {
        this.props.onCatch && this.props.onCatch(e, t)
    }
    render() {
        return this.props.children({
            error: this.state.error,
            reset: () => {
                this.reset()
            }
        })
    }
};

function Ss({
    error: e
}) {
    let [t, n] = z.useState(!1);
    return (0, B.jsxs)(`div`, {
        style: {
            padding: `.5rem`,
            maxWidth: `100%`
        },
        children: [(0, B.jsxs)(`div`, {
            style: {
                display: `flex`,
                alignItems: `center`,
                gap: `.5rem`
            },
            children: [(0, B.jsx)(`strong`, {
                style: {
                    fontSize: `1rem`
                },
                children: `Something went wrong!`
            }), (0, B.jsx)(`button`, {
                style: {
                    appearance: `none`,
                    fontSize: `.6em`,
                    border: `1px solid currentColor`,
                    padding: `.1rem .2rem`,
                    fontWeight: `bold`,
                    borderRadius: `.25rem`
                },
                onClick: () => n(e => !e),
                children: t ? `Hide Error` : `Show Error`
            })]
        }), (0, B.jsx)(`div`, {
            style: {
                height: `.25rem`
            }
        }), t ? (0, B.jsx)(`div`, {
            children: (0, B.jsx)(`pre`, {
                style: {
                    fontSize: `.7em`,
                    border: `1px solid red`,
                    borderRadius: `.25rem`,
                    padding: `.3rem`,
                    color: `red`,
                    overflow: `auto`
                },
                children: e.message ? (0, B.jsx)(`code`, {
                    children: e.message
                }) : null
            })
        }) : null]
    })
}

function Cs({
    children: e,
    fallback: t = null
}) {
    return ws() ? (0, B.jsx)(z.Fragment, {
        children: e
    }) : (0, B.jsx)(z.Fragment, {
        children: t
    })
}

function ws() {
    return z.useSyncExternalStore(Ts, () => !0, () => !1)
}

function Ts() {
    return () => {}
}
var Es = z.createContext(null);

function Ds(e) {
    return z.useContext(Es)
}
var Os = z.createContext(void 0),
    ks = z.createContext(void 0),
    V = (e => (e[e.None = 0] = `None`, e[e.Mutable = 1] = `Mutable`, e[e.Watching = 2] = `Watching`, e[e.RecursedCheck = 4] = `RecursedCheck`, e[e.Recursed = 8] = `Recursed`, e[e.Dirty = 16] = `Dirty`, e[e.Pending = 32] = `Pending`, e))(V || {});

function As({
    update: e,
    notify: t,
    unwatched: n
}) {
    return {
        link: r,
        unlink: i,
        propagate: a,
        checkDirty: o,
        shallowPropagate: s
    };

    function r(e, t, n) {
        let r = t.depsTail;
        if (r !== void 0 && r.dep === e) return;
        let i = r === void 0 ? t.deps : r.nextDep;
        if (i !== void 0 && i.dep === e) {
            i.version = n, t.depsTail = i;
            return
        }
        let a = e.subsTail;
        if (a !== void 0 && a.version === n && a.sub === t) return;
        let o = t.depsTail = e.subsTail = {
            version: n,
            dep: e,
            sub: t,
            prevDep: r,
            nextDep: i,
            prevSub: a,
            nextSub: void 0
        };
        i !== void 0 && (i.prevDep = o), r === void 0 ? t.deps = o : r.nextDep = o, a === void 0 ? e.subs = o : a.nextSub = o
    }

    function i(e, t = e.sub) {
        let r = e.dep,
            i = e.prevDep,
            a = e.nextDep,
            o = e.nextSub,
            s = e.prevSub;
        return a === void 0 ? t.depsTail = i : a.prevDep = i, i === void 0 ? t.deps = a : i.nextDep = a, o === void 0 ? r.subsTail = s : o.prevSub = s, s === void 0 ? (r.subs = o) === void 0 && n(r) : s.nextSub = o, a
    }

    function a(e) {
        let n = e.nextSub,
            r;
        top: do {
            let i = e.sub,
                a = i.flags;
            if (a & 60 ? a & 12 ? a & 4 ? !(a & 48) && c(e, i) ? (i.flags = a | 40, a &= 1) : a = 0 : i.flags = a & -9 | 32 : a = 0 : i.flags = a | 32, a & 2 && t(i), a & 1) {
                let t = i.subs;
                if (t !== void 0) {
                    let i = (e = t).nextSub;
                    i !== void 0 && (r = {
                        value: n,
                        prev: r
                    }, n = i);
                    continue
                }
            }
            if ((e = n) !== void 0) {
                n = e.nextSub;
                continue
            }
            for (; r !== void 0;)
                if (e = r.value, r = r.prev, e !== void 0) {
                    n = e.nextSub;
                    continue top
                }
            break
        } while (!0)
    }

    function o(t, n) {
        let r, i = 0,
            a = !1;
        top: do {
            let o = t.dep,
                c = o.flags;
            if (n.flags & 16) a = !0;
            else if ((c & 17) == 17) {
                if (e(o)) {
                    let e = o.subs;
                    e.nextSub !== void 0 && s(e), a = !0
                }
            } else if ((c & 33) == 33) {
                (t.nextSub !== void 0 || t.prevSub !== void 0) && (r = {
                    value: t,
                    prev: r
                }), t = o.deps, n = o, ++i;
                continue
            }
            if (!a) {
                let e = t.nextDep;
                if (e !== void 0) {
                    t = e;
                    continue
                }
            }
            for (; i--;) {
                let i = n.subs,
                    o = i.nextSub !== void 0;
                if (o ? (t = r.value, r = r.prev) : t = i, a) {
                    if (e(n)) {
                        o && s(i), n = t.sub;
                        continue
                    }
                    a = !1
                } else n.flags &= -33;
                n = t.sub;
                let c = t.nextDep;
                if (c !== void 0) {
                    t = c;
                    continue top
                }
            }
            return a
        } while (!0)
    }

    function s(e) {
        do {
            let n = e.sub,
                r = n.flags;
            (r & 48) == 32 && (n.flags = r | 16, (r & 6) == 2 && t(n))
        } while ((e = e.nextSub) !== void 0)
    }

    function c(e, t) {
        let n = t.depsTail;
        for (; n !== void 0;) {
            if (n === e) return !0;
            n = n.prevDep
        }
        return !1
    }
}

function js(e, t, n) {
    let r = typeof e == `object`,
        i = r ? e : void 0;
    return {
        next: (r ? e.next : e) ? .bind(i),
        error: (r ? e.error : t) ? .bind(i),
        complete: (r ? e.complete : n) ? .bind(i)
    }
}
var Ms = [],
    Ns = 0,
    {
        link: Ps,
        unlink: Fs,
        propagate: Is,
        checkDirty: Ls,
        shallowPropagate: Rs
    } = As({
        update(e) {
            return e._update()
        },
        notify(e) {
            Ms[Bs++] = e, e.flags &= ~V.Watching
        },
        unwatched(e) {
            e.depsTail !== void 0 && (e.depsTail = void 0, e.flags = V.Mutable | V.Dirty, Ws(e))
        }
    }),
    zs = 0,
    Bs = 0,
    Vs, Hs = 0;

function Us(e) {
    try {
        ++Hs, e()
    } finally {
        --Hs || Gs()
    }
}

function Ws(e) {
    let t = e.depsTail,
        n = t === void 0 ? e.deps : t.nextDep;
    for (; n !== void 0;) n = Fs(n, e)
}

function Gs() {
    if (!(Hs > 0)) {
        for (; zs < Bs;) {
            let e = Ms[zs];
            Ms[zs++] = void 0, e.notify()
        }
        zs = 0, Bs = 0
    }
}

function Ks(e, t) {
    let n = typeof e == `function`,
        r = e,
        i = {
            _snapshot: n ? void 0 : e,
            subs: void 0,
            subsTail: void 0,
            deps: void 0,
            depsTail: void 0,
            flags: n ? V.None : V.Mutable,
            get() {
                return Vs !== void 0 && Ps(i, Vs, Ns), i._snapshot
            },
            subscribe(e) {
                let t = js(e),
                    n = {
                        current: !1
                    },
                    r = qs(() => {
                        i.get(), n.current ? t.next ? .(i._snapshot) : n.current = !0
                    });
                return {
                    unsubscribe: () => {
                        r.stop()
                    }
                }
            },
            _update(e) {
                let a = Vs,
                    o = t ? .compare ? ? Object.is;
                if (n) Vs = i, ++Ns, i.depsTail = void 0;
                else if (e === void 0) return !1;
                n && (i.flags = V.Mutable | V.RecursedCheck);
                try {
                    let t = i._snapshot,
                        a = typeof e == `function` ? e(t) : e === void 0 && n ? r(t) : e;
                    return t === void 0 || !o(t, a) ? (i._snapshot = a, !0) : !1
                } finally {
                    Vs = a, n && (i.flags &= ~V.RecursedCheck), Ws(i)
                }
            }
        };
    return n ? (i.flags = V.Mutable | V.Dirty, i.get = function() {
        let e = i.flags;
        if (e & V.Dirty || e & V.Pending && Ls(i.deps, i)) {
            if (i._update()) {
                let e = i.subs;
                e !== void 0 && Rs(e)
            }
        } else e & V.Pending && (i.flags = e & ~V.Pending);
        return Vs !== void 0 && Ps(i, Vs, Ns), i._snapshot
    }) : i.set = function(e) {
        if (i._update(e)) {
            let e = i.subs;
            e !== void 0 && (Is(e), Rs(e), Gs())
        }
    }, i
}

function qs(e) {
    let t = () => {
            let t = Vs;
            Vs = n, ++Ns, n.depsTail = void 0, n.flags = V.Watching | V.RecursedCheck;
            try {
                return e()
            } finally {
                Vs = t, n.flags &= ~V.RecursedCheck, Ws(n)
            }
        },
        n = {
            deps: void 0,
            depsTail: void 0,
            subs: void 0,
            subsTail: void 0,
            flags: V.Watching | V.RecursedCheck,
            notify() {
                let e = this.flags;
                e & V.Dirty || e & V.Pending && Ls(this.deps, this) ? t() : this.flags = V.Watching
            },
            stop() {
                this.flags = V.None, this.depsTail = void 0, Ws(this)
            }
        };
    return t(), n
}
var Js = o((e => {
        var t = u();

        function n(e, t) {
            return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t
        }
        var r = typeof Object.is == `function` ? Object.is : n,
            i = t.useState,
            a = t.useEffect,
            o = t.useLayoutEffect,
            s = t.useDebugValue;

        function c(e, t) {
            var n = t(),
                r = i({
                    inst: {
                        value: n,
                        getSnapshot: t
                    }
                }),
                c = r[0].inst,
                u = r[1];
            return o(function() {
                c.value = n, c.getSnapshot = t, l(c) && u({
                    inst: c
                })
            }, [e, n, t]), a(function() {
                return l(c) && u({
                    inst: c
                }), e(function() {
                    l(c) && u({
                        inst: c
                    })
                })
            }, [e]), s(n), n
        }

        function l(e) {
            var t = e.getSnapshot;
            e = e.value;
            try {
                var n = t();
                return !r(e, n)
            } catch {
                return !0
            }
        }

        function d(e, t) {
            return t()
        }
        var f = typeof window > `u` || window.document === void 0 || window.document.createElement === void 0 ? d : c;
        e.useSyncExternalStore = t.useSyncExternalStore === void 0 ? f : t.useSyncExternalStore
    })),
    Ys = o(((e, t) => {
        t.exports = Js()
    })),
    Xs = o((e => {
        var t = u(),
            n = Ys();

        function r(e, t) {
            return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t
        }
        var i = typeof Object.is == `function` ? Object.is : r,
            a = n.useSyncExternalStore,
            o = t.useRef,
            s = t.useEffect,
            c = t.useMemo,
            l = t.useDebugValue;
        e.useSyncExternalStoreWithSelector = function(e, t, n, r, u) {
            var d = o(null);
            if (d.current === null) {
                var f = {
                    hasValue: !1,
                    value: null
                };
                d.current = f
            } else f = d.current;
            d = c(function() {
                function e(e) {
                    if (!a) {
                        if (a = !0, o = e, e = r(e), u !== void 0 && f.hasValue) {
                            var t = f.value;
                            if (u(t, e)) return s = t
                        }
                        return s = e
                    }
                    if (t = s, i(o, e)) return t;
                    var n = r(e);
                    return u !== void 0 && u(t, n) ? (o = e, t) : (o = e, s = n)
                }
                var a = !1,
                    o, s, c = n === void 0 ? null : n;
                return [function() {
                    return e(t())
                }, c === null ? void 0 : function() {
                    return e(c())
                }]
            }, [t, n, r, u]);
            var p = a(e, d[0], d[1]);
            return s(function() {
                f.hasValue = !0, f.value = p
            }, [p]), l(p), p
        }
    })),
    Zs = o(((e, t) => {
        t.exports = Xs()
    }))();

function Qs(e, t) {
    return e === t
}

function H(e, t, n = Qs) {
    let r = (0, z.useCallback)(t => {
            if (!e) return () => {};
            let {
                unsubscribe: n
            } = e.subscribe(t);
            return n
        }, [e]),
        i = (0, z.useCallback)(() => e ? .get(), [e]);
    return (0, Zs.useSyncExternalStoreWithSelector)(r, i, i, t, n)
}
var $s = {
    get() {},
    subscribe() {
        return {
            unsubscribe() {}
        }
    }
};

function ec(e, t) {
    let n = z.useRef();
    return r => {
        let i = e ? .select ? e.select(r) : r;
        return e ? .structuralSharing ? ? t.options.defaultStructuralSharing ? n.current = le(n.current, i) : i
    }
}

function tc(e) {
    let t = Ds(),
        n = z.useContext(e.from ? ks : Os),
        r = e.from ? t.stores.getRouteMatchStore(e.from) : t.stores.matchStores.get(n),
        i = ec(e, t),
        a = H(r ? ? $s, e => e ? i(e) : $s);
    if (a !== $s) return a;
    (e.shouldThrow ? ? !0) && we()
}

function nc(e) {
    return tc({
        from: e.from,
        strict: e.strict,
        structuralSharing: e.structuralSharing,
        select: t => e.select ? e.select(t.loaderData) : t.loaderData
    })
}

function rc(e) {
    let {
        select: t,
        ...n
    } = e;
    return tc({ ...n,
        select: e => t ? t(e.loaderDeps) : e.loaderDeps
    })
}

function ic(e) {
    return tc({
        from: e.from,
        shouldThrow: e.shouldThrow,
        structuralSharing: e.structuralSharing,
        strict: e.strict,
        select: t => {
            let n = e.strict === !1 ? t.params : t._strictParams;
            return e.select ? e.select(n) : n
        }
    })
}

function ac(e) {
    return tc({
        from: e.from,
        strict: e.strict,
        shouldThrow: e.shouldThrow,
        structuralSharing: e.structuralSharing,
        select: t => e.select ? e.select(t.search) : t.search
    })
}

function oc(e) {
    let t = Ds();
    return z.useCallback(n => t.navigate({ ...n,
        from: n.from ? ? e ? .from
    }), [e ? .from, t])
}

function sc(e) {
    return tc({ ...e,
        select: t => e.select ? e.select(t.context) : t.context
    })
}
var cc = m();

function lc(e, t) {
    let n = Ds(),
        r = ms(t),
        {
            activeProps: i,
            inactiveProps: a,
            activeOptions: o,
            to: s,
            preload: c,
            preloadDelay: l,
            preloadIntentProximity: u,
            hashScrollIntoView: d,
            replace: f,
            startTransition: p,
            resetScroll: m,
            viewTransition: h,
            children: g,
            target: _,
            disabled: v,
            style: y,
            className: b,
            onClick: x,
            onBlur: ee,
            onFocus: S,
            onMouseEnter: C,
            onMouseLeave: te,
            onTouchStart: ne,
            ignoreBlocker: ie,
            params: ae,
            search: oe,
            hash: se,
            state: ce,
            mask: le,
            reloadDocument: ue,
            unsafeRelative: de,
            from: w,
            _fromLocation: E,
            ...pe
        } = e,
        me = ws(),
        he = z.useMemo(() => e, [n, e.from, e._fromLocation, e.hash, e.to, e.search, e.params, e.state, e.mask, e.unsafeRelative]),
        D = H(n.stores.location, e => e, (e, t) => e.href === t.href),
        O = z.useMemo(() => {
            let e = {
                _fromLocation: D,
                ...he
            };
            return n.buildLocation(e)
        }, [n, D, he]),
        ge = O.maskedLocation ? O.maskedLocation.publicHref : O.publicHref,
        ve = O.maskedLocation ? O.maskedLocation.external : O.external,
        ye = z.useMemo(() => vc(ge, ve, n.history, v), [v, ve, ge, n.history]),
        be = z.useMemo(() => {
            if (ye ? .external) return _e(ye.href, n.protocolAllowlist) ? void 0 : ye.href;
            if (!yc(s) && !(typeof s != `string` || s.indexOf(`:`) === -1)) try {
                return new URL(s), _e(s, n.protocolAllowlist) ? void 0 : s
            } catch {}
        }, [s, ye, n.protocolAllowlist]),
        xe = z.useMemo(() => {
            if (be) return !1;
            if (o ? .exact) {
                if (!nt(D.pathname, O.pathname, n.basepath)) return !1
            } else {
                let e = tt(D.pathname, n.basepath),
                    t = tt(O.pathname, n.basepath);
                if (!(e.startsWith(t) && (e.length === t.length || e[t.length] === `/`))) return !1
            }
            return (o ? .includeSearch ? ? !0) && !fe(D.search, O.search, {
                partial: !o ? .exact,
                ignoreUndefined: !o ? .explicitUndefined
            }) ? !1 : o ? .includeHash ? me && D.hash === O.hash : !0
        }, [o ? .exact, o ? .explicitUndefined, o ? .includeHash, o ? .includeSearch, D, be, me, O.hash, O.pathname, O.search, n.basepath]),
        Se = xe ? re(i, {}) ? ? dc : uc,
        Ce = xe ? uc : re(a, {}) ? ? uc,
        we = [b, Se.className, Ce.className].filter(Boolean).join(` `),
        Te = (y || Se.style || Ce.style) && { ...y,
            ...Se.style,
            ...Ce.style
        },
        [Ee, De] = z.useState(!1),
        Oe = z.useRef(!1),
        ke = e.reloadDocument || be ? !1 : c ? ? n.options.defaultPreload,
        Ae = l ? ? n.options.defaultPreloadDelay ? ? 0,
        je = z.useCallback(() => {
            n.preloadRoute({ ...he,
                _builtLocation: O
            }).catch(e => {
                console.warn(e), console.warn(Nn)
            })
        }, [n, he, O]);
    ps(r, z.useCallback(e => {
        e ? .isIntersecting && je()
    }, [je]), gc, {
        disabled: !!v || ke !== `viewport`
    }), z.useEffect(() => {
        Oe.current || !v && ke === `render` && (je(), Oe.current = !0)
    }, [v, je, ke]);
    let Me = e => {
        let t = e.currentTarget.getAttribute(`target`),
            r = _ === void 0 ? t : _;
        if (!v && !xc(e) && !e.defaultPrevented && (!r || r === `_self`) && e.button === 0) {
            e.preventDefault(), (0, cc.flushSync)(() => {
                De(!0)
            });
            let t = n.subscribe(`onResolved`, () => {
                t(), De(!1)
            });
            n.navigate({ ...he,
                replace: f,
                resetScroll: m,
                hashScrollIntoView: d,
                startTransition: p,
                viewTransition: h,
                ignoreBlocker: ie
            })
        }
    };
    if (be) return { ...pe,
        ref: r,
        href: be,
        ...g && {
            children: g
        },
        ..._ && {
            target: _
        },
        ...v && {
            disabled: v
        },
        ...y && {
            style: y
        },
        ...b && {
            className: b
        },
        ...x && {
            onClick: x
        },
        ...ee && {
            onBlur: ee
        },
        ...S && {
            onFocus: S
        },
        ...C && {
            onMouseEnter: C
        },
        ...te && {
            onMouseLeave: te
        },
        ...ne && {
            onTouchStart: ne
        }
    };
    let Ne = e => {
            if (v || ke !== `intent`) return;
            if (!Ae) {
                je();
                return
            }
            let t = e.currentTarget;
            if (hc.has(t)) return;
            let n = setTimeout(() => {
                hc.delete(t), je()
            }, Ae);
            hc.set(t, n)
        },
        Pe = e => {
            v || ke !== `intent` || je()
        },
        Fe = e => {
            if (v || !ke || !Ae) return;
            let t = e.currentTarget,
                n = hc.get(t);
            n && (clearTimeout(n), hc.delete(t))
        };
    return { ...pe,
        ...Se,
        ...Ce,
        href: ye ? .href,
        ref: r,
        onClick: _c([x, Me]),
        onBlur: _c([ee, Fe]),
        onFocus: _c([S, Ne]),
        onMouseEnter: _c([C, Ne]),
        onMouseLeave: _c([te, Fe]),
        onTouchStart: _c([ne, Pe]),
        disabled: !!v,
        target: _,
        ...Te && {
            style: Te
        },
        ...we && {
            className: we
        },
        ...v && fc,
        ...xe && pc,
        ...me && Ee && mc
    }
}
var uc = {},
    dc = {
        className: `active`
    },
    fc = {
        role: `link`,
        "aria-disabled": !0
    },
    pc = {
        "data-status": `active`,
        "aria-current": `page`
    },
    mc = {
        "data-transitioning": `transitioning`
    },
    hc = new WeakMap,
    gc = {
        rootMargin: `100px`
    },
    _c = e => t => {
        for (let n of e)
            if (n) {
                if (t.defaultPrevented) return;
                n(t)
            }
    };

function vc(e, t, n, r) {
    if (!r) return t ? {
        href: e,
        external: !0
    } : {
        href: n.createHref(e) || `/`,
        external: !1
    }
}

function yc(e) {
    if (typeof e != `string`) return !1;
    let t = e.charCodeAt(0);
    return t === 47 ? e.charCodeAt(1) !== 47 : t === 46
}
var bc = z.forwardRef((e, t) => {
    let {
        _asChild: n,
        ...r
    } = e, {
        type: i,
        ...a
    } = lc(r, t), o = typeof r.children == `function` ? r.children({
        isActive: a[`data-status`] === `active`
    }) : r.children;
    if (!n) {
        let {
            disabled: e,
            ...t
        } = a;
        return z.createElement(`a`, t, o)
    }
    return z.createElement(n, a, o)
});

function xc(e) {
    return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey)
}
var Sc = class extends Bn {
    constructor(e) {
        super(e), this.useMatch = e => tc({
            select: e ? .select,
            from: this.id,
            structuralSharing: e ? .structuralSharing
        }), this.useRouteContext = e => sc({ ...e,
            from: this.id
        }), this.useSearch = e => ac({
            select: e ? .select,
            structuralSharing: e ? .structuralSharing,
            from: this.id
        }), this.useParams = e => ic({
            select: e ? .select,
            structuralSharing: e ? .structuralSharing,
            from: this.id
        }), this.useLoaderDeps = e => rc({ ...e,
            from: this.id
        }), this.useLoaderData = e => nc({ ...e,
            from: this.id
        }), this.useNavigate = () => oc({
            from: this.fullPath
        }), this.Link = z.forwardRef((e, t) => (0, B.jsx)(bc, {
            ref: t,
            from: this.fullPath,
            ...e
        }))
    }
};

function Cc(e) {
    return new Sc(e)
}

function wc() {
    return e => Ec(e)
}
var Tc = class extends Vn {
    constructor(e) {
        super(e), this.useMatch = e => tc({
            select: e ? .select,
            from: this.id,
            structuralSharing: e ? .structuralSharing
        }), this.useRouteContext = e => sc({ ...e,
            from: this.id
        }), this.useSearch = e => ac({
            select: e ? .select,
            structuralSharing: e ? .structuralSharing,
            from: this.id
        }), this.useParams = e => ic({
            select: e ? .select,
            structuralSharing: e ? .structuralSharing,
            from: this.id
        }), this.useLoaderDeps = e => rc({ ...e,
            from: this.id
        }), this.useLoaderData = e => nc({ ...e,
            from: this.id
        }), this.useNavigate = () => oc({
            from: this.fullPath
        }), this.Link = z.forwardRef((e, t) => (0, B.jsx)(bc, {
            ref: t,
            from: this.fullPath,
            ...e
        }))
    }
};

function Ec(e) {
    return new Tc(e)
}

function Dc(e) {
    return new Oc(e, {
        silent: !0
    }).createRoute
}
var Oc = class {
    constructor(e, t) {
        this.path = e, this.createRoute = e => {
            let t = Cc(e);
            return t.isRoot = !1, t
        }, this.silent = t ? .silent
    }
};

function kc(e, t) {
    let n, r, i, a, o = () => (n || = e().then(e => {
            n = void 0, r = e[t ? ? `default`]
        }).catch(e => {
            if (i = e, me(i) && i instanceof Error && typeof window < `u` && typeof sessionStorage < `u`) {
                let e = `tanstack_router_reload:${i.message}`;
                sessionStorage.getItem(e) || (sessionStorage.setItem(e, `1`), a = !0)
            }
        }), n),
        s = function(e) {
            if (a) throw window.location.reload(), new Promise(() => {});
            if (i) throw i;
            if (!r)
                if (us) us(o());
                else throw o();
            return z.createElement(r, e)
        };
    return s.preload = o, s
}

function Ac(e) {
    let t = Ds(),
        n = `not-found-${H(t.stores.location,e=>e.pathname)}-${H(t.stores.status,e=>e)}`;
    return (0, B.jsx)(bs, {
        getResetKey: () => n,
        onCatch: (t, n) => {
            if (ct(t)) e.onCatch ? .(t, n);
            else throw t
        },
        errorComponent: ({
            error: t
        }) => {
            if (ct(t)) return e.fallback ? .(t);
            throw t
        },
        children: e.children
    })
}

function jc() {
    return (0, B.jsx)(`p`, {
        children: `Not Found`
    })
}

function Mc(e) {
    return (0, B.jsx)(B.Fragment, {
        children: e.children
    })
}

function Nc(e, t, n) {
    return t.options.notFoundComponent ? (0, B.jsx)(t.options.notFoundComponent, { ...n
    }) : e.options.defaultNotFoundComponent ? (0, B.jsx)(e.options.defaultNotFoundComponent, { ...n
    }) : (0, B.jsx)(jc, {})
}
var Pc = (e, t) => e.routeId === t.routeId && e._displayPending === t._displayPending,
    Fc = (e, t) => e[0] === t[0] && e[1] === t[1],
    Ic = z.memo(function({
        matchId: e
    }) {
        let t = Ds(),
            n = t.stores.matchStores.get(e);
        n || we();
        let r = H(t.stores.loadedAt, e => e),
            i = H(n, e => e, Pc);
        return (0, B.jsx)(Lc, {
            router: t,
            matchId: e,
            resetKey: r,
            matchState: z.useMemo(() => {
                let e = i.routeId,
                    n = t.routesById[e].parentRoute ? .id;
                return {
                    routeId: e,
                    ssr: i.ssr,
                    _displayPending: i._displayPending,
                    parentRouteId: n
                }
            }, [i._displayPending, i.routeId, i.ssr, t.routesById])
        })
    });

function Lc({
    router: e,
    matchId: t,
    resetKey: n,
    matchState: r
}) {
    let i = e.routesById[r.routeId],
        a = i.options.pendingComponent ? ? e.options.defaultPendingComponent,
        o = a ? (0, B.jsx)(a, {}) : null,
        s = i.options.errorComponent ? ? e.options.defaultErrorComponent,
        c = i.options.onCatch ? ? e.options.defaultOnCatch,
        l = i.isRoot ? i.options.notFoundComponent ? ? e.options.notFoundRoute ? .options.component : i.options.notFoundComponent,
        u = r.ssr === !1 || r.ssr === `data-only`,
        d = (!i.isRoot || i.options.wrapInSuspense || u) && (i.options.wrapInSuspense ? ? a ? ? (i.options.errorComponent ? .preload || u)) ? z.Suspense : Mc,
        f = s ? bs : Mc,
        p = l ? Ac : Mc;
    return (0, B.jsxs)(i.isRoot ? i.options.shellComponent ? ? Mc : Mc, {
        children: [(0, B.jsx)(Os.Provider, {
            value: t,
            children: (0, B.jsx)(d, {
                fallback: o,
                children: (0, B.jsx)(f, {
                    getResetKey: () => n,
                    errorComponent: s || Ss,
                    onCatch: (e, t) => {
                        if (ct(e)) throw e.routeId ? ? = r.routeId, e;
                        c ? .(e, t)
                    },
                    children: (0, B.jsx)(p, {
                        fallback: e => {
                            if (e.routeId ? ? = r.routeId, !l || e.routeId && e.routeId !== r.routeId || !e.routeId && !i.isRoot) throw e;
                            return z.createElement(l, e)
                        },
                        children: u || r._displayPending ? (0, B.jsx)(Cs, {
                            fallback: o,
                            children: (0, B.jsx)(zc, {
                                matchId: t
                            })
                        }) : (0, B.jsx)(zc, {
                            matchId: t
                        })
                    })
                })
            })
        }), r.parentRouteId === `__root__` ? (0, B.jsxs)(B.Fragment, {
            children: [(0, B.jsx)(Rc, {}), (e.options.scrollRestoration, null)]
        }) : null]
    })
}

function Rc() {
    let e = Ds(),
        t = z.useRef();
    return ds(() => {
        let n = e.stores.resolvedLocation.get(),
            r = t.current;
        n && (!r || r.href !== n.href) && e.emit({
            type: `onRendered`,
            ...an(e.stores.location.get(), r ? ? n)
        }), t.current = n
    }, [H(e.stores.resolvedLocation, e => e ? .state.__TSR_key), e]), null
}
var zc = z.memo(function({
        matchId: e
    }) {
        let t = Ds(),
            n = (e, n) => t.getMatch(e.id) ? ._nonReactive[n] ? ? e._nonReactive[n],
            r = t.stores.matchStores.get(e);
        r || we();
        let i = H(r, e => e),
            a = i.routeId,
            o = t.routesById[a],
            s = z.useMemo(() => {
                let e = (t.routesById[a].options.remountDeps ? ? t.options.defaultRemountDeps) ? .({
                    routeId: a,
                    loaderDeps: i.loaderDeps,
                    params: i._strictParams,
                    search: i._strictSearch
                });
                return e ? JSON.stringify(e) : void 0
            }, [a, i.loaderDeps, i._strictParams, i._strictSearch, t.options.defaultRemountDeps, t.routesById]),
            c = z.useMemo(() => {
                let e = o.options.component ? ? t.options.defaultComponent;
                return e ? (0, B.jsx)(e, {}, s) : (0, B.jsx)(U, {})
            }, [s, o.options.component, t.options.defaultComponent]);
        if (i._displayPending) throw n(i, `displayPendingPromise`);
        if (i._forcePending) throw n(i, `minPendingPromise`);
        if (i.status === `pending`) {
            let e = o.options.pendingMinMs ? ? t.options.defaultPendingMinMs;
            if (e) {
                let n = t.getMatch(i.id);
                if (n && !n._nonReactive.minPendingPromise) {
                    let t = pe();
                    n._nonReactive.minPendingPromise = t, setTimeout(() => {
                        t.resolve(), n._nonReactive.minPendingPromise = void 0
                    }, e)
                }
            }
            throw n(i, `loadPromise`)
        }
        if (i.status === `notFound`) return ct(i.error) || we(), Nc(t, o, i.error);
        if (i.status === `redirected`) throw k(i.error) || we(), n(i, `loadPromise`);
        if (i.status === `error`) throw i.error;
        return c
    }),
    U = z.memo(function() {
        let e = Ds(),
            t = z.useContext(Os),
            n, r = !1,
            i; {
            let a = t ? e.stores.matchStores.get(t) : void 0;
            [n, r] = H(a, e => [e ? .routeId, e ? .globalNotFound ? ? !1], Fc), i = H(e.stores.matchesId, e => e[e.findIndex(e => e === t) + 1])
        }
        let a = n ? e.routesById[n] : void 0,
            o = e.options.defaultPendingComponent ? (0, B.jsx)(e.options.defaultPendingComponent, {}) : null;
        if (r) return a || we(), Nc(e, a, void 0);
        if (!i) return null;
        let s = (0, B.jsx)(Ic, {
            matchId: i
        });
        return n === `__root__` ? (0, B.jsx)(z.Suspense, {
            fallback: o,
            children: s
        }) : s
    });

function Bc() {
    let e = Ds(),
        t = z.useRef({
            router: e,
            mounted: !1
        }),
        [n, r] = z.useState(!1),
        i = H(e.stores.isLoading, e => e),
        a = H(e.stores.hasPending, e => e),
        o = fs(i),
        s = i || n || a,
        c = fs(s),
        l = i || a,
        u = fs(l);
    return e.startTransition = e => {
        r(!0), z.startTransition(() => {
            e(), r(!1)
        })
    }, z.useEffect(() => {
        let t = e.history.subscribe(e.load),
            n = e.buildLocation({
                to: e.latestLocation.pathname,
                search: !0,
                params: !0,
                hash: !0,
                state: !0,
                _includeValidateSearch: !0
            });
        return $e(e.latestLocation.publicHref) !== $e(n.publicHref) && e.commitLocation({ ...n,
            replace: !0
        }), () => {
            t()
        }
    }, [e, e.history]), ds(() => {
        typeof window < `u` && e.ssr || t.current.router === e && t.current.mounted || (t.current = {
            router: e,
            mounted: !0
        }, (async () => {
            try {
                await e.load()
            } catch (e) {
                console.error(e)
            }
        })())
    }, [e]), ds(() => {
        o && !i && e.emit({
            type: `onLoad`,
            ...an(e.stores.location.get(), e.stores.resolvedLocation.get())
        })
    }, [o, e, i]), ds(() => {
        u && !l && e.emit({
            type: `onBeforeRouteMount`,
            ...an(e.stores.location.get(), e.stores.resolvedLocation.get())
        })
    }, [l, u, e]), ds(() => {
        if (c && !s) {
            let t = an(e.stores.location.get(), e.stores.resolvedLocation.get());
            e.emit({
                type: `onResolved`,
                ...t
            }), Us(() => {
                e.stores.status.set(`idle`), e.stores.resolvedLocation.set(e.stores.location.get())
            })
        }
    }, [s, c, e]), null
}

function Vc() {
    let e = Ds(),
        t = e.routesById.__root__.options.pendingComponent ? ? e.options.defaultPendingComponent,
        n = t ? (0, B.jsx)(t, {}) : null,
        r = (0, B.jsxs)(typeof document < `u` && e.ssr ? Mc : z.Suspense, {
            fallback: n,
            children: [(0, B.jsx)(Bc, {}), (0, B.jsx)(Hc, {})]
        });
    return e.options.InnerWrap ? (0, B.jsx)(e.options.InnerWrap, {
        children: r
    }) : r
}

function Hc() {
    let e = Ds(),
        t = H(e.stores.firstId, e => e),
        n = H(e.stores.loadedAt, e => e),
        r = t ? (0, B.jsx)(Ic, {
            matchId: t
        }) : null;
    return (0, B.jsx)(Os.Provider, {
        value: t,
        children: e.options.disableGlobalCatchBoundary ? r : (0, B.jsx)(bs, {
            getResetKey: () => n,
            errorComponent: Ss,
            onCatch: void 0,
            children: r
        })
    })
}
var Uc = e => ({
        createMutableStore: Ks,
        createReadonlyStore: Ks,
        batch: Us
    }),
    Wc = e => new Gc(e),
    Gc = class extends sn {
        constructor(e) {
            super(e, Uc)
        }
    };

function Kc({
    router: e,
    children: t,
    ...n
}) {
    oe(n) && e.update({ ...e.options,
        ...n,
        context: { ...e.options.context,
            ...n.context
        }
    });
    let r = (0, B.jsx)(Es.Provider, {
        value: e,
        children: t
    });
    return e.options.Wrap ? (0, B.jsx)(e.options.Wrap, {
        children: r
    }) : r
}

function qc({
    router: e,
    ...t
}) {
    return (0, B.jsx)(Kc, {
        router: e,
        ...t,
        children: (0, B.jsx)(Vc, {})
    })
}

function Jc(e, t) {
    if (t)
        for (let [n, r] of Object.entries(t)) n !== `suppressHydrationWarning` && r !== void 0 && r !== !1 && e.setAttribute(n, typeof r == `boolean` ? `` : String(r))
}

function Yc(e) {
    let {
        attrs: t,
        children: n,
        nonce: r,
        preventScriptHoist: i
    } = e;
    switch (e.tag) {
        case `title`:
            return (0, B.jsx)(`title`, { ...t,
                suppressHydrationWarning: !0,
                children: n
            });
        case `meta`:
            return (0, B.jsx)(`meta`, { ...t,
                suppressHydrationWarning: !0
            });
        case `link`:
            return (0, B.jsx)(`link`, { ...t,
                precedence: t ? .precedence ? ? (t ? .rel === `stylesheet` ? `default` : void 0),
                nonce: r,
                suppressHydrationWarning: !0
            });
        case `style`:
            return e.inlineCss, (0, B.jsx)(`style`, { ...t,
                dangerouslySetInnerHTML: {
                    __html: n
                },
                nonce: r
            });
        case `script`:
            return (0, B.jsx)(Xc, {
                attrs: t,
                preventScriptHoist: i,
                children: n
            });
        default:
            return null
    }
}

function Xc({
    attrs: e,
    children: t,
    preventScriptHoist: n
}) {
    Ds();
    let r = ws(),
        i = typeof e ? .type == `string` && e.type !== `` && e.type !== `text/javascript` && e.type !== `module`;
    if (z.useEffect(() => {
            if (!i) {
                if (e ? .src) {
                    let t = (() => {
                        try {
                            let t = document.baseURI || window.location.href;
                            return new URL(e.src, t).href
                        } catch {
                            return e.src
                        }
                    })();
                    for (let e of document.querySelectorAll(`script[src]`))
                        if (e.src === t) return;
                    let n = document.createElement(`script`);
                    return Jc(n, e), document.head.appendChild(n), () => n.remove()
                }
                if (typeof t == `string`) {
                    let n = typeof e ? .type == `string` ? e.type : `text/javascript`,
                        r = typeof e ? .nonce == `string` ? e.nonce : void 0;
                    for (let e of document.querySelectorAll(`script:not([src])`)) {
                        if (!(e instanceof HTMLScriptElement)) continue;
                        let i = e.getAttribute(`type`) ? ? `text/javascript`,
                            a = e.getAttribute(`nonce`) ? ? void 0;
                        if (e.textContent === t && i === n && a === r) return
                    }
                    let i = document.createElement(`script`);
                    return i.textContent = t, Jc(i, e), document.head.appendChild(i), () => i.remove()
                }
            }
        }, [e, t, i]), i && typeof t == `string`) return (0, B.jsx)(`script`, { ...e,
        suppressHydrationWarning: !0,
        dangerouslySetInnerHTML: {
            __html: t
        }
    });
    if (!r) {
        if (e ? .src) return (0, B.jsx)(`script`, { ...e,
            suppressHydrationWarning: !0
        });
        if (typeof t == `string`) return (0, B.jsx)(`script`, { ...e,
            dangerouslySetInnerHTML: {
                __html: t
            },
            suppressHydrationWarning: !0
        })
    }
    return null
}
var Zc = e => {
    let t = Ds(),
        n = t.options.ssr ? .nonce,
        r = H(t.stores.matches, e => e.map(e => e.meta).filter(e => e !== void 0), fe),
        i = z.useMemo(() => {
            let e = [],
                t = {},
                i;
            for (let a = r.length - 1; a >= 0; a--) {
                let o = r[a];
                for (let r = o.length - 1; r >= 0; r--) {
                    let a = o[r];
                    if (a)
                        if (a.title) i || = {
                            tag: `title`,
                            children: a.title
                        };
                        else if (`script:ld+json` in a) try {
                        let t = JSON.stringify(a[`script:ld+json`]);
                        e.push({
                            tag: `script`,
                            attrs: {
                                type: `application/ld+json`
                            },
                            children: be(t)
                        })
                    } catch {} else {
                        let r = a.name ? ? a.property;
                        if (r) {
                            if (t[r]) continue;
                            t[r] = !0
                        }
                        e.push({
                            tag: `meta`,
                            attrs: { ...a,
                                nonce: n
                            }
                        })
                    }
                }
            }
            return i && e.push(i), n && e.push({
                tag: `meta`,
                attrs: {
                    property: `csp-nonce`,
                    content: n
                }
            }), e.reverse(), e
        }, [r, n]),
        a = H(t.stores.matches, e => e.flatMap(e => e.links ? ? []).filter(e => e !== void 0).map(e => ({
            tag: `link`,
            attrs: { ...e,
                nonce: n
            }
        })), fe),
        o = H(t.stores.matches, r => {
            let i = t.ssr ? .manifest,
                a = [];
            return i ? (r.forEach(t => {
                i.routes[t.routeId] ? .css ? .forEach(t => {
                    let r = zn(t);
                    a.push({
                        tag: `link`,
                        attrs: {
                            rel: `stylesheet`,
                            ...r,
                            crossOrigin: Pn(e, `stylesheet`) ? ? r.crossOrigin,
                            suppressHydrationWarning: !0,
                            nonce: n
                        }
                    })
                })
            }), i.inlineStyle && a.push({
                tag: `style`,
                attrs: { ...i.inlineStyle.attrs,
                    nonce: n
                },
                children: i.inlineStyle.children,
                inlineCss: !0
            }), a) : a
        }, fe),
        s = H(t.stores.matches, r => {
            let i = [],
                a = t.ssr ? .manifest;
            return a && r.forEach(t => {
                a.routes[t.routeId] ? .preloads ? .forEach(t => {
                    i.push({
                        tag: `link`,
                        attrs: { ...In(a, t, e),
                            nonce: n
                        }
                    })
                })
            }), i
        }, fe),
        c = H(t.stores.matches, e => e.flatMap(e => e.styles ? ? []).filter(e => e !== void 0).map(({
            children: e,
            ...t
        }) => ({
            tag: `style`,
            attrs: { ...t,
                nonce: n
            },
            children: e
        })), fe),
        l = H(t.stores.matches, e => e.flatMap(e => e.headScripts ? ? []).filter(e => e !== void 0).map(({
            children: e,
            ...t
        }) => ({
            tag: `script`,
            attrs: { ...t,
                nonce: n
            },
            children: e
        })), fe),
        u = [];
    return Rn(u, i), u.push(...s), Rn(u, a), u.push(...o), Rn(u, c), Rn(u, l), u
};

function Qc(e) {
    let t = Zc(e.assetCrossOrigin),
        n = Ds().options.ssr ? .nonce;
    return (0, B.jsx)(B.Fragment, {
        children: t.map(e => (0, z.createElement)(Yc, { ...e,
            key: `tsr-meta-${JSON.stringify(e)}`,
            nonce: n
        }))
    })
}
var $c = () => {
    let e = Ds(),
        t = e.options.ssr ? .nonce,
        n = n => {
            let r = [],
                i = e.ssr ? .manifest;
            if (!i) return [];
            for (let e of n) {
                let n = i.routes[e.routeId] ? .scripts;
                if (n)
                    for (let e of n) r.push({
                        tag: `script`,
                        attrs: { ...e.attrs,
                            nonce: t
                        },
                        children: e.children,
                        ...typeof e.attrs ? .src == `string` ? {
                            preventScriptHoist: !0
                        } : {}
                    })
            }
            return r
        },
        r = e => e.map(e => e.scripts).flat(1).filter(Boolean).map(({
            children: e,
            ...n
        }) => ({
            tag: `script`,
            attrs: { ...n,
                suppressHydrationWarning: !0,
                nonce: t
            },
            children: e
        })),
        i = H(e.stores.matches, n, fe);
    return el(e, H(e.stores.matches, r, fe), i)
};

function el(e, t, n) {
    let r = [...t, ...n];
    return (0, B.jsx)(B.Fragment, {
        children: r.map((e, t) => (0, z.createElement)(Yc, { ...e,
            key: `tsr-scripts-${e.tag}-${t}`
        }))
    })
}
var tl = (e, t) => {
    let n = {
            type: `request`,
            ...t || e
        },
        r = e => tl({}, Object.assign(n, {
            validator: e,
            inputValidator: e
        }));
    return {
        options: n,
        middleware: e => tl({}, Object.assign(n, {
            middleware: e
        })),
        validator: r,
        inputValidator: r,
        client: e => tl({}, Object.assign(n, {
            client: e
        })),
        server: e => tl({}, Object.assign(n, {
            server: e
        }))
    }
};

function nl(e, t) {
    for (let n = 0, r = t.length; n < r; n++) {
        let r = t[n];
        e.has(r) || (e.add(r), r.extends && nl(e, r.extends))
    }
}
var rl = e => ({
        getOptions: async () => {
            let t = await e();
            if (t.serializationAdapters) {
                let e = new Set;
                nl(e, t.serializationAdapters), t.serializationAdapters = Array.from(e)
            }
            return t
        },
        createMiddleware: tl
    }),
    il = tl(),
    al = rl(() => ({
        requestMiddleware: [il]
    })),
    ol = class {
        constructor() {
            this.listeners = new Set, this.subscribe = this.subscribe.bind(this)
        }
        subscribe(e) {
            return this.listeners.add(e), this.onSubscribe(), () => {
                this.listeners.delete(e), this.onUnsubscribe()
            }
        }
        hasListeners() {
            return this.listeners.size > 0
        }
        onSubscribe() {}
        onUnsubscribe() {}
    },
    sl = new class extends ol {#
        e;#
        t;#
        n;
        constructor() {
            super(), this.#n = e => {
                if (typeof window < `u` && window.addEventListener) {
                    let t = () => e();
                    return window.addEventListener(`visibilitychange`, t, !1), () => {
                        window.removeEventListener(`visibilitychange`, t)
                    }
                }
            }
        }
        onSubscribe() {
            this.#t || this.setEventListener(this.#n)
        }
        onUnsubscribe() {
            this.hasListeners() || (this.#t ? .(), this.#t = void 0)
        }
        setEventListener(e) {
            this.#n = e, this.#t ? .(), this.#t = e(e => {
                typeof e == `boolean` ? this.setFocused(e) : this.onFocus()
            })
        }
        setFocused(e) {
            this.#e !== e && (this.#e = e, this.onFocus())
        }
        onFocus() {
            let e = this.isFocused();
            this.listeners.forEach(t => {
                t(e)
            })
        }
        isFocused() {
            return typeof this.#e == `boolean` ? this.#e : globalThis.document ? .visibilityState !== `hidden`
        }
    },
    cl = {
        setTimeout: (e, t) => setTimeout(e, t),
        clearTimeout: e => clearTimeout(e),
        setInterval: (e, t) => setInterval(e, t),
        clearInterval: e => clearInterval(e)
    },
    ll = new class {#
        e = cl;
        setTimeoutProvider(e) {
            this.#e = e
        }
        setTimeout(e, t) {
            return this.#e.setTimeout(e, t)
        }
        clearTimeout(e) {
            this.#e.clearTimeout(e)
        }
        setInterval(e, t) {
            return this.#e.setInterval(e, t)
        }
        clearInterval(e) {
            this.#e.clearInterval(e)
        }
    };

function W(e) {
    setTimeout(e, 0)
}
var ul = typeof window > `u` || `Deno` in globalThis;

function dl() {}

function fl(e, t) {
    return typeof e == `function` ? e(t) : e
}

function pl(e) {
    return typeof e == `number` && e >= 0 && e !== 1 / 0
}

function ml(e, t) {
    return Math.max(e + (t || 0) - Date.now(), 0)
}

function hl(e, t) {
    return typeof e == `function` ? e(t) : e
}

function gl(e, t) {
    return typeof e == `function` ? e(t) : e
}

function _l(e, t) {
    let {
        type: n = `all`,
        exact: r,
        fetchStatus: i,
        predicate: a,
        queryKey: o,
        stale: s
    } = e;
    if (o) {
        if (r) {
            if (t.queryHash !== yl(o, t.options)) return !1
        } else if (!xl(t.queryKey, o)) return !1
    }
    if (n !== `all`) {
        let e = t.isActive();
        if (n === `active` && !e || n === `inactive` && e) return !1
    }
    return !(typeof s == `boolean` && t.isStale() !== s || i && i !== t.state.fetchStatus || a && !a(t))
}

function vl(e, t) {
    let {
        exact: n,
        status: r,
        predicate: i,
        mutationKey: a
    } = e;
    if (a) {
        if (!t.options.mutationKey) return !1;
        if (n) {
            if (bl(t.options.mutationKey) !== bl(a)) return !1
        } else if (!xl(t.options.mutationKey, a)) return !1
    }
    return !(r && t.state.status !== r || i && !i(t))
}

function yl(e, t) {
    return (t ? .queryKeyHashFn || bl)(e)
}

function bl(e) {
    return JSON.stringify(e, (e, t) => Tl(t) ? Object.keys(t).sort().reduce((e, n) => (e[n] = t[n], e), {}) : t)
}

function xl(e, t) {
    return e === t ? !0 : typeof e == typeof t && e && t && typeof e == `object` && typeof t == `object` ? Object.keys(t).every(n => xl(e[n], t[n])) : !1
}
var Sl = Object.prototype.hasOwnProperty;

function Cl(e, t, n = 0) {
    if (e === t) return e;
    if (n > 500) return t;
    let r = wl(e) && wl(t);
    if (!r && !(Tl(e) && Tl(t))) return t;
    let i = (r ? e : Object.keys(e)).length,
        a = r ? t : Object.keys(t),
        o = a.length,
        s = r ? Array(o) : {},
        c = 0;
    for (let l = 0; l < o; l++) {
        let o = r ? l : a[l],
            u = e[o],
            d = t[o];
        if (u === d) {
            s[o] = u, (r ? l < i : Sl.call(e, o)) && c++;
            continue
        }
        if (u === null || d === null || typeof u != `object` || typeof d != `object`) {
            s[o] = d;
            continue
        }
        let f = Cl(u, d, n + 1);
        s[o] = f, f === u && c++
    }
    return i === o && c === i ? e : s
}

function wl(e) {
    return Array.isArray(e) && e.length === Object.keys(e).length
}

function Tl(e) {
    if (!El(e)) return !1;
    let t = e.constructor;
    if (t === void 0) return !0;
    let n = t.prototype;
    return !(!El(n) || !n.hasOwnProperty(`isPrototypeOf`) || Object.getPrototypeOf(e) !== Object.prototype)
}

function El(e) {
    return Object.prototype.toString.call(e) === `[object Object]`
}

function Dl(e) {
    return new Promise(t => {
        ll.setTimeout(t, e)
    })
}

function Ol(e, t, n) {
    return typeof n.structuralSharing == `function` ? n.structuralSharing(e, t) : n.structuralSharing === !1 ? t : Cl(e, t)
}

function kl(e, t, n = 0) {
    let r = [...e, t];
    return n && r.length > n ? r.slice(1) : r
}

function Al(e, t, n = 0) {
    let r = [t, ...e];
    return n && r.length > n ? r.slice(0, -1) : r
}
var jl = Symbol();

function Ml(e, t) {
    return !e.queryFn && t ? .initialPromise ? () => t.initialPromise : !e.queryFn || e.queryFn === jl ? () => Promise.reject(Error(`Missing queryFn: '${e.queryHash}'`)) : e.queryFn
}

function Nl(e, t, n) {
    let r = !1,
        i;
    return Object.defineProperty(e, "signal", {
        enumerable: !0,
        get: () => (i ? ? = t(), r ? i : (r = !0, i.aborted ? n() : i.addEventListener(`abort`, n, {
            once: !0
        }), i))
    }), e
}
var Pl = (() => {
    let e = () => ul;
    return {
        isServer() {
            return e()
        },
        setIsServer(t) {
            e = t
        }
    }
})();

function Fl() {
    let e, t, n = new Promise((n, r) => {
        e = n, t = r
    });
    n.status = `pending`, n.catch(() => {});

    function r(e) {
        Object.assign(n, e), delete n.resolve, delete n.reject
    }
    return n.resolve = t => {
        r({
            status: `fulfilled`,
            value: t
        }), e(t)
    }, n.reject = e => {
        r({
            status: `rejected`,
            reason: e
        }), t(e)
    }, n
}
var Il = W;

function Ll() {
    let e = [],
        t = 0,
        n = e => {
            e()
        },
        r = e => {
            e()
        },
        i = Il,
        a = r => {
            t ? e.push(r) : i(() => {
                n(r)
            })
        },
        o = () => {
            let t = e;
            e = [], t.length && i(() => {
                r(() => {
                    t.forEach(e => {
                        n(e)
                    })
                })
            })
        };
    return {
        batch: e => {
            let n;
            t++;
            try {
                n = e()
            } finally {
                t--, t || o()
            }
            return n
        },
        batchCalls: e => (...t) => {
            a(() => {
                e(...t)
            })
        },
        schedule: a,
        setNotifyFunction: e => {
            n = e
        },
        setBatchNotifyFunction: e => {
            r = e
        },
        setScheduler: e => {
            i = e
        }
    }
}
var Rl = Ll(),
    zl = new class extends ol {#
        e = !0;#
        t;#
        n;
        constructor() {
            super(), this.#n = e => {
                if (typeof window < `u` && window.addEventListener) {
                    let t = () => e(!0),
                        n = () => e(!1);
                    return window.addEventListener(`online`, t, !1), window.addEventListener(`offline`, n, !1), () => {
                        window.removeEventListener(`online`, t), window.removeEventListener(`offline`, n)
                    }
                }
            }
        }
        onSubscribe() {
            this.#t || this.setEventListener(this.#n)
        }
        onUnsubscribe() {
            this.hasListeners() || (this.#t ? .(), this.#t = void 0)
        }
        setEventListener(e) {
            this.#n = e, this.#t ? .(), this.#t = e(this.setOnline.bind(this))
        }
        setOnline(e) {
            this.#e !== e && (this.#e = e, this.listeners.forEach(t => {
                t(e)
            }))
        }
        isOnline() {
            return this.#e
        }
    };

function Bl(e) {
    return Math.min(1e3 * 2 ** e, 3e4)
}

function G(e) {
    return (e ? ? `online`) === `online` ? zl.isOnline() : !0
}
var K = class extends Error {
    constructor(e) {
        super(`CancelledError`), this.revert = e ? .revert, this.silent = e ? .silent
    }
};

function q(e) {
    let t = !1,
        n = 0,
        r, i = Fl(),
        a = () => i.status !== `pending`,
        o = t => {
            if (!a()) {
                let n = new K(t);
                f(n), e.onCancel ? .(n)
            }
        },
        s = () => {
            t = !0
        },
        c = () => {
            t = !1
        },
        l = () => sl.isFocused() && (e.networkMode === `always` || zl.isOnline()) && e.canRun(),
        u = () => G(e.networkMode) && e.canRun(),
        d = e => {
            a() || (r ? .(), i.resolve(e))
        },
        f = e => {
            a() || (r ? .(), i.reject(e))
        },
        p = () => new Promise(t => {
            r = e => {
                (a() || l()) && t(e)
            }, e.onPause ? .()
        }).then(() => {
            r = void 0, a() || e.onContinue ? .()
        }),
        m = () => {
            if (a()) return;
            let r, i = n === 0 ? e.initialPromise : void 0;
            try {
                r = i ? ? e.fn()
            } catch (e) {
                r = Promise.reject(e)
            }
            Promise.resolve(r).then(d).catch(r => {
                if (a()) return;
                let i = e.retry ? ? (Pl.isServer() ? 0 : 3),
                    o = e.retryDelay ? ? Bl,
                    s = typeof o == `function` ? o(n, r) : o,
                    c = i === !0 || typeof i == `number` && n < i || typeof i == `function` && i(n, r);
                if (t || !c) {
                    f(r);
                    return
                }
                n++, e.onFail ? .(n, r), Dl(s).then(() => l() ? void 0 : p()).then(() => {
                    t ? f(r) : m()
                })
            })
        };
    return {
        promise: i,
        status: () => i.status,
        cancel: o,
        continue: () => (r ? .(), i),
        cancelRetry: s,
        continueRetry: c,
        canStart: u,
        start: () => (u() ? m() : p().then(m), i)
    }
}
var J = class {#
    e;
    destroy() {
        this.clearGcTimeout()
    }
    scheduleGc() {
        this.clearGcTimeout(), pl(this.gcTime) && (this.#e = ll.setTimeout(() => {
            this.optionalRemove()
        }, this.gcTime))
    }
    updateGcTime(e) {
        this.gcTime = Math.max(this.gcTime || 0, e ? ? (Pl.isServer() ? 1 / 0 : 300 * 1e3))
    }
    clearGcTimeout() {
        this.#e !== void 0 && (ll.clearTimeout(this.#e), this.#e = void 0)
    }
};

function Y(e) {
    return {
        onFetch: (t, n) => {
            let r = t.options,
                i = t.fetchOptions ? .meta ? .fetchMore ? .direction,
                a = t.state.data ? .pages || [],
                o = t.state.data ? .pageParams || [],
                s = {
                    pages: [],
                    pageParams: []
                },
                c = 0,
                l = async () => {
                    let n = !1,
                        l = e => {
                            Nl(e, () => t.signal, () => n = !0)
                        },
                        u = Ml(t.options, t.fetchOptions),
                        d = async (e, r, i) => {
                            if (n) return Promise.reject(t.signal.reason);
                            if (r == null && e.pages.length) return Promise.resolve(e);
                            let a = await u((() => {
                                    let e = {
                                        client: t.client,
                                        queryKey: t.queryKey,
                                        pageParam: r,
                                        direction: i ? `backward` : `forward`,
                                        meta: t.options.meta
                                    };
                                    return l(e), e
                                })()),
                                {
                                    maxPages: o
                                } = t.options,
                                s = i ? Al : kl;
                            return {
                                pages: s(e.pages, a, o),
                                pageParams: s(e.pageParams, r, o)
                            }
                        };
                    if (i && a.length) {
                        let e = i === `backward`,
                            t = e ? Hl : Vl,
                            n = {
                                pages: a,
                                pageParams: o
                            };
                        s = await d(n, t(r, n), e)
                    } else {
                        let t = e ? ? a.length;
                        do {
                            let e = c === 0 ? o[0] ? ? r.initialPageParam : Vl(r, s);
                            if (c > 0 && e == null) break;
                            s = await d(s, e), c++
                        } while (c < t)
                    }
                    return s
                };
            t.options.persister ? t.fetchFn = () => t.options.persister ? .(l, {
                client: t.client,
                queryKey: t.queryKey,
                meta: t.options.meta,
                signal: t.signal
            }, n) : t.fetchFn = l
        }
    }
}

function Vl(e, {
    pages: t,
    pageParams: n
}) {
    let r = t.length - 1;
    return t.length > 0 ? e.getNextPageParam(t[r], t, n[r], n) : void 0
}

function Hl(e, {
    pages: t,
    pageParams: n
}) {
    return t.length > 0 ? e.getPreviousPageParam ? .(t[0], t, n[0], n) : void 0
}
var Ul = class extends J {#
    e;#
    t;#
    n;#
    r;#
    i;#
    a;#
    o;#
    s;
    constructor(e) {
        super(), this.#s = !1, this.#o = e.defaultOptions, this.setOptions(e.options), this.observers = [], this.#i = e.client, this.#r = this.#i.getQueryCache(), this.queryKey = e.queryKey, this.queryHash = e.queryHash, this.#t = X(this.options), this.state = e.state ? ? this.#t, this.scheduleGc()
    }
    get meta() {
        return this.options.meta
    }
    get queryType() {
        return this.#e
    }
    get promise() {
        return this.#a ? .promise
    }
    setOptions(e) {
        if (this.options = { ...this.#o,
                ...e
            }, e ? ._type && (this.#e = e._type), this.updateGcTime(this.options.gcTime), this.state && this.state.data === void 0) {
            let e = X(this.options);
            e.data !== void 0 && (this.setState(Gl(e.data, e.dataUpdatedAt)), this.#t = e)
        }
    }
    optionalRemove() {
        !this.observers.length && this.state.fetchStatus === `idle` && this.#r.remove(this)
    }
    setData(e, t) {
        let n = Ol(this.state.data, e, this.options);
        return this.#l({
            data: n,
            type: `success`,
            dataUpdatedAt: t ? .updatedAt,
            manual: t ? .manual
        }), n
    }
    setState(e) {
        this.#l({
            type: `setState`,
            state: e
        })
    }
    cancel(e) {
        let t = this.#a ? .promise;
        return this.#a ? .cancel(e), t ? t.then(dl).catch(dl) : Promise.resolve()
    }
    destroy() {
        super.destroy(), this.cancel({
            silent: !0
        })
    }
    get resetState() {
        return this.#t
    }
    reset() {
        this.destroy(), this.setState(this.resetState)
    }
    isActive() {
        return this.observers.some(e => gl(e.options.enabled, this) !== !1)
    }
    isDisabled() {
        return this.getObserversCount() > 0 ? !this.isActive() : this.options.queryFn === jl || !this.isFetched()
    }
    isFetched() {
        return this.state.dataUpdateCount + this.state.errorUpdateCount > 0
    }
    isStatic() {
        return this.getObserversCount() > 0 ? this.observers.some(e => hl(e.options.staleTime, this) === `static`) : !1
    }
    isStale() {
        return this.getObserversCount() > 0 ? this.observers.some(e => e.getCurrentResult().isStale) : this.state.data === void 0 || this.state.isInvalidated
    }
    isStaleByTime(e = 0) {
        return this.state.data === void 0 ? !0 : e === `static` ? !1 : this.state.isInvalidated ? !0 : !ml(this.state.dataUpdatedAt, e)
    }
    onFocus() {
        this.observers.find(e => e.shouldFetchOnWindowFocus()) ? .refetch({
            cancelRefetch: !1
        }), this.#a ? .continue()
    }
    onOnline() {
        this.observers.find(e => e.shouldFetchOnReconnect()) ? .refetch({
            cancelRefetch: !1
        }), this.#a ? .continue()
    }
    addObserver(e) {
        this.observers.includes(e) || (this.observers.push(e), this.clearGcTimeout(), this.#r.notify({
            type: `observerAdded`,
            query: this,
            observer: e
        }))
    }
    removeObserver(e) {
        this.observers.includes(e) && (this.observers = this.observers.filter(t => t !== e), this.observers.length || (this.#a && (this.#s || this.#c() ? this.#a.cancel({
            revert: !0
        }) : this.#a.cancelRetry()), this.scheduleGc()), this.#r.notify({
            type: `observerRemoved`,
            query: this,
            observer: e
        }))
    }
    getObserversCount() {
        return this.observers.length
    }#
    c() {
        return this.state.fetchStatus === `paused` && this.state.status === `pending`
    }
    invalidate() {
        this.state.isInvalidated || this.#l({
            type: `invalidate`
        })
    }
    async fetch(e, t) {
        if (this.state.fetchStatus !== `idle` && this.#a ? .status() !== `rejected`) {
            if (this.state.data !== void 0 && t ? .cancelRefetch) this.cancel({
                silent: !0
            });
            else if (this.#a) return this.#a.continueRetry(), this.#a.promise
        }
        if (e && this.setOptions(e), !this.options.queryFn) {
            let e = this.observers.find(e => e.options.queryFn);
            e && this.setOptions(e.options)
        }
        let n = new AbortController,
            r = e => {
                Object.defineProperty(e, "signal", {
                    enumerable: !0,
                    get: () => (this.#s = !0, n.signal)
                })
            },
            i = () => {
                let e = Ml(this.options, t),
                    n = (() => {
                        let e = {
                            client: this.#i,
                            queryKey: this.queryKey,
                            meta: this.meta
                        };
                        return r(e), e
                    })();
                return this.#s = !1, this.options.persister ? this.options.persister(e, n, this) : e(n)
            },
            a = (() => {
                let e = {
                    fetchOptions: t,
                    options: this.options,
                    queryKey: this.queryKey,
                    client: this.#i,
                    state: this.state,
                    fetchFn: i
                };
                return r(e), e
            })();
        (this.#e === `infinite` ? Y(this.options.pages) : this.options.behavior) ? .onFetch(a, this), this.#n = this.state, (this.state.fetchStatus === `idle` || this.state.fetchMeta !== a.fetchOptions ? .meta) && this.#l({
            type: `fetch`,
            meta: a.fetchOptions ? .meta
        }), this.#a = q({
            initialPromise: t ? .initialPromise,
            fn: a.fetchFn,
            onCancel: e => {
                e instanceof K && e.revert && this.setState({ ...this.#n,
                    fetchStatus: `idle`
                }), n.abort()
            },
            onFail: (e, t) => {
                this.#l({
                    type: `failed`,
                    failureCount: e,
                    error: t
                })
            },
            onPause: () => {
                this.#l({
                    type: `pause`
                })
            },
            onContinue: () => {
                this.#l({
                    type: `continue`
                })
            },
            retry: a.options.retry,
            retryDelay: a.options.retryDelay,
            networkMode: a.options.networkMode,
            canRun: () => !0
        });
        try {
            let e = await this.#a.start();
            if (e === void 0) throw Error(`${this.queryHash} data is undefined`);
            return this.setData(e), this.#r.config.onSuccess ? .(e, this), this.#r.config.onSettled ? .(e, this.state.error, this), e
        } catch (e) {
            if (e instanceof K) {
                if (e.silent) return this.#a.promise;
                if (e.revert) {
                    if (this.state.data === void 0) throw e;
                    return this.state.data
                }
            }
            throw this.#l({
                type: `error`,
                error: e
            }), this.#r.config.onError ? .(e, this), this.#r.config.onSettled ? .(this.state.data, e, this), e
        } finally {
            this.scheduleGc()
        }
    }#
    l(e) {
        let t = t => {
            switch (e.type) {
                case `failed`:
                    return { ...t,
                        fetchFailureCount: e.failureCount,
                        fetchFailureReason: e.error
                    };
                case `pause`:
                    return { ...t,
                        fetchStatus: `paused`
                    };
                case `continue`:
                    return { ...t,
                        fetchStatus: `fetching`
                    };
                case `fetch`:
                    return { ...t,
                        ...Wl(t.data, this.options),
                        fetchMeta: e.meta ? ? null
                    };
                case `success`:
                    let n = { ...t,
                        ...Gl(e.data, e.dataUpdatedAt),
                        dataUpdateCount: t.dataUpdateCount + 1,
                        ...!e.manual && {
                            fetchStatus: `idle`,
                            fetchFailureCount: 0,
                            fetchFailureReason: null
                        }
                    };
                    return this.#n = e.manual ? n : void 0, n;
                case `error`:
                    let r = e.error;
                    return { ...t,
                        error: r,
                        errorUpdateCount: t.errorUpdateCount + 1,
                        errorUpdatedAt: Date.now(),
                        fetchFailureCount: t.fetchFailureCount + 1,
                        fetchFailureReason: r,
                        fetchStatus: `idle`,
                        status: `error`,
                        isInvalidated: !0
                    };
                case `invalidate`:
                    return { ...t,
                        isInvalidated: !0
                    };
                case `setState`:
                    return { ...t,
                        ...e.state
                    }
            }
        };
        this.state = t(this.state), Rl.batch(() => {
            this.observers.forEach(e => {
                e.onQueryUpdate()
            }), this.#r.notify({
                query: this,
                type: `updated`,
                action: e
            })
        })
    }
};

function Wl(e, t) {
    return {
        fetchFailureCount: 0,
        fetchFailureReason: null,
        fetchStatus: G(t.networkMode) ? `fetching` : `paused`,
        ...e === void 0 && {
            error: null,
            status: `pending`
        }
    }
}

function Gl(e, t) {
    return {
        data: e,
        dataUpdatedAt: t ? ? Date.now(),
        error: null,
        isInvalidated: !1,
        status: `success`
    }
}

function X(e) {
    let t = typeof e.initialData == `function` ? e.initialData() : e.initialData,
        n = t !== void 0,
        r = n ? typeof e.initialDataUpdatedAt == `function` ? e.initialDataUpdatedAt() : e.initialDataUpdatedAt : 0;
    return {
        data: t,
        dataUpdateCount: 0,
        dataUpdatedAt: n ? r ? ? Date.now() : 0,
        error: null,
        errorUpdateCount: 0,
        errorUpdatedAt: 0,
        fetchFailureCount: 0,
        fetchFailureReason: null,
        fetchMeta: null,
        isInvalidated: !1,
        status: n ? `success` : `pending`,
        fetchStatus: `idle`
    }
}
var Kl = class extends J {#
    e;#
    t;#
    n;#
    r;
    constructor(e) {
        super(), this.#e = e.client, this.mutationId = e.mutationId, this.#n = e.mutationCache, this.#t = [], this.state = e.state || ql(), this.setOptions(e.options), this.scheduleGc()
    }
    setOptions(e) {
        this.options = e, this.updateGcTime(this.options.gcTime)
    }
    get meta() {
        return this.options.meta
    }
    addObserver(e) {
        this.#t.includes(e) || (this.#t.push(e), this.clearGcTimeout(), this.#n.notify({
            type: `observerAdded`,
            mutation: this,
            observer: e
        }))
    }
    removeObserver(e) {
        this.#t = this.#t.filter(t => t !== e), this.scheduleGc(), this.#n.notify({
            type: `observerRemoved`,
            mutation: this,
            observer: e
        })
    }
    optionalRemove() {
        this.#t.length || (this.state.status === `pending` ? this.scheduleGc() : this.#n.remove(this))
    }
    continue () {
        return this.#r ? .continue() ? ? this.execute(this.state.variables)
    }
    async execute(e) {
        let t = () => {
                this.#i({
                    type: `continue`
                })
            },
            n = {
                client: this.#e,
                meta: this.options.meta,
                mutationKey: this.options.mutationKey
            };
        this.#r = q({
            fn: () => this.options.mutationFn ? this.options.mutationFn(e, n) : Promise.reject(Error(`No mutationFn found`)),
            onFail: (e, t) => {
                this.#i({
                    type: `failed`,
                    failureCount: e,
                    error: t
                })
            },
            onPause: () => {
                this.#i({
                    type: `pause`
                })
            },
            onContinue: t,
            retry: this.options.retry ? ? 0,
            retryDelay: this.options.retryDelay,
            networkMode: this.options.networkMode,
            canRun: () => this.#n.canRun(this)
        });
        let r = this.state.status === `pending`,
            i = !this.#r.canStart();
        try {
            if (r) t();
            else {
                this.#i({
                    type: `pending`,
                    variables: e,
                    isPaused: i
                }), this.#n.config.onMutate && await this.#n.config.onMutate(e, this, n);
                let t = await this.options.onMutate ? .(e, n);
                t !== this.state.context && this.#i({
                    type: `pending`,
                    context: t,
                    variables: e,
                    isPaused: i
                })
            }
            let a = await this.#r.start();
            return await this.#n.config.onSuccess ? .(a, e, this.state.context, this, n), await this.options.onSuccess ? .(a, e, this.state.context, n), await this.#n.config.onSettled ? .(a, null, this.state.variables, this.state.context, this, n), await this.options.onSettled ? .(a, null, e, this.state.context, n), this.#i({
                type: `success`,
                data: a
            }), a
        } catch (t) {
            try {
                await this.#n.config.onError ? .(t, e, this.state.context, this, n)
            } catch (e) {
                Promise.reject(e)
            }
            try {
                await this.options.onError ? .(t, e, this.state.context, n)
            } catch (e) {
                Promise.reject(e)
            }
            try {
                await this.#n.config.onSettled ? .(void 0, t, this.state.variables, this.state.context, this, n)
            } catch (e) {
                Promise.reject(e)
            }
            try {
                await this.options.onSettled ? .(void 0, t, e, this.state.context, n)
            } catch (e) {
                Promise.reject(e)
            }
            throw this.#i({
                type: `error`,
                error: t
            }), t
        } finally {
            this.#n.runNext(this)
        }
    }#
    i(e) {
        let t = t => {
            switch (e.type) {
                case `failed`:
                    return { ...t,
                        failureCount: e.failureCount,
                        failureReason: e.error
                    };
                case `pause`:
                    return { ...t,
                        isPaused: !0
                    };
                case `continue`:
                    return { ...t,
                        isPaused: !1
                    };
                case `pending`:
                    return { ...t,
                        context: e.context,
                        data: void 0,
                        failureCount: 0,
                        failureReason: null,
                        error: null,
                        isPaused: e.isPaused,
                        status: `pending`,
                        variables: e.variables,
                        submittedAt: Date.now()
                    };
                case `success`:
                    return { ...t,
                        data: e.data,
                        failureCount: 0,
                        failureReason: null,
                        error: null,
                        status: `success`,
                        isPaused: !1
                    };
                case `error`:
                    return { ...t,
                        data: void 0,
                        error: e.error,
                        failureCount: t.failureCount + 1,
                        failureReason: e.error,
                        isPaused: !1,
                        status: `error`
                    }
            }
        };
        this.state = t(this.state), Rl.batch(() => {
            this.#t.forEach(t => {
                t.onMutationUpdate(e)
            }), this.#n.notify({
                mutation: this,
                type: `updated`,
                action: e
            })
        })
    }
};

function ql() {
    return {
        context: void 0,
        data: void 0,
        error: null,
        failureCount: 0,
        failureReason: null,
        isPaused: !1,
        status: `idle`,
        variables: void 0,
        submittedAt: 0
    }
}
var Jl = class extends ol {
    constructor(e = {}) {
        super(), this.config = e, this.#e = new Set, this.#t = new Map, this.#n = 0
    }#
    e;#
    t;#
    n;
    build(e, t, n) {
        let r = new Kl({
            client: e,
            mutationCache: this,
            mutationId: ++this.#n,
            options: e.defaultMutationOptions(t),
            state: n
        });
        return this.add(r), r
    }
    add(e) {
        this.#e.add(e);
        let t = Yl(e);
        if (typeof t == `string`) {
            let n = this.#t.get(t);
            n ? n.push(e) : this.#t.set(t, [e])
        }
        this.notify({
            type: `added`,
            mutation: e
        })
    }
    remove(e) {
        if (this.#e.delete(e)) {
            let t = Yl(e);
            if (typeof t == `string`) {
                let n = this.#t.get(t);
                if (n)
                    if (n.length > 1) {
                        let t = n.indexOf(e);
                        t !== -1 && n.splice(t, 1)
                    } else n[0] === e && this.#t.delete(t)
            }
        }
        this.notify({
            type: `removed`,
            mutation: e
        })
    }
    canRun(e) {
        let t = Yl(e);
        if (typeof t == `string`) {
            let n = this.#t.get(t) ? .find(e => e.state.status === `pending`);
            return !n || n === e
        } else return !0
    }
    runNext(e) {
        let t = Yl(e);
        return typeof t == `string` ? (this.#t.get(t) ? .find(t => t !== e && t.state.isPaused)) ? .continue() ? ? Promise.resolve() : Promise.resolve()
    }
    clear() {
        Rl.batch(() => {
            this.#e.forEach(e => {
                this.notify({
                    type: `removed`,
                    mutation: e
                })
            }), this.#e.clear(), this.#t.clear()
        })
    }
    getAll() {
        return Array.from(this.#e)
    }
    find(e) {
        let t = {
            exact: !0,
            ...e
        };
        return this.getAll().find(e => vl(t, e))
    }
    findAll(e = {}) {
        return this.getAll().filter(t => vl(e, t))
    }
    notify(e) {
        Rl.batch(() => {
            this.listeners.forEach(t => {
                t(e)
            })
        })
    }
    resumePausedMutations() {
        let e = this.getAll().filter(e => e.state.isPaused);
        return Rl.batch(() => Promise.all(e.map(e => e.continue().catch(dl))))
    }
};

function Yl(e) {
    return e.options.scope ? .id
}
var Xl = class extends ol {
        constructor(e = {}) {
            super(), this.config = e, this.#e = new Map
        }#
        e;
        build(e, t, n) {
            let r = t.queryKey,
                i = t.queryHash ? ? yl(r, t),
                a = this.get(i);
            return a || (a = new Ul({
                client: e,
                queryKey: r,
                queryHash: i,
                options: e.defaultQueryOptions(t),
                state: n,
                defaultOptions: e.getQueryDefaults(r)
            }), this.add(a)), a
        }
        add(e) {
            this.#e.has(e.queryHash) || (this.#e.set(e.queryHash, e), this.notify({
                type: `added`,
                query: e
            }))
        }
        remove(e) {
            let t = this.#e.get(e.queryHash);
            t && (e.destroy(), t === e && this.#e.delete(e.queryHash), this.notify({
                type: `removed`,
                query: e
            }))
        }
        clear() {
            Rl.batch(() => {
                this.getAll().forEach(e => {
                    this.remove(e)
                })
            })
        }
        get(e) {
            return this.#e.get(e)
        }
        getAll() {
            return [...this.#e.values()]
        }
        find(e) {
            let t = {
                exact: !0,
                ...e
            };
            return this.getAll().find(e => _l(t, e))
        }
        findAll(e = {}) {
            let t = this.getAll();
            return Object.keys(e).length > 0 ? t.filter(t => _l(e, t)) : t
        }
        notify(e) {
            Rl.batch(() => {
                this.listeners.forEach(t => {
                    t(e)
                })
            })
        }
        onFocus() {
            Rl.batch(() => {
                this.getAll().forEach(e => {
                    e.onFocus()
                })
            })
        }
        onOnline() {
            Rl.batch(() => {
                this.getAll().forEach(e => {
                    e.onOnline()
                })
            })
        }
    },
    Zl = class {#
        e;#
        t;#
        n;#
        r;#
        i;#
        a;#
        o;#
        s;
        constructor(e = {}) {
            this.#e = e.queryCache || new Xl, this.#t = e.mutationCache || new Jl, this.#n = e.defaultOptions || {}, this.#r = new Map, this.#i = new Map, this.#a = 0
        }
        mount() {
            this.#a++, this.#a === 1 && (this.#o = sl.subscribe(async e => {
                e && (await this.resumePausedMutations(), this.#e.onFocus())
            }), this.#s = zl.subscribe(async e => {
                e && (await this.resumePausedMutations(), this.#e.onOnline())
            }))
        }
        unmount() {
            this.#a--, this.#a === 0 && (this.#o ? .(), this.#o = void 0, this.#s ? .(), this.#s = void 0)
        }
        isFetching(e) {
            return this.#e.findAll({ ...e,
                fetchStatus: `fetching`
            }).length
        }
        isMutating(e) {
            return this.#t.findAll({ ...e,
                status: `pending`
            }).length
        }
        getQueryData(e) {
            let t = this.defaultQueryOptions({
                queryKey: e
            });
            return this.#e.get(t.queryHash) ? .state.data
        }
        ensureQueryData(e) {
            let t = this.defaultQueryOptions(e),
                n = this.#e.build(this, t),
                r = n.state.data;
            return r === void 0 ? this.fetchQuery(e) : (e.revalidateIfStale && n.isStaleByTime(hl(t.staleTime, n)) && this.prefetchQuery(t), Promise.resolve(r))
        }
        getQueriesData(e) {
            return this.#e.findAll(e).map(({
                queryKey: e,
                state: t
            }) => [e, t.data])
        }
        setQueryData(e, t, n) {
            let r = this.defaultQueryOptions({
                    queryKey: e
                }),
                i = this.#e.get(r.queryHash) ? .state.data,
                a = fl(t, i);
            if (a !== void 0) return this.#e.build(this, r).setData(a, { ...n,
                manual: !0
            })
        }
        setQueriesData(e, t, n) {
            return Rl.batch(() => this.#e.findAll(e).map(({
                queryKey: e
            }) => [e, this.setQueryData(e, t, n)]))
        }
        getQueryState(e) {
            let t = this.defaultQueryOptions({
                queryKey: e
            });
            return this.#e.get(t.queryHash) ? .state
        }
        removeQueries(e) {
            let t = this.#e;
            Rl.batch(() => {
                t.findAll(e).forEach(e => {
                    t.remove(e)
                })
            })
        }
        resetQueries(e, t) {
            let n = this.#e;
            return Rl.batch(() => (n.findAll(e).forEach(e => {
                e.reset()
            }), this.refetchQueries({
                type: `active`,
                ...e
            }, t)))
        }
        cancelQueries(e, t = {}) {
            let n = {
                    revert: !0,
                    ...t
                },
                r = Rl.batch(() => this.#e.findAll(e).map(e => e.cancel(n)));
            return Promise.all(r).then(dl).catch(dl)
        }
        invalidateQueries(e, t = {}) {
            return Rl.batch(() => (this.#e.findAll(e).forEach(e => {
                e.invalidate()
            }), e ? .refetchType === `none` ? Promise.resolve() : this.refetchQueries({ ...e,
                type: e ? .refetchType ? ? e ? .type ? ? `active`
            }, t)))
        }
        refetchQueries(e, t = {}) {
            let n = { ...t,
                    cancelRefetch: t.cancelRefetch ? ? !0
                },
                r = Rl.batch(() => this.#e.findAll(e).filter(e => !e.isDisabled() && !e.isStatic()).map(e => {
                    let t = e.fetch(void 0, n);
                    return n.throwOnError || (t = t.catch(dl)), e.state.fetchStatus === `paused` ? Promise.resolve() : t
                }));
            return Promise.all(r).then(dl)
        }
        fetchQuery(e) {
            let t = this.defaultQueryOptions(e);
            t.retry === void 0 && (t.retry = !1);
            let n = this.#e.build(this, t);
            return n.isStaleByTime(hl(t.staleTime, n)) ? n.fetch(t) : Promise.resolve(n.state.data)
        }
        prefetchQuery(e) {
            return this.fetchQuery(e).then(dl).catch(dl)
        }
        fetchInfiniteQuery(e) {
            return e._type = `infinite`, this.fetchQuery(e)
        }
        prefetchInfiniteQuery(e) {
            return this.fetchInfiniteQuery(e).then(dl).catch(dl)
        }
        ensureInfiniteQueryData(e) {
            return e._type = `infinite`, this.ensureQueryData(e)
        }
        resumePausedMutations() {
            return zl.isOnline() ? this.#t.resumePausedMutations() : Promise.resolve()
        }
        getQueryCache() {
            return this.#e
        }
        getMutationCache() {
            return this.#t
        }
        getDefaultOptions() {
            return this.#n
        }
        setDefaultOptions(e) {
            this.#n = e
        }
        setQueryDefaults(e, t) {
            this.#r.set(bl(e), {
                queryKey: e,
                defaultOptions: t
            })
        }
        getQueryDefaults(e) {
            let t = [...this.#r.values()],
                n = {};
            return t.forEach(t => {
                xl(e, t.queryKey) && Object.assign(n, t.defaultOptions)
            }), n
        }
        setMutationDefaults(e, t) {
            this.#i.set(bl(e), {
                mutationKey: e,
                defaultOptions: t
            })
        }
        getMutationDefaults(e) {
            let t = [...this.#i.values()],
                n = {};
            return t.forEach(t => {
                xl(e, t.mutationKey) && Object.assign(n, t.defaultOptions)
            }), n
        }
        defaultQueryOptions(e) {
            if (e._defaulted) return e;
            let t = { ...this.#n.queries,
                ...this.getQueryDefaults(e.queryKey),
                ...e,
                _defaulted: !0
            };
            return t.queryHash || = yl(t.queryKey, t), t.refetchOnReconnect === void 0 && (t.refetchOnReconnect = t.networkMode !== `always`), t.throwOnError === void 0 && (t.throwOnError = !!t.suspense), !t.networkMode && t.persister && (t.networkMode = `offlineFirst`), t.queryFn === jl && (t.enabled = !1), t
        }
        defaultMutationOptions(e) {
            return e ? ._defaulted ? e : { ...this.#n.mutations,
                ...e ? .mutationKey && this.getMutationDefaults(e.mutationKey),
                ...e,
                _defaulted : !0
            }
        }
        clear() {
            this.#e.clear(), this.#t.clear()
        }
    },
    Ql = z.createContext(void 0),
    $l = ({
        client: e,
        children: t
    }) => (z.useEffect(() => (e.mount(), () => {
        e.unmount()
    }), [e]), (0, B.jsx)(Ql.Provider, {
        value: e,
        children: t
    })),
    eu = `/assets/styles-CNP5WB0Z.css`;

function tu(e, t = {}) {
    if (typeof window > `u`) return;
    window.__lovableEvents ? .captureException ? .(e, {
        source: `react_error_boundary`,
        route: window.location.pathname,
        ...t
    }, {
        mechanism: `react_error_boundary`,
        handled: !1,
        severity: `error`
    });
    let n = e instanceof Response ? `Response ${e.status}${e.url?` at ${e.url}`:``}` : e instanceof Error ? e.message : String(e);
    window.__lovableReportRuntimeError ? .({
        message: n,
        stack: e instanceof Error ? e.stack : void 0,
        filename: window.location.pathname
    })
}

function nu() {
    return (0, B.jsx)(`div`, {
        className: `flex min-h-screen items-center justify-center bg-background px-4`,
        children: (0, B.jsxs)(`div`, {
            className: `max-w-md text-center`,
            children: [(0, B.jsx)(`h1`, {
                className: `text-7xl font-bold text-foreground`,
                children: `404`
            }), (0, B.jsx)(`h2`, {
                className: `mt-4 text-xl font-semibold text-foreground`,
                children: `Page not found`
            }), (0, B.jsx)(`p`, {
                className: `mt-2 text-sm text-muted-foreground`,
                children: `The page you're looking for doesn't exist or has been moved.`
            }), (0, B.jsx)(`div`, {
                className: `mt-6`,
                children: (0, B.jsx)(bc, {
                    to: `/`,
                    className: `inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90`,
                    children: `Go home`
                })
            })]
        })
    })
}

function ru({
    error: e,
    reset: t
}) {
    console.error(e);
    let n = Ds();
    return (0, z.useEffect)(() => {
        tu(e, {
            boundary: `tanstack_root_error_component`
        })
    }, [e]), (0, B.jsx)(`div`, {
        className: `flex min-h-screen items-center justify-center bg-background px-4`,
        children: (0, B.jsxs)(`div`, {
            className: `max-w-md text-center`,
            children: [(0, B.jsx)(`h1`, {
                className: `text-xl font-semibold tracking-tight text-foreground`,
                children: `This page didn't load`
            }), (0, B.jsx)(`p`, {
                className: `mt-2 text-sm text-muted-foreground`,
                children: `Something went wrong on our end. You can try refreshing or head back home.`
            }), (0, B.jsxs)(`div`, {
                className: `mt-6 flex flex-wrap justify-center gap-2`,
                children: [(0, B.jsx)(`button`, {
                    onClick: () => {
                        n.invalidate(), t()
                    },
                    className: `inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90`,
                    children: `Try again`
                }), (0, B.jsx)(`a`, {
                    href: `/`,
                    className: `inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent`,
                    children: `Go home`
                })]
            })]
        })
    })
}
var iu = wc()({
    head: () => ({
        meta: [{
            charSet: `utf-8`
        }, {
            name: `viewport`,
            content: `width=device-width, initial-scale=1`
        }, {
            title: `Acervo de Moldes para Papelaria Personalizada — +7.500 Artes`
        }, {
            name: `description`,
            content: `Mais de 7.500 artes, moldes e modelos prontos para editar, imprimir e adaptar. Compatível com Canva, CorelDraw e Silhouette Studio.`
        }, {
            property: `og:title`,
            content: `Acervo de Moldes para Papelaria Personalizada — +7.500 Artes`
        }, {
            property: `og:description`,
            content: `Mais de 7.500 artes, moldes e modelos prontos para editar, imprimir e adaptar. Compatível com Canva, CorelDraw e Silhouette Studio.`
        }, {
            property: `og:type`,
            content: `website`
        }, {
            name: `twitter:card`,
            content: `summary_large_image`
        }, {
            name: `twitter:title`,
            content: `Acervo de Moldes para Papelaria Personalizada — +7.500 Artes`
        }, {
            name: `twitter:description`,
            content: `Mais de 7.500 artes, moldes e modelos prontos para editar, imprimir e adaptar. Compatível com Canva, CorelDraw e Silhouette Studio.`
        }, {
            property: `og:image`,
            content: `https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/8d2d6b94-1167-473f-a30e-f89979e56724/id-preview-fb66825a--5016f5ee-2497-43ad-8e1d-9c51cb507b8f.lovable.app-1784347397330.png`
        }, {
            name: `twitter:image`,
            content: `https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/8d2d6b94-1167-473f-a30e-f89979e56724/id-preview-fb66825a--5016f5ee-2497-43ad-8e1d-9c51cb507b8f.lovable.app-1784347397330.png`
        }],
        links: [{
            rel: `stylesheet`,
            href: eu
        }, {
            rel: `icon`,
            href: `/favicon.ico`,
            type: `image/x-icon`
        }, {
            rel: `preconnect`,
            href: `https://fonts.googleapis.com`
        }, {
            rel: `preconnect`,
            href: `https://fonts.gstatic.com`,
            crossOrigin: `anonymous`
        }, {
            rel: `stylesheet`,
            href: `https://fonts.googleapis.com/css2?family=Nunito:wght@400;500;600;700;800;900&family=Baloo+2:wght@500;600;700;800&display=swap`
        }]
    }),
    shellComponent: au,
    component: ou,
    notFoundComponent: nu,
    errorComponent: ru
});

function au({
    children: e
}) {
    return (0, B.jsxs)(`html`, {
        lang: `en`,
        children: [(0, B.jsxs)(`head`, {
            children: [(0, B.jsx)(Qc, {}), (0, B.jsx)(`script`, {
                dangerouslySetInnerHTML: {
                    __html: `window.pixelId = "6a5b03ada05dc54a0cbf8cec"; var a = document.createElement("script"); a.setAttribute("async", ""); a.setAttribute("defer", ""); a.setAttribute("src", "https://cdn.utmify.com.br/scripts/pixel/pixel.js"); document.head.appendChild(a);`
                }
            }), (0, B.jsx)(`script`, {
                src: `https://cdn.utmify.com.br/scripts/utms/latest.js`,
                "data-utmify-prevent-xcod-sck": !0,
                "data-utmify-prevent-subids": !0,
                async: !0,
                defer: !0
            })]
        }), (0, B.jsxs)(`body`, {
            children: [e, (0, B.jsx)($c, {})]
        })]
    })
}

function ou() {
    let {
        queryClient: e
    } = iu.useRouteContext();
    return (0, B.jsx)($l, {
        client: e,
        children: (0, B.jsx)(U, {})
    })
}
var su = `modulepreload`,
    cu = function(e) {
        return `/` + e
    },
    lu = {},
    uu = function(e, t, n) {
        let r = Promise.resolve();
        if (t && t.length > 0) {
            let e = document.getElementsByTagName(`link`),
                i = document.querySelector(`meta[property=csp-nonce]`),
                a = i ? .nonce || i ? .getAttribute(`nonce`);

            function o(e) {
                return Promise.all(e.map(e => Promise.resolve(e).then(e => ({
                    status: `fulfilled`,
                    value: e
                }), e => ({
                    status: `rejected`,
                    reason: e
                }))))
            }
            r = o(t.map(t => {
                if (t = cu(t, n), t in lu) return;
                lu[t] = !0;
                let r = t.endsWith(`.css`),
                    i = r ? `[rel="stylesheet"]` : ``;
                if (n)
                    for (let n = e.length - 1; n >= 0; n--) {
                        let i = e[n];
                        if (i.href === t && (!r || i.rel === `stylesheet`)) return
                    } else if (document.querySelector(`link[href="${t}"]${i}`)) return;
                let o = document.createElement(`link`);
                if (o.rel = r ? `stylesheet` : su, r || (o.as = `script`), o.crossOrigin = ``, o.href = t, a && o.setAttribute(`nonce`, a), document.head.appendChild(o), r) return new Promise((e, n) => {
                    o.addEventListener(`load`, e), o.addEventListener(`error`, () => n(Error(`Unable to preload CSS for ${t}`)))
                })
            }))
        }

        function i(e) {
            let t = new Event(`vite:preloadError`, {
                cancelable: !0
            });
            if (t.payload = e, window.dispatchEvent(t), !t.defaultPrevented) throw e
        }
        return r.then(t => {
            for (let e of t || []) e.status === `rejected` && i(e.reason);
            return e().catch(i)
        })
    },
    du = {
        IndexRoute: Dc(`/`)({
            component: kc(() => uu(() =>
                import (`./routes-BVuSelZA.js`), []), `component`)
        }).update({
            id: `/`,
            path: `/`,
            getParentRoute: () => iu
        })
    },
    fu = iu._addFileChildren(du),
    pu = () => Wc({
        routeTree: fu,
        context: {
            queryClient: new Zl
        },
        scrollRestoration: !0,
        defaultPreloadStaleTime: 0
    });
async function mu() {
    let e = await pu(),
        t;
    if (al) {
        let n = await al.getOptions();
        n.serializationAdapters = n.serializationAdapters ? ? [], window.__TSS_START_OPTIONS__ = n, t = n.serializationAdapters, e.options.defaultSsr = n.defaultSsr
    } else t = [], window.__TSS_START_OPTIONS__ = {
        serializationAdapters: t
    };
    return t.push(os), e.options.serializationAdapters && t.push(...e.options.serializationAdapters), e.update({
        basepath: ``,
        serializationAdapters: t
    }), e.stores.matchesId.get().length || await ls(e), e
}
var hu = mu;
async function gu() {
    let e = await hu();
    return window.$_TSR ? .h(), e
}
var _u;

function vu() {
    return _u || = gu(), (0, B.jsx)(vs, {
        promise: _u,
        children: e => (0, B.jsx)(qc, {
            router: e
        })
    })
}
var yu = g();
(0, z.startTransition)(() => {
    (0, yu.hydrateRoot)(document, (0, B.jsx)(z.StrictMode, {
        children: (0, B.jsx)(vu, {})
    }))
});
export {
    u as n, c as r, gs as t
};