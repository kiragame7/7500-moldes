(() => {
    "use strict";
    var t = {
            370: (t, e) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.visibleForTesting = void 0, e.visibleForTesting = (t, e) => {}
            },
            568: (t, e, i) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.AppStorage = void 0;
                const n = i(923);
                e.AppStorage = class {
                    static save(t, e) {
                        const i = JSON.stringify(e);
                        localStorage.setItem(t, i)
                    }
                    static load(t) {
                        const e = localStorage.getItem(t);
                        return e ? JSON.parse(e) : null
                    }
                    static getFbc() {
                        const t = document.cookie.split(";");
                        for (const e of t) {
                            const [t, i] = e.trim().split("=");
                            if ("_fbc" === t) return decodeURIComponent(i)
                        }
                    }
                    static getFbp() {
                        var t;
                        return null !== (t = n.Utils.getCookieByNames("_fbp", "fbp")) && void 0 !== t ? t : void 0
                    }
                    static getTtp() {
                        var t;
                        return null !== (t = n.Utils.getCookieByNames("_ttp", "ttp")) && void 0 !== t ? t : void 0
                    }
                }
            },
            717: function(t, e) {
                var i = this && this.__awaiter || function(t, e, i, n) {
                    return new(i || (i = Promise))((function(o, l) {
                        function r(t) {
                            try {
                                s(n.next(t))
                            } catch (t) {
                                l(t)
                            }
                        }

                        function a(t) {
                            try {
                                s(n.throw(t))
                            } catch (t) {
                                l(t)
                            }
                        }

                        function s(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof i ? e : new i((function(t) {
                                t(e)
                            }))).then(r, a)
                        }
                        s((n = n.apply(t, e || [])).next())
                    }))
                };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.CountryService = void 0, e.CountryService = class {
                    static getCountry(t) {
                        var e, n;
                        return i(this, void 0, void 0, (function*() {
                            if (null === (e = t.geolocation) || void 0 === e ? void 0 : e.country) return t.geolocation.country;
                            const i = yield(yield fetch("https://ipapi.co/json/")).json();
                            return null !== (n = i.country) && void 0 !== n ? n : null
                        }))
                    }
                }
            },
            75: (t, e) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.FBC = void 0;
                class i {
                    constructor(t) {
                        this.version = "fb", this.fbclid = t, this.subdomainIndex = 1, this.creationTime = Date.now()
                    }
                    static fromClid(t) {
                        return t ? new i(t) : null
                    }
                    formatted() {
                        return `${this.version}.${this.subdomainIndex}.${this.creationTime}.${this.fbclid}`
                    }
                }
                e.FBC = i
            },
            865: function(t, e, i) {
                var n = this && this.__decorate || function(t, e, i, n) {
                        var o, l = arguments.length,
                            r = l < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, i) : n;
                        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(t, e, i, n);
                        else
                            for (var a = t.length - 1; a >= 0; a--)(o = t[a]) && (r = (l < 3 ? o(r) : l > 3 ? o(e, i, r) : o(e, i)) || r);
                        return l > 3 && r && Object.defineProperty(e, i, r), r
                    },
                    o = this && this.__metadata || function(t, e) {
                        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(t, e)
                    },
                    l = this && this.__awaiter || function(t, e, i, n) {
                        return new(i || (i = Promise))((function(o, l) {
                            function r(t) {
                                try {
                                    s(n.next(t))
                                } catch (t) {
                                    l(t)
                                }
                            }

                            function a(t) {
                                try {
                                    s(n.throw(t))
                                } catch (t) {
                                    l(t)
                                }
                            }

                            function s(t) {
                                var e;
                                t.done ? o(t.value) : (e = t.value, e instanceof i ? e : new i((function(t) {
                                    t(e)
                                }))).then(r, a)
                            }
                            s((n = n.apply(t, e || [])).next())
                        }))
                    };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.FormsListener = void 0;
                const r = i(370),
                    a = i(119),
                    s = i(568),
                    d = i(717),
                    c = i(562),
                    u = i(554),
                    v = i(526),
                    p = i(923);
                class g {
                    static init() {
                        g.inited || (g.inited = !0, "complete" === document.readyState ? g.startListening() : window.addEventListener("load", g.startListening))
                    }
                    static startListening() {
                        g.listenToForms(!0), new c.Observer({
                            throttle: 2e3,
                            groupEvents: !0
                        }).observeNewElements(document.body, (() => {
                            g.listenToForms(!1)
                        }))
                    }
                    static listenToForms(t) {
                        Array.from(document.querySelectorAll("input, textarea")).forEach((e => {
                            (t || g.canUseEl(e)) && (g.tryFill(e), e.addEventListener("input", g.handleInput), e.addEventListener("blur", g.handleInput))
                        }))
                    }
                    static tryFill(t) {
                        var e, i, n, o;
                        return l(this, void 0, void 0, (function*() {
                            const l = yield v.Tracker.getTruthyLead(), r = g.classifyInput(t);
                            r === a.InputType.Phone && (t.value = null !== (e = l.phone) && void 0 !== e ? e : ""), r === a.InputType.Email && (t.value = null !== (i = l.email) && void 0 !== i ? i : ""), r === a.InputType.Name && (t.value = `${null!==(n=l.firstName)&&void 0!==n?n:""} ${null!==(o=l.lastName)&&void 0!==o?o:""}`)
                        }))
                    }
                    static handleInput(t) {
                        return l(this, void 0, void 0, (function*() {
                            const e = t.target,
                                i = g.classifyInput(e),
                                n = yield v.Tracker.getTruthyLead();
                            if (i === a.InputType.Phone) {
                                const t = yield d.CountryService.getCountry(n), i = u.Phone.format(e.value, "BR" === t);
                                s.AppStorage.save(v.Tracker.leadKey, Object.assign(Object.assign({}, n), {
                                    phone: i
                                }))
                            }
                            if (i === a.InputType.Email && s.AppStorage.save(v.Tracker.leadKey, Object.assign(Object.assign({}, n), {
                                    email: e.value
                                })), i === a.InputType.Name) {
                                const t = e.value.split(" "),
                                    i = t[0],
                                    o = t.slice(1).join(" ");
                                s.AppStorage.save(v.Tracker.leadKey, Object.assign(Object.assign({}, n), {
                                    firstName: i,
                                    lastName: o
                                }))
                            }
                        }))
                    }
                    static classifyInput(t) {
                        const {
                            id: e,
                            name: i,
                            type: n,
                            placeholder: o
                        } = t;
                        return "email" === n || (null == o ? void 0 : o.toLowerCase().includes("email")) || (null == e ? void 0 : e.toLowerCase().includes("field-email")) || (null == i ? void 0 : i.toLowerCase().includes("email")) ? a.InputType.Email : (null == i ? void 0 : i.toLowerCase().includes("phone")) || (null == e ? void 0 : e.toLowerCase().includes("field-phone")) || (null == o ? void 0 : o.toLowerCase().includes("phone")) ? a.InputType.Phone : (null == i ? void 0 : i.toLowerCase().includes("name")) || (null == e ? void 0 : e.toLowerCase().includes("field-name")) || (null == o ? void 0 : o.toLowerCase().includes("name")) ? a.InputType.Name : a.InputType.Unknown
                    }
                    static canUseEl(t) {
                        if (g.usedIds.has(t.id)) return !1;
                        const e = p.Utils.getId(t);
                        return g.usedIds.add(e), !0
                    }
                }
                g.inited = !1, g.usedIds = new Set, n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", []), o("design:returntype", void 0)], g, "startListening", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [HTMLInputElement]), o("design:returntype", Promise)], g, "tryFill", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [Event]), o("design:returntype", Promise)], g, "handleInput", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [HTMLInputElement]), o("design:returntype", String)], g, "classifyInput", null), e.FormsListener = g
            },
            8: function(t, e) {
                var i = this && this.__awaiter || function(t, e, i, n) {
                    return new(i || (i = Promise))((function(o, l) {
                        function r(t) {
                            try {
                                s(n.next(t))
                            } catch (t) {
                                l(t)
                            }
                        }

                        function a(t) {
                            try {
                                s(n.throw(t))
                            } catch (t) {
                                l(t)
                            }
                        }

                        function s(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof i ? e : new i((function(t) {
                                t(e)
                            }))).then(r, a)
                        }
                        s((n = n.apply(t, e || [])).next())
                    }))
                };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.Ips = void 0;
                class n {
                    static getIpv4(t) {
                        return i(this, void 0, void 0, (function*() {
                            return yield n.fetchIp("https://api.ipify.org?format=json", "error on getIpv4", null == t ? void 0 : t.timeoutMs)
                        }))
                    }
                    static getIpv6(t) {
                        return i(this, void 0, void 0, (function*() {
                            return yield n.fetchIp("https://api6.ipify.org?format=json", "error on getIpv6", null == t ? void 0 : t.timeoutMs)
                        }))
                    }
                    static fetchIp(t, e, n) {
                        var o;
                        return i(this, void 0, void 0, (function*() {
                            const i = n ? AbortSignal.timeout(n) : null;
                            try {
                                const e = yield fetch(t, {
                                    signal: i
                                }).then((t => t.json()));
                                return null !== (o = e.ip) && void 0 !== o ? o : void 0
                            } catch (t) {
                                return void console.log(e, t)
                            }
                        }))
                    }
                }
                e.Ips = n
            },
            774: function(t, e, i) {
                var n = this && this.__decorate || function(t, e, i, n) {
                        var o, l = arguments.length,
                            r = l < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, i) : n;
                        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(t, e, i, n);
                        else
                            for (var a = t.length - 1; a >= 0; a--)(o = t[a]) && (r = (l < 3 ? o(r) : l > 3 ? o(e, i, r) : o(e, i)) || r);
                        return l > 3 && r && Object.defineProperty(e, i, r), r
                    },
                    o = this && this.__metadata || function(t, e) {
                        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(t, e)
                    },
                    l = this && this.__awaiter || function(t, e, i, n) {
                        return new(i || (i = Promise))((function(o, l) {
                            function r(t) {
                                try {
                                    s(n.next(t))
                                } catch (t) {
                                    l(t)
                                }
                            }

                            function a(t) {
                                try {
                                    s(n.throw(t))
                                } catch (t) {
                                    l(t)
                                }
                            }

                            function s(t) {
                                var e;
                                t.done ? o(t.value) : (e = t.value, e instanceof i ? e : new i((function(t) {
                                    t(e)
                                }))).then(r, a)
                            }
                            s((n = n.apply(t, e || [])).next())
                        }))
                    };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.checkoutButtonKeywors = e.checkoutLinkKeywords = e.NavigationListener = void 0;
                const r = i(370),
                    a = i(562),
                    s = i(526),
                    d = i(923);
                class c {
                    static init() {
                        this.inited || (this.inited = !0, c.monitorWindowOpen(), c.monitorLinks(!0), c.monitorButtons(!0), c.monitorForms(!0), new a.Observer({
                            throttle: 2e3,
                            groupEvents: !0
                        }).observeNewElements(document.body, (() => {
                            c.monitorLinks(!1), c.monitorButtons(!1), c.monitorForms(!1)
                        })))
                    }
                    static monitorButtons(t) {
                        const e = Array.from(document.querySelectorAll("button"));
                        console.log("buttons", e), e.forEach((e => {
                            (t || this.canUseEl(e)) && e.addEventListener("click", (t => {
                                var i, n, o, l;
                                console.log("button clicked pixel", e), (c.isCheckoutButtonText(null !== (i = e.textContent) && void 0 !== i ? i : "") || c.isCheckoutButtonClassList(null !== (n = e.classList) && void 0 !== n ? n : "")) && (console.log("tracking ic with button", e), s.Tracker.track("InitiateCheckout")), c.isLeadButtonText(null !== (o = e.textContent) && void 0 !== o ? o : "") && (console.log("tracking lead with button", e), s.Tracker.track("Lead")), c.isAddToCartButtonText(null !== (l = e.textContent) && void 0 !== l ? l : "") && (console.log("tracking add to cart with button", e), s.Tracker.track("AddToCart"))
                            }), !0)
                        }))
                    }
                    static monitorForms(t) {
                        Array.from(document.querySelectorAll("form")).forEach((e => {
                            (t || this.canUseEl(e)) && e.addEventListener("submit", (t => {
                                var i;
                                const n = e.querySelector('button[type="submit"], input[type="submit"], input[type="button"]');
                                console.log("submitButton", n);
                                const o = c.getSubmitElementText(n);
                                c.isCheckoutButtonText(o) && (console.log("tracking ic with form", e), s.Tracker.track("InitiateCheckout")), c.isCheckoutButtonClassList(null !== (i = null == n ? void 0 : n.classList) && void 0 !== i ? i : null) && (console.log("tracking ic with form", e), s.Tracker.track("InitiateCheckout")), c.isCheckoutLink(e.action, void 0, void 0) && (console.log("tracking ic with form", e), s.Tracker.track("InitiateCheckout")), c.isLeadButtonText(o) && (console.log("tracking lead with button", n), s.Tracker.track("Lead")), c.isAddToCartButtonText(o) && (console.log("tracking add to cart with button", n), s.Tracker.track("AddToCart"))
                            }), !0)
                        }))
                    }
                    static getSubmitElementText(t) {
                        var e;
                        if (!t) return "";
                        const {
                            textContent: i
                        } = t;
                        return i || (null !== (e = t.value) && void 0 !== e ? e : "")
                    }
                    static monitorWindowOpen() {
                        const t = window.open;
                        window.open = function(e, i, n) {
                            const o = () => t(e, i || "", n || "");
                            return c.isCheckoutLink(null == e ? void 0 : e.toString(), void 0, void 0) ? (s.Tracker.track("InitiateCheckout").finally((() => {
                                o()
                            })), null) : o()
                        }
                    }
                    static monitorLinks(t) {
                        Array.from(document.querySelectorAll("a")).forEach((e => {
                            (t || this.canUseEl(e)) && e.addEventListener("click", (t => {
                                var i, n, o;
                                console.log("link clicked v", e);
                                const l = c.isCheckoutLink(e.href, null !== (i = e.textContent) && void 0 !== i ? i : "", e.classList);
                                console.log("canSendIc", l), l && c.waitBeforeAction(t, s.Tracker.track("InitiateCheckout"), e);
                                const r = c.isLeadButtonText(null !== (n = e.textContent) && void 0 !== n ? n : "");
                                console.log("canSendLead", r), r && c.waitBeforeAction(t, s.Tracker.track("Lead"), e);
                                const a = c.isAddToCartButtonText(null !== (o = e.textContent) && void 0 !== o ? o : "");
                                console.log("canAddToCart", a), a && (console.log("tracking add to cart with button", e), c.waitBeforeAction(t, s.Tracker.track("AddToCart"), e))
                            }), !0)
                        }))
                    }
                    static waitBeforeAction(t, e, i) {
                        var n, o;
                        return l(this, void 0, void 0, (function*() {
                            if (c.isShopify()) return void(yield e);
                            if (c.isElementorButton(i)) return void(yield e);
                            if (null !== (n = null == t ? void 0 : t.flagged) && void 0 !== n && n) return void console.log("flagged event", t);
                            null == t || t.preventDefault(), null == t || t.stopPropagation();
                            const l = i.onclick;
                            i.onclick = null;
                            try {
                                yield e, console.log("tracking done")
                            } catch (t) {
                                console.error("Error tracking", t)
                            }
                            console.log("target", i), console.log("insance of a el", i instanceof HTMLAnchorElement);
                            const r = i.classList.contains("link_interno");
                            if (l) l.call(i);
                            else if (i instanceof HTMLAnchorElement && null != i.href && "" !== i.href && !r) console.log("TARGET.href", i.href), window.location.href = i.href;
                            else if (i instanceof HTMLButtonElement && "submit" === i.type) {
                                const t = i.closest("form");
                                t && t.submit()
                            }
                            const a = new Event(t.type, t);
                            a.flagged = !0, null === (o = t.target) || void 0 === o || o.dispatchEvent(a), console.log("dispatched event", a), i.onclick = l
                        }))
                    }
                    static canUseEl(t) {
                        if (this.usedIds.has(t.id)) return !1;
                        const e = d.Utils.getId(t);
                        return this.usedIds.add(e), !0
                    }
                    static removeInvisibleCharsFromText(t) {
                        return null == t ? void 0 : t.replace(/[\u200B-\u200D\uFEFF]/g, "")
                    }
                    static isCheckoutLink(t, i, n) {
                        var o, l, r;
                        console.log("check is checkout link: ", t);
                        const a = s.Tracker.getTruthyLead();
                        if (a.icURLMatch) return null !== (o = null == t ? void 0 : t.includes(a.icURLMatch)) && void 0 !== o && o;
                        if (null != a.icTextMatch) {
                            if (null == i ? void 0 : i.includes(a.icTextMatch)) return !0;
                            const t = c.removeInvisibleCharsFromText(i);
                            return null !== (l = null == t ? void 0 : t.includes(a.icTextMatch)) && void 0 !== l && l
                        }
                        if (a.icCSSMatch) return null !== (r = null == n ? void 0 : n.contains(a.icCSSMatch)) && void 0 !== r && r;
                        for (const i of e.checkoutLinkKeywords)
                            if (null == t ? void 0 : t.toLowerCase().includes(i.toLowerCase())) return !0;
                        return !1
                    }
                    static isCheckoutButtonText(t) {
                        var i;
                        console.log("check can iniate checkout: ", t);
                        const n = s.Tracker.getTruthyLead();
                        if (null != n.icTextMatch) {
                            if (null == t ? void 0 : t.includes(n.icTextMatch)) return !0;
                            const e = c.removeInvisibleCharsFromText(t);
                            return null !== (i = null == e ? void 0 : e.includes(n.icTextMatch)) && void 0 !== i && i
                        }
                        return e.checkoutButtonKeywors.some((e => t.toLowerCase().includes(e)))
                    }
                    static isCheckoutButtonClassList(t) {
                        var e;
                        const i = s.Tracker.getTruthyLead();
                        return null != i.icCSSMatch && null !== (e = null == t ? void 0 : t.contains(i.icCSSMatch)) && void 0 !== e && e
                    }
                    static isLeadButtonText(t) {
                        var e;
                        console.log("check can send lead: ", t);
                        const i = s.Tracker.getTruthyLead();
                        return null != i.leadTextMatch && null !== (e = null == t ? void 0 : t.includes(i.leadTextMatch)) && void 0 !== e && e
                    }
                    static isAddToCartButtonText(t) {
                        var e;
                        console.log("check can send add to cart: ", t);
                        const i = s.Tracker.getTruthyLead();
                        return null != i.addToCartTextMatch && null !== (e = null == t ? void 0 : t.includes(i.addToCartTextMatch)) && void 0 !== e && e
                    }
                    static isShopify() {
                        var t;
                        const e = null === (t = null === window || void 0 === window ? void 0 : window.BOOMR) || void 0 === t ? void 0 : t.themeName;
                        return null != e && "" !== e
                    }
                    static isElementorButton(t) {
                        return null == t ? void 0 : t.classList.contains("elementor-button")
                    }
                }
                c.inited = !1, c.usedIds = new Set, n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [Boolean]), o("design:returntype", void 0)], c, "monitorButtons", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [Boolean]), o("design:returntype", void 0)], c, "monitorForms", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [Object]), o("design:returntype", String)], c, "getSubmitElementText", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", []), o("design:returntype", void 0)], c, "monitorWindowOpen", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [Boolean]), o("design:returntype", void 0)], c, "monitorLinks", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [Object]), o("design:returntype", Object)], c, "removeInvisibleCharsFromText", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [Object, Object, Object]), o("design:returntype", Boolean)], c, "isCheckoutLink", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [String]), o("design:returntype", Boolean)], c, "isCheckoutButtonText", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [Object]), o("design:returntype", Boolean)], c, "isCheckoutButtonClassList", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [String]), o("design:returntype", Boolean)], c, "isLeadButtonText", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [String]), o("design:returntype", Boolean)], c, "isAddToCartButtonText", null), e.NavigationListener = c, e.checkoutLinkKeywords = ["checkout", "pagamento", "payment", "pay", "kiwify", "hotmart", "eduzz", "monetizze", "vindi", "pague", "comprar", "finalizar", "compra", "cart", "carrinho", "order", "pedido", "confirmar", "confirmacao", "confirmation", "adoorei", "vega", "buygoods", "octuspay", "perfect", "iexperience", "payt", "guru", "green", "yampi", "appmax", "pepper"], e.checkoutButtonKeywors = ["comprar", "finalizar", "compra", "confirmar", "quero ter", "proximo passo", "próximo passo", "inscrição", "inscricao", "participar", "participe", "quero participar", "checkout"]
            },
            562: (t, e) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.Observer = void 0, e.Observer = class {
                    constructor(t) {
                        var e, i;
                        this.mutations = [], this.timer = null, this.setThrottle(null !== (e = t.throttle) && void 0 !== e ? e : 100), this.groupEvents = null !== (i = t.groupEvents) && void 0 !== i && i
                    }
                    observeNewElements(t, e) {
                        this.callback = e, new MutationObserver(((t, e) => {
                            const i = this.groupEvents ? 1 : null;
                            (null == i || this.mutations.length < i) && this.mutations.push({
                                list: t,
                                _observer: e
                            })
                        })).observe(t, {
                            subtree: !0,
                            childList: !0
                        })
                    }
                    setThrottle(t) {
                        var e;
                        this.throttle = t, null === (e = this.timer) || void 0 === e || e.unref(), this.timer = setInterval((() => {
                            this.checkMutations()
                        }), this.throttle)
                    }
                    checkMutations() {
                        const t = this.mutations.length;
                        for (let e = 0; e < t; e++) {
                            const t = this.mutations.shift();
                            t && this.callback(t.list, t._observer)
                        }
                    }
                }
            },
            554: (t, e) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.Phone = void 0, e.Phone = class {
                    static format(t, e = !0) {
                        const i = t.replace(/\D/g, "");
                        let n = i;
                        const o = e ? "55" : "";
                        return e && (i.startsWith("00") ? n = i.substring(2) : i.startsWith("0") && (n = i.substring(1)), 10 === n.length ? n = `55${n.substring(0,2)}9${n.substring(2)}` : 12 === n.length && n.startsWith("55") && (n = `55${n.substring(0,4)}9${n.substring(4)}`)), n.startsWith(o) || (n = `${o}${n}`), n.replace(/^0+/, "")
                    }
                }
            },
            428: function(t, e, i) {
                var n = this && this.__decorate || function(t, e, i, n) {
                        var o, l = arguments.length,
                            r = l < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, i) : n;
                        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(t, e, i, n);
                        else
                            for (var a = t.length - 1; a >= 0; a--)(o = t[a]) && (r = (l < 3 ? o(r) : l > 3 ? o(e, i, r) : o(e, i)) || r);
                        return l > 3 && r && Object.defineProperty(e, i, r), r
                    },
                    o = this && this.__metadata || function(t, e) {
                        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(t, e)
                    },
                    l = this && this.__awaiter || function(t, e, i, n) {
                        return new(i || (i = Promise))((function(o, l) {
                            function r(t) {
                                try {
                                    s(n.next(t))
                                } catch (t) {
                                    l(t)
                                }
                            }

                            function a(t) {
                                try {
                                    s(n.throw(t))
                                } catch (t) {
                                    l(t)
                                }
                            }

                            function s(t) {
                                var e;
                                t.done ? o(t.value) : (e = t.value, e instanceof i ? e : new i((function(t) {
                                    t(e)
                                }))).then(r, a)
                            }
                            s((n = n.apply(t, e || [])).next())
                        }))
                    };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.PixelUtmify = void 0;
                const r = i(370),
                    a = i(186),
                    s = i(937),
                    d = i(792),
                    c = i(923);
                class u {
                    static init(t) {
                        return l(this, void 0, void 0, (function*() {
                            const {
                                metaPixelIds: e,
                                tikTokPixelIds: i
                            } = null != t ? t : {};
                            var n, o, r, a, s, d;
                            "undefined" == typeof fbq && (n = window, o = document, r = "script", n.fbq || (a = n.fbq = function() {
                                a.callMethod ? a.callMethod.apply(a, arguments) : a.queue.push(arguments)
                            }, n._fbq || (n._fbq = a), a.push = a, a.loaded = !0, a.version = "2.0", a.queue = [], (s = o.createElement(r)).async = !0, s.src = "https://connect.facebook.net/en_US/fbevents.js", null == (d = o.getElementsByTagName(r)[0]) || d.parentNode.insertBefore(s, d))), "undefined" == typeof ttq && function(t, e, i) {
                                t.TiktokAnalyticsObject = i;
                                var n = t[i] = t[i] || [];
                                n.methods = ["page", "track", "identify", "instances", "debug", "on", "off", "once", "ready", "alias", "group", "enableCookie", "disableCookie", "holdConsent", "revokeConsent", "grantConsent"], n.setAndDefer = function(t, e) {
                                    t[e] = function() {
                                        t.push([e].concat(Array.prototype.slice.call(arguments, 0)))
                                    }
                                };
                                for (var o = 0; o < n.methods.length; o++) n.setAndDefer(n, n.methods[o]);
                                n.instance = function(t) {
                                    for (var e = n._i[t] || [], i = 0; i < n.methods.length; i++) n.setAndDefer(e, n.methods[i]);
                                    return e
                                }, n.load = function(t, e) {
                                    var o = "https://analytics.tiktok.com/i18n/pixel/events.js";
                                    e && e.partner, n._i = n._i || {}, n._i[t] = [], n._i[t]._u = o, n._t = n._t || {}, n._t[t] = +new Date, n._o = n._o || {}, n._o[t] = e || {}, (e = document.createElement("script")).type = "text/javascript", e.async = !0, e.src = o + "?sdkid=" + t + "&lib=" + i, (t = document.getElementsByTagName("script")[0]).parentNode.insertBefore(e, t)
                                }
                            }(window, document, "ttq"), e && e.length > 0 && (yield Promise.all(e.map((t => l(this, void 0, void 0, (function*() {
                                u.initedMetaPixels.includes(t) || (yield fbq("init", t), u.initedMetaPixels.push(t))
                            })))))), i && i.length > 0 && (yield Promise.all(i.map((t => l(this, void 0, void 0, (function*() {
                                u.initedTikTokPixels.includes(t) || (ttq.load(t), u.initedTikTokPixels.push(t))
                            }))))))
                        }))
                    }
                    static get baseUrl() {
                        return "localhost" === window.location.hostname || "127.0.0.1" === window.location.hostname ? "http://localhost:3001/tracking/v1" : "https://tracking.utmify.com.br/tracking/v1"
                    }
                    static event(t) {
                        var e, i, n, o, r, a, d, c, u, v, p, g, h, f, y, m, b, T, w, k, _, C, x, L, I, F, P, S, M, O, j, A, U, E, B, N, R, D, $, V, q, K, W, z, G, H, J, Y, Z, Q, X, tt, et, it, nt, ot, lt, rt, at, st, dt, ct, ut, vt, pt, gt, ht, ft, yt, mt, bt, Tt;
                        return l(this, void 0, void 0, (function*() {
                            const l = `${this.baseUrl}/events`,
                                wt = yield fetch(l, {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json"
                                    },
                                    body: JSON.stringify(t)
                                }).then((t => t.json()));
                            if (console.log(`response for ${null===(e=t.lead)||void 0===e?void 0:e.pixelId}: ${null===(i=null==wt?void 0:wt.lead)||void 0===i?void 0:i.metaPixelIds}`), null == wt.lead._id) return null;
                            const kt = new s.Lead({
                                _id: wt.lead._id,
                                pixelId: wt.lead.pixelId,
                                userAgent: null !== (o = null === (n = null == t ? void 0 : t.lead) || void 0 === n ? void 0 : n.userAgent) && void 0 !== o ? o : "",
                                locale: null === (r = null == t ? void 0 : t.lead) || void 0 === r ? void 0 : r.locale,
                                birthdate: wt.lead.birthdate,
                                email: wt.lead.email,
                                fbc: wt.lead.fbc,
                                fbp: null === (a = null == t ? void 0 : t.lead) || void 0 === a ? void 0 : a.fbp,
                                gclid: null !== (g = null !== (c = null === (d = null == wt ? void 0 : wt.lead) || void 0 === d ? void 0 : d.gclid) && void 0 !== c ? c : null === (p = null === (v = null === (u = null == wt ? void 0 : wt.event) || void 0 === u ? void 0 : u.log) || void 0 === v ? void 0 : v.leadData) || void 0 === p ? void 0 : p.gclid) && void 0 !== g ? g : null === (h = null == t ? void 0 : t.lead) || void 0 === h ? void 0 : h.gclid,
                                gbraid: null !== (w = null !== (y = null === (f = null == wt ? void 0 : wt.lead) || void 0 === f ? void 0 : f.gbraid) && void 0 !== y ? y : null === (T = null === (b = null === (m = null == wt ? void 0 : wt.event) || void 0 === m ? void 0 : m.log) || void 0 === b ? void 0 : b.leadData) || void 0 === T ? void 0 : T.gbraid) && void 0 !== w ? w : null === (k = null == t ? void 0 : t.lead) || void 0 === k ? void 0 : k.gbraid,
                                wbraid: null !== (F = null !== (C = null === (_ = null == wt ? void 0 : wt.lead) || void 0 === _ ? void 0 : _.wbraid) && void 0 !== C ? C : null === (I = null === (L = null === (x = null == wt ? void 0 : wt.event) || void 0 === x ? void 0 : x.log) || void 0 === L ? void 0 : L.leadData) || void 0 === I ? void 0 : I.wbraid) && void 0 !== F ? F : null === (P = null == t ? void 0 : t.lead) || void 0 === P ? void 0 : P.wbraid,
                                kclid: null !== (U = null !== (M = null === (S = null == wt ? void 0 : wt.lead) || void 0 === S ? void 0 : S.kclid) && void 0 !== M ? M : null === (A = null === (j = null === (O = null == wt ? void 0 : wt.event) || void 0 === O ? void 0 : O.log) || void 0 === j ? void 0 : j.leadData) || void 0 === A ? void 0 : A.kclid) && void 0 !== U ? U : null === (E = null == t ? void 0 : t.lead) || void 0 === E ? void 0 : E.kclid,
                                ttclid: null !== (V = null !== (N = null === (B = null == wt ? void 0 : wt.lead) || void 0 === B ? void 0 : B.ttclid) && void 0 !== N ? N : null === ($ = null === (D = null === (R = null == wt ? void 0 : wt.event) || void 0 === R ? void 0 : R.log) || void 0 === D ? void 0 : D.leadData) || void 0 === $ ? void 0 : $.ttclid) && void 0 !== V ? V : null === (q = null == t ? void 0 : t.lead) || void 0 === q ? void 0 : q.ttclid,
                                ttp: null !== (J = null !== (W = null === (K = null == wt ? void 0 : wt.lead) || void 0 === K ? void 0 : K.ttp) && void 0 !== W ? W : null === (H = null === (G = null === (z = null == wt ? void 0 : wt.event) || void 0 === z ? void 0 : z.log) || void 0 === G ? void 0 : G.leadData) || void 0 === H ? void 0 : H.ttp) && void 0 !== J ? J : null === (Y = null == t ? void 0 : t.lead) || void 0 === Y ? void 0 : Y.ttp,
                                tbclid: null !== (it = null !== (Q = null === (Z = null == wt ? void 0 : wt.lead) || void 0 === Z ? void 0 : Z.tbclid) && void 0 !== Q ? Q : null === (et = null === (tt = null === (X = null == wt ? void 0 : wt.event) || void 0 === X ? void 0 : X.log) || void 0 === tt ? void 0 : tt.leadData) || void 0 === et ? void 0 : et.tbclid) && void 0 !== it ? it : null === (nt = null == t ? void 0 : t.lead) || void 0 === nt ? void 0 : nt.tbclid,
                                firstName: wt.lead.firstName,
                                geolocation: wt.lead.geolocation,
                                ip: wt.lead.ip,
                                ipv6: wt.lead.ipv6,
                                lastName: wt.lead.lastName,
                                metaPixelIds: wt.lead.metaPixelIds,
                                tikTokPixelIds: wt.lead.tikTokPixelIds,
                                phone: wt.lead.phone,
                                parameters: wt.lead.parameters,
                                updatedAt: new Date,
                                icTextMatch: null !== (ot = wt.icTextMatch) && void 0 !== ot ? ot : null,
                                icCSSMatch: null !== (lt = wt.icCSSMatch) && void 0 !== lt ? lt : null,
                                ipConfiguration: wt.ipConfiguration,
                                leadTextMatch: null !== (rt = wt.leadTextMatch) && void 0 !== rt ? rt : null,
                                icURLMatch: null !== (at = wt.icURLMatch) && void 0 !== at ? at : null,
                                addToCartTextMatch: null !== (st = wt.addToCartTextMatch) && void 0 !== st ? st : null
                            });
                            return !1 !== (null == wt ? void 0 : wt.sendWebEvents) && ("PageView" === t.type && (yield this.init({
                                metaPixelIds: kt.metaPixelIds,
                                tikTokPixelIds: kt.tikTokPixelIds
                            })), (null !== (ct = null === (dt = kt.metaPixelIds) || void 0 === dt ? void 0 : dt.length) && void 0 !== ct ? ct : 0) > 0 && this.metaEvent(Object.assign(Object.assign({}, t), {
                                event: {
                                    _id: wt.event._id,
                                    pageTitle: null !== (vt = null === (ut = t.event) || void 0 === ut ? void 0 : ut.pageTitle) && void 0 !== vt ? vt : null,
                                    sourceUrl: null !== (gt = null === (pt = t.event) || void 0 === pt ? void 0 : pt.sourceUrl) && void 0 !== gt ? gt : null
                                }
                            })), (null !== (ft = null === (ht = kt.tikTokPixelIds) || void 0 === ht ? void 0 : ht.length) && void 0 !== ft ? ft : 0) > 0 && this.tikTokEvent(Object.assign(Object.assign({}, t), {
                                event: {
                                    _id: wt.event._id,
                                    pageTitle: null !== (mt = null === (yt = t.event) || void 0 === yt ? void 0 : yt.pageTitle) && void 0 !== mt ? mt : null,
                                    sourceUrl: null !== (Tt = null === (bt = t.event) || void 0 === bt ? void 0 : bt.sourceUrl) && void 0 !== Tt ? Tt : null
                                }
                            }))), kt
                        }))
                    }
                    static updateLead(t) {
                        return l(this, void 0, void 0, (function*() {
                            const e = `${this.baseUrl}/lead`;
                            return !0 === (yield fetch(e, {
                                method: "PUT",
                                headers: {
                                    "Content-Type": "application/json"
                                },
                                body: JSON.stringify(t)
                            }).then((t => t.json())))
                        }))
                    }
                    static getClientIpAddress(t, e, i) {
                        return l(this, void 0, void 0, (function*() {
                            switch (i) {
                                case a.IpConfigurationType.IPV6_ONLY:
                                    return t;
                                case a.IpConfigurationType.IPV6_OR_IPV4:
                                    return t || e;
                                case a.IpConfigurationType.NO_IP:
                                    return;
                                default:
                                    return t || e
                            }
                        }))
                    }
                    static metaEvent(t) {
                        var e, i, n, o, r, a, s, u, v, p, g, h, f, y, m, b, T, w, k, _, C, x, L, I;
                        return l(this, void 0, void 0, (function*() {
                            const l = d.StringUtils.removeAllNonAlphaChars(null !== (n = null === (i = null === (e = t.lead) || void 0 === e ? void 0 : e.geolocation) || void 0 === i ? void 0 : i.city) && void 0 !== n ? n : void 0),
                                F = d.StringUtils.removeAllNonAlphaChars(null !== (a = null === (r = null === (o = t.lead) || void 0 === o ? void 0 : o.geolocation) || void 0 === r ? void 0 : r.state) && void 0 !== a ? a : void 0),
                                P = d.StringUtils.removeAllNonAlhaNumericChars(null !== (v = null === (u = null === (s = t.lead) || void 0 === s ? void 0 : s.geolocation) || void 0 === u ? void 0 : u.zipcode) && void 0 !== v ? v : void 0),
                                S = d.StringUtils.removeAllNonAlphaAccentChars(null === (p = t.lead) || void 0 === p ? void 0 : p.firstName),
                                M = d.StringUtils.removeAllNonAlphaAccentChars(null === (g = t.lead) || void 0 === g ? void 0 : g.lastName),
                                O = yield this.getClientIpAddress(null === (h = t.lead) || void 0 === h ? void 0 : h.ipv6, null === (f = t.lead) || void 0 === f ? void 0 : f.ip, null === (y = t.lead) || void 0 === y ? void 0 : y.ipConfiguration);
                            fbq("track", t.type, {
                                event_time: c.Utils.getEventTime(),
                                event_day: c.Utils.getEventDay(),
                                event_day_in_month: c.Utils.getEventDayInMonth(),
                                event_month: c.Utils.getEventMonth(),
                                event_time_interval: c.Utils.getEventTimeInterval(),
                                event_url: window.location.href,
                                event_source_url: window.location.href,
                                traffic_source: document.referrer,
                                ct: yield c.Utils.hashValue(l), st: yield c.Utils.hashValue(F), zp: yield c.Utils.hashValue(P), client_user_agent: null === (m = t.lead) || void 0 === m ? void 0 : m.userAgent, client_ip_address: O, country: yield c.Utils.hashValue(null !== (w = null === (T = null === (b = t.lead) || void 0 === b ? void 0 : b.geolocation) || void 0 === T ? void 0 : T.country) && void 0 !== w ? w : void 0), external_id: null === (k = t.lead) || void 0 === k ? void 0 : k._id, fn: yield c.Utils.hashValue(S), ln: yield c.Utils.hashValue(M), em: yield c.Utils.hashValue(null === (_ = null == t ? void 0 : t.lead) || void 0 === _ ? void 0 : _.email), ph: yield c.Utils.hashValue(null === (C = null == t ? void 0 : t.lead) || void 0 === C ? void 0 : C.phone), fbc: null === (x = t.lead) || void 0 === x ? void 0 : x.fbc, fbp: null === (L = t.lead) || void 0 === L ? void 0 : L.fbp, content_type: "product", page_title: document.title
                            }, {
                                eventID: null === (I = t.event) || void 0 === I ? void 0 : I._id
                            })
                        }))
                    }
                    static tikTokEvent(t) {
                        var e, i;
                        return l(this, void 0, void 0, (function*() {
                            "PageView" === t.type ? ttq.page({
                                event_id: null === (e = t.event) || void 0 === e ? void 0 : e._id
                            }) : ttq.track(t.type, {
                                content_type: "product"
                            }, {
                                event_id: null === (i = t.event) || void 0 === i ? void 0 : i._id
                            })
                        }))
                    }
                }
                u.initedMetaPixels = [], u.initedTikTokPixels = [], n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [Object, Object, Object]), o("design:returntype", Promise)], u, "getClientIpAddress", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [Object]), o("design:returntype", Promise)], u, "metaEvent", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [Object]), o("design:returntype", Promise)], u, "tikTokEvent", null), e.PixelUtmify = u
            },
            792: (t, e) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.StringUtils = void 0, e.StringUtils = class {
                    static removeAllNonAlphaAccentChars(t) {
                        return null != t ? t.replace(/[0-9]/g, "").replace(/[^a-zA-ZÀ-ÿ\s]/g, "").replace(/[^a-zA-ZÀ-ÿ]/g, "").toLowerCase() : void 0
                    }
                    static removeAllNonAlphaChars(t) {
                        return null != t ? t.replace(/[^a-zA-Z]/g, "").toLowerCase() : void 0
                    }
                    static removeAllNonAlhaNumericChars(t) {
                        return null != t ? t.replace(/[^a-zA-Z0-9]/g, "").toLowerCase() : void 0
                    }
                }
            },
            526: function(t, e, i) {
                var n = this && this.__decorate || function(t, e, i, n) {
                        var o, l = arguments.length,
                            r = l < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, i) : n;
                        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(t, e, i, n);
                        else
                            for (var a = t.length - 1; a >= 0; a--)(o = t[a]) && (r = (l < 3 ? o(r) : l > 3 ? o(e, i, r) : o(e, i)) || r);
                        return l > 3 && r && Object.defineProperty(e, i, r), r
                    },
                    o = this && this.__metadata || function(t, e) {
                        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(t, e)
                    },
                    l = this && this.__awaiter || function(t, e, i, n) {
                        return new(i || (i = Promise))((function(o, l) {
                            function r(t) {
                                try {
                                    s(n.next(t))
                                } catch (t) {
                                    l(t)
                                }
                            }

                            function a(t) {
                                try {
                                    s(n.throw(t))
                                } catch (t) {
                                    l(t)
                                }
                            }

                            function s(t) {
                                var e;
                                t.done ? o(t.value) : (e = t.value, e instanceof i ? e : new i((function(t) {
                                    t(e)
                                }))).then(r, a)
                            }
                            s((n = n.apply(t, e || [])).next())
                        }))
                    };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.Tracker = void 0;
                const r = i(370),
                    a = i(937),
                    s = i(568),
                    d = i(75),
                    c = i(865),
                    u = i(8),
                    v = i(774),
                    p = i(428),
                    g = i(436);
                class h {
                    static get leadKey() {
                        return "Meta" === this.type ? "lead" : "Google" === this.type ? "lead-google" : "Kwai" === this.type ? "lead-kwai" : "Taboola" === this.type ? "lead-taboola" : "lead-tiktok"
                    }
                    static get pixelId() {
                        return "Meta" === this.type ? window.pixelId : "Google" === this.type ? window.googlePixelId : "Kwai" === this.type ? window.kwaiPixelId : "TikTok" === this.type ? window.tikTokPixelId : window.taboolaPixelId
                    }
                    static init(t) {
                        return l(this, void 0, void 0, (function*() {
                            if (console.log("Tracker.inited?:", this.inited), this.inited) return;
                            this.inited = !0, this.type = t;
                            const [e, i] = yield Promise.all([u.Ips.getIpv4({
                                timeoutMs: 5e3
                            }), u.Ips.getIpv6({
                                timeoutMs: 5e3
                            })]);
                            h.ipv4 = e, h.ipv6 = i, c.FormsListener.init(), v.NavigationListener.init(), h.track("PageView"), g.ViewContentListener.init(), "Meta" === this.type && (yield h.trySendFbp())
                        }))
                    }
                    static trySendFbp() {
                        return l(this, void 0, void 0, (function*() {
                            const t = () => l(this, void 0, void 0, (function*() {
                                const t = h.getTruthyLead();
                                (null == t ? void 0 : t._id) && t.fbp && (yield p.PixelUtmify.updateLead({
                                    _id: t._id,
                                    fbp: t.fbp
                                })) && s.AppStorage.save(h.leadKey, t)
                            }));
                            setTimeout(t, 2500), setTimeout(t, 5e3)
                        }))
                    }
                    static track(t) {
                        return l(this, void 0, void 0, (function*() {
                            if (this.trackedEvents.includes(t)) return;
                            this.trackedEvents.push(t);
                            const e = this.getTruthyLead(),
                                i = yield p.PixelUtmify.event({
                                    type: t,
                                    lead: e,
                                    event: this.getEventData(),
                                    tikTokPageInfo: "TikTok" === this.type ? {
                                        url: window.location.href,
                                        referrer: document.referrer || null
                                    } : null
                                });
                            s.AppStorage.save(this.leadKey, i)
                        }))
                    }
                    static getTruthyLead() {
                        const t = h.getLeadFromLocalStorageOrNew();
                        return h.getLeadWithBasicFields(t)
                    }
                    static getLeadFromLocalStorageOrNew() {
                        return s.AppStorage.load(this.leadKey) || new a.Lead({
                            pixelId: this.pixelId,
                            userAgent: navigator.userAgent,
                            icTextMatch: null,
                            icCSSMatch: null,
                            icURLMatch: null,
                            leadTextMatch: null,
                            addToCartTextMatch: null
                        })
                    }
                    static getLeadWithBasicFields(t) {
                        const e = h.getFbc(t),
                            i = h.getFbp(t),
                            n = h.getGclid(t),
                            o = h.getGbraid(t),
                            l = h.getWbraid(t),
                            r = h.getKclid(t),
                            a = h.getTtclid(t),
                            s = h.getTtp(t),
                            d = h.getTbclid(t);
                        return Object.assign(Object.assign({}, t), {
                            fbc: e,
                            fbp: i,
                            gclid: n,
                            gbraid: o,
                            wbraid: l,
                            kclid: r,
                            ttclid: a,
                            ttp: s,
                            tbclid: d,
                            parameters: window.location.search,
                            locale: "TikTok" === this.type && navigator.language || void 0,
                            ip: h.ipv4,
                            ipv6: h.ipv6
                        })
                    }
                    static getFbc(t) {
                        var e;
                        if (t.fbc) return t.fbc;
                        const i = null !== (e = new URLSearchParams(window.location.search).get("fbclid")) && void 0 !== e ? e : void 0,
                            n = i ? d.FBC.fromClid(i) : void 0,
                            o = null == n ? void 0 : n.formatted();
                        if (o) return o;
                        return s.AppStorage.getFbc() || o
                    }
                    static getFbp(t) {
                        return t.fbp ? t.fbp : s.AppStorage.getFbp()
                    }
                    static getGclid(t) {
                        var e;
                        return t.gclid ? t.gclid : null !== (e = new URLSearchParams(window.location.search).get("gclid")) && void 0 !== e ? e : void 0
                    }
                    static getGbraid(t) {
                        var e;
                        return t.gbraid ? t.gbraid : null !== (e = new URLSearchParams(window.location.search).get("gbraid")) && void 0 !== e ? e : void 0
                    }
                    static getWbraid(t) {
                        var e;
                        return t.wbraid ? t.wbraid : null !== (e = new URLSearchParams(window.location.search).get("wbraid")) && void 0 !== e ? e : void 0
                    }
                    static getKclid(t) {
                        var e, i;
                        return t.kclid ? t.kclid : null != (null !== (e = new URLSearchParams(window.location.search).get("CampaignID")) && void 0 !== e ? e : void 0) && null !== (i = new URLSearchParams(window.location.search).get("click_id")) && void 0 !== i ? i : void 0
                    }
                    static getTtclid(t) {
                        var e;
                        return t.ttclid ? t.ttclid : null !== (e = new URLSearchParams(window.location.search).get("ttclid")) && void 0 !== e ? e : void 0
                    }
                    static getTtp(t) {
                        return t.ttp ? t.ttp : s.AppStorage.getTtp()
                    }
                    static getTbclid(t) {
                        var e;
                        return t.tbclid ? t.tbclid : null !== (e = new URLSearchParams(window.location.search).get("tbclid")) && void 0 !== e ? e : void 0
                    }
                    static getEventData() {
                        var t;
                        try {
                            if ("undefined" == typeof window || "undefined" == typeof document) return {
                                sourceUrl: null,
                                pageTitle: null
                            };
                            const {
                                protocol: e,
                                hostname: i,
                                pathname: n
                            } = window.location || {};
                            return {
                                sourceUrl: "string" == typeof e && "string" == typeof i && "string" == typeof n ? `${e}//${i}${n}`.replace(/\/+$/, "") : null,
                                pageTitle: (null === (t = document.title) || void 0 === t ? void 0 : t.trim()) || null
                            }
                        } catch (t) {
                            return {
                                sourceUrl: null,
                                pageTitle: null
                            }
                        }
                    }
                }
                h.inited = !1, h.type = "Meta", h.trackedEvents = [], n([r.visibleForTesting, o("design:type", String), o("design:paramtypes", [])], h, "pixelId", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", []), o("design:returntype", a.Lead)], h, "getLeadFromLocalStorageOrNew", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [a.Lead]), o("design:returntype", a.Lead)], h, "getLeadWithBasicFields", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [a.Lead]), o("design:returntype", Object)], h, "getFbc", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [a.Lead]), o("design:returntype", Object)], h, "getFbp", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [a.Lead]), o("design:returntype", Object)], h, "getGclid", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [a.Lead]), o("design:returntype", Object)], h, "getGbraid", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [a.Lead]), o("design:returntype", Object)], h, "getWbraid", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [a.Lead]), o("design:returntype", Object)], h, "getKclid", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [a.Lead]), o("design:returntype", Object)], h, "getTtclid", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [a.Lead]), o("design:returntype", Object)], h, "getTtp", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", [a.Lead]), o("design:returntype", Object)], h, "getTbclid", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", []), o("design:returntype", Object)], h, "getEventData", null), e.Tracker = h
            },
            923: function(t, e) {
                var i = this && this.__awaiter || function(t, e, i, n) {
                    return new(i || (i = Promise))((function(o, l) {
                        function r(t) {
                            try {
                                s(n.next(t))
                            } catch (t) {
                                l(t)
                            }
                        }

                        function a(t) {
                            try {
                                s(n.throw(t))
                            } catch (t) {
                                l(t)
                            }
                        }

                        function s(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof i ? e : new i((function(t) {
                                t(e)
                            }))).then(r, a)
                        }
                        s((n = n.apply(t, e || [])).next())
                    }))
                };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.Utils = void 0;
                class n {
                    static hashValue(t) {
                        return i(this, void 0, void 0, (function*() {
                            if (t && t.length) {
                                if (crypto && crypto.subtle) {
                                    const e = (new TextEncoder).encode(t),
                                        i = yield crypto.subtle.digest("SHA-256", e);
                                    return Array.from(new Uint8Array(i)).map((t => t.toString(16).padStart(2, "0"))).join("")
                                }
                                return sha256 || (yield n.loadScript("https://cdn.jsdelivr.net/npm/js-sha256/src/sha256.min.js")), sha256(t)
                            }
                        }))
                    }
                    static loadScript(t) {
                        return i(this, void 0, void 0, (function*() {
                            return new Promise(((e, i) => {
                                const n = document.createElement("script");
                                n.src = t, n.onload = e, n.onerror = i, document.head.appendChild(n)
                            }))
                        }))
                    }
                    static wait(t) {
                        return new Promise((e => {
                            setTimeout(e, t)
                        }))
                    }
                    static getEventTime() {
                        const t = new Date,
                            e = Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), t.getUTCDate(), t.getUTCHours(), t.getUTCMinutes(), t.getUTCSeconds(), t.getUTCMilliseconds());
                        return Math.floor(e / 1e3)
                    }
                    static getEventDayInMonth() {
                        return (new Date).getDate()
                    }
                    static getEventDay() {
                        return ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][(new Date).getDay()]
                    }
                    static getEventMonth() {
                        return ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"][(new Date).getMonth()]
                    }
                    static getEventTimeInterval() {
                        const t = (new Date).getHours();
                        return `${t}-${t+1}`
                    }
                    static getCookieByNames(...t) {
                        for (const e of t) {
                            const t = e,
                                i = n.getCookieFromStorage(t);
                            if (i) return i
                        }
                        for (const e of t) {
                            const t = e,
                                i = n.getCookieFromUrl(t);
                            if (i) return i
                        }
                        return null
                    }
                    static getCookieFromStorage(t) {
                        const e = document.cookie.split(";");
                        for (const i of e) {
                            const [e, n] = i.trim().split("=");
                            if (e === t) return n
                        }
                        return null
                    }
                    static getCookieFromUrl(...t) {
                        const e = new URLSearchParams(window.location.search);
                        for (const i of t)
                            if (e.has(i)) return e.get(i);
                        return null
                    }
                    static getId(t) {
                        if (t.id) return t.id;
                        const e = n.uuid();
                        return t.id = e, e
                    }
                    static uuid() {
                        const t = () => Math.floor(65536 * (1 + Math.random())).toString(16).substring(1);
                        return `${t()+t()}-${t()}-${t()}-${t()}-${t()+t()+t()}`
                    }
                }
                e.Utils = n
            },
            436: function(t, e, i) {
                var n = this && this.__decorate || function(t, e, i, n) {
                        var o, l = arguments.length,
                            r = l < 3 ? e : null === n ? n = Object.getOwnPropertyDescriptor(e, i) : n;
                        if ("object" == typeof Reflect && "function" == typeof Reflect.decorate) r = Reflect.decorate(t, e, i, n);
                        else
                            for (var a = t.length - 1; a >= 0; a--)(o = t[a]) && (r = (l < 3 ? o(r) : l > 3 ? o(e, i, r) : o(e, i)) || r);
                        return l > 3 && r && Object.defineProperty(e, i, r), r
                    },
                    o = this && this.__metadata || function(t, e) {
                        if ("object" == typeof Reflect && "function" == typeof Reflect.metadata) return Reflect.metadata(t, e)
                    },
                    l = this && this.__awaiter || function(t, e, i, n) {
                        return new(i || (i = Promise))((function(o, l) {
                            function r(t) {
                                try {
                                    s(n.next(t))
                                } catch (t) {
                                    l(t)
                                }
                            }

                            function a(t) {
                                try {
                                    s(n.throw(t))
                                } catch (t) {
                                    l(t)
                                }
                            }

                            function s(t) {
                                var e;
                                t.done ? o(t.value) : (e = t.value, e instanceof i ? e : new i((function(t) {
                                    t(e)
                                }))).then(r, a)
                            }
                            s((n = n.apply(t, e || [])).next())
                        }))
                    };
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.ViewContentListener = void 0;
                const r = i(370),
                    a = i(526),
                    s = i(923);
                class d {
                    static init() {
                        d.trackByTime(), d.trackByScroll()
                    }
                    static trackByTime() {
                        return l(this, void 0, void 0, (function*() {
                            yield s.Utils.wait(8e3), a.Tracker.track("ViewContent")
                        }))
                    }
                    static trackByScroll() {
                        return l(this, void 0, void 0, (function*() {
                            window.addEventListener("scroll", (() => l(this, void 0, void 0, (function*() {
                                console.log("scrolling", window.scrollY), window.scrollY > 100 && a.Tracker.track("ViewContent")
                            }))))
                        }))
                    }
                }
                n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", []), o("design:returntype", Promise)], d, "trackByTime", null), n([r.visibleForTesting, o("design:type", Function), o("design:paramtypes", []), o("design:returntype", Promise)], d, "trackByScroll", null), e.ViewContentListener = d
            },
            119: (t, e) => {
                var i;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.InputType = void 0, (i = e.InputType || (e.InputType = {})).Name = "Name", i.Email = "Email", i.Phone = "Phone", i.Unknown = "Unknown"
            },
            186: (t, e) => {
                var i;
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.IpConfigurationType = void 0, (i = e.IpConfigurationType || (e.IpConfigurationType = {})).IPV6_ONLY = "IPV6_ONLY", i.IPV6_OR_IPV4 = "IPV6_OR_IPV4", i.NO_IP = "NO_IP"
            },
            937: (t, e) => {
                Object.defineProperty(e, "__esModule", {
                    value: !0
                }), e.Lead = void 0, e.Lead = class {
                    constructor(t) {
                        this.pixelId = t.pixelId, this._id = t._id, this.email = t.email, this.firstName = t.firstName, this.lastName = t.lastName, this.phone = t.phone, this.birthdate = t.birthdate, this.metaPixelIds = t.metaPixelIds, this.tikTokPixelIds = t.tikTokPixelIds, this.geolocation = t.geolocation, this.userAgent = t.userAgent, this.locale = t.locale, this.ip = t.ip, this.ipv6 = t.ipv6, this.fbc = t.fbc, this.fbp = t.fbp, this.gclid = t.gclid, this.gbraid = t.gbraid, this.wbraid = t.wbraid, this.kclid = t.kclid, this.ttclid = t.ttclid, this.ttp = t.ttp, this.tbclid = t.tbclid, this.parameters = t.parameters, this.updatedAt = t.updatedAt, this.icTextMatch = t.icTextMatch, this.icCSSMatch = t.icCSSMatch, this.icURLMatch = t.icURLMatch, this.leadTextMatch = t.leadTextMatch, this.addToCartTextMatch = t.addToCartTextMatch, this.ipConfiguration = t.ipConfiguration
                    }
                }
            }
        },
        e = {};

    function i(n) {
        var o = e[n];
        if (void 0 !== o) return o.exports;
        var l = e[n] = {
            exports: {}
        };
        return t[n].call(l.exports, l, l.exports, i), l.exports
    }(() => {
        const t = i(526);
        console.log("Tracker Meta version 1.6.1"), t.Tracker.init("Meta")
    })()
})();