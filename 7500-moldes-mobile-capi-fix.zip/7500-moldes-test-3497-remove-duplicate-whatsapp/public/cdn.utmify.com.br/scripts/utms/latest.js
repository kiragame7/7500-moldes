(() => {
    "use strict";
    var e = {
            262: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.Random = void 0, t.Random = class {
                    static chooseOne(e) {
                        return e[Math.floor(Math.random() * e.length)]
                    }
                }
            },
            745: (e, t) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.UnicodeHasher = void 0;
                class r {
                    static encode(e) {
                        return e.replace(/[0-9a-f]/g, (e => r.map[e]))
                    }
                    static decode(e) {
                        const t = Object.values(r.map).join(""),
                            n = new RegExp(`[${t}]`, "g");
                        return e.replace(n, (e => Object.keys(r.map).find((t => r.map[t] === e)) || ""))
                    }
                    static encodeAndInsert(e, t, n, l = 1) {
                        var i;
                        const a = [...e.map((e => r.encode(null != e ? e : ""))), n && (null === (i = r.adPlatformsSequencesMap[n]) || void 0 === i ? void 0 : i.join("")) || ""].join(r.HASH_SEPARATOR);
                        return `${t.slice(0,l)}${a}${t.slice(l)}`
                    }
                    static decodeAndExtract(e) {
                        if (!e) return [];
                        const t = Object.values(r.map).join(""),
                            n = new RegExp(`[${t}]`, "g");
                        return e.split(r.HASH_SEPARATOR).map((e => {
                            const t = Object.keys(r.adPlatformsSequencesMap).find((t => {
                                const n = r.adPlatformsSequencesMap[t].join("");
                                return new RegExp(n, "g").test(e)
                            }));
                            if (t) return t;
                            let l = "";
                            return e.replace(n, (e => {
                                const t = Object.keys(r.map).find((t => r.map[t] === e));
                                return t && (l += t), e
                            })), "" !== l ? l : null
                        }))
                    }
                    static removeAllEncodedChars(e) {
                        const t = Object.values(r.map).join(""),
                            n = [new RegExp(`[${t}]`, "g"), new RegExp(r.HASH_SEPARATOR, "g"), ...Object.values(r.adPlatformsSequencesMap).map((e => new RegExp(e.join(""), "g")))];
                        let l = e;
                        return n.forEach((e => {
                            l = l.replace(e, "")
                        })), l
                    }
                }
                t.UnicodeHasher = r, r.HASH_SEPARATOR = "⁬⁭⁬⁭", r.map = {
                    0: "​",
                    1: "‌",
                    2: "‍",
                    3: "⁠",
                    4: "⁡",
                    5: "⁢",
                    6: "⁣",
                    7: "⁤",
                    8: "‪",
                    9: "‬",
                    a: "⁦",
                    b: "͏",
                    c: "⁨",
                    d: "⁩",
                    e: "⁪",
                    f: "⁫"
                }, r.adPlatformsSequencesMap = {
                    meta: ["⁮", "⁯", "឴", "឵"],
                    google: ["឴", "឵", "឵", "឴", "\ufeff", "؜"],
                    kwai: ["؜", "\ufeff", "⁯", "⁮"],
                    tiktok: ["؜", "឵", "⁯", "؜", "\ufeff", "⁯"],
                    taboola: ["⁯", "⁮", "؜", "឵", "឵", "឴", "⁮"]
                }
            },
            202: (e, t, r) => {
                Object.defineProperty(t, "__esModule", {
                    value: !0
                }), t.UrlRebuilder = void 0;
                const n = r(262),
                    l = r(745);
                class i {
                    static randomizePhoneNumberIfNecessary(e) {
                        var t;
                        const r = null !== (t = window.phones) && void 0 !== t ? t : [];
                        if (0 === r.length) return e;
                        const l = n.Random.chooseOne(r);
                        return e.includes("phone=") ? i.withReplaceQueryParam(e, "phone", l) : e.includes("wa.me") ? `https://wa.me/${l}?${e.split("?")[1]}` : e
                    }
                    static insertAdIdInWppUrl(e, t, r, n) {
                        var a;
                        const o = null !== (a = i.getQueryParams(e).get("text")) && void 0 !== a ? a : "Olá",
                            s = t.replace(/[^0-9]/g, ""),
                            u = l.UnicodeHasher.removeAllEncodedChars(o),
                            c = l.UnicodeHasher.encodeAndInsert([s, r], u, n);
                        return i.withReplaceQueryParam(e, "text", c)
                    }
                    static getAdId(e) {
                        var t, r, n;
                        const l = null !== (n = null === (r = null === (t = e.get("utm_content")) || void 0 === t ? void 0 : t.split("::")) || void 0 === r ? void 0 : r[0]) && void 0 !== n ? n : "";
                        return l.includes("|") ? l.split("|")[1] : l.match(/^\d+$/) ? l : null
                    }
                    static getTrackingSource(e) {
                        var t, r, n;
                        const l = null === (t = e.get("utm_source")) || void 0 === t ? void 0 : t.toLowerCase(),
                            i = null === (r = e.get("src")) || void 0 === r ? void 0 : r.toLowerCase(),
                            a = null === (n = e.get("utm_term")) || void 0 === n ? void 0 : n.toLowerCase(),
                            o = ["facebook", "fb", "face", "Instagram_Stories", "Instagram_Stories", "Instagram_Feed"],
                            s = ["google", "gclid", "googleads", "adwords", "youtube.com"],
                            u = (e, t) => t.some((t => null == e ? void 0 : e.toLowerCase().includes(t.toLowerCase()))),
                            c = u(l, o) || u(i, o) || u(a, o),
                            d = u(l, s) || u(i, s) || u(a, s),
                            m = u(l, ["kwai"]),
                            v = u(l, ["tiktok"]),
                            p = u(l, ["taboola"]);
                        return c ? "meta" : d ? "google" : m ? "kwai" : v ? "tiktok" : p ? "taboola" : null
                    }
                    static getQueryParams(e) {
                        const t = e.split("?")[1];
                        return new URLSearchParams(t)
                    }
                    static withReplaceQueryParam(e, t, r) {
                        const n = e.split("?")[0],
                            l = e.split("?")[1],
                            i = new URLSearchParams(l);
                        return i.set(t, r), `${n}?${i.toString()}`
                    }
                    static removeSpecialCharacteres(e) {
                        return e.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\w\s-|]/gi, "").replace(/\s/g, "")
                    }
                }
                t.UrlRebuilder = i
            }
        },
        t = {};

    function r(n) {
        var l = t[n];
        if (void 0 !== l) return l.exports;
        var i = t[n] = {
            exports: {}
        };
        return e[n](i, i.exports, r), i.exports
    }(() => {
        var e, t, n, l;
        const i = r(202),
            a = {
                ignoreAllIframes: !!document.querySelector("[data-utmify-ignore-iframe]"),
                ignoreScriptRetry: !!document.querySelector("[data-utmify-ignore-retry]"),
                fastStart: !!document.querySelector("[data-utmify-fast-start]"),
                replacePlusSignal: !!document.querySelector("[data-utmify-plus-signal]"),
                isClickBank: !!document.querySelector("[data-utmify-is-click-bank]"),
                preventSubIds: !!document.querySelector("[data-utmify-prevent-subids]"),
                fixShopifyTheme: !!document.querySelector("[data-utmify-fix-shopify-theme]"),
                ignoreClasses: null === (n = null === (t = null === (e = document.querySelector("[data-utmify-ignore-classes]")) || void 0 === e ? void 0 : e.getAttribute("data-utmify-ignore-classes")) || void 0 === t ? void 0 : t.split(" ")) || void 0 === n ? void 0 : n.filter((e => !!e)),
                replaceLinks: null === (l = document.querySelector("[data-utmify-replace-links]")) || void 0 === l ? void 0 : l.getAttribute("data-utmify-replace-links"),
                isCartpanda: !!document.querySelector("[data-utmify-is-cartpanda]"),
                preventXcodSck: !!document.querySelector("[data-utmify-prevent-xcod-sck]"),
                preventClickIdsFallback: !!document.querySelector("[data-utmify-prevent-click-ids-fallback]"),
                isStripe: !!document.querySelector("[data-utmify-is-stripe]"),
                isEverflow: !!document.querySelector("[data-utmify-is-everflow]"),
                isNuvemShop: !!document.querySelector("[data-utmify-is-nuvem-shop]")
            };
        var o, s;
        ! function(e) {
            e.Doppus = "doppus"
        }(o || (o = {})),
        function(e) {
            e.PandaVideo = "pandavideo.com", e.YouTube = "youtube.com", e.EplayVideo = "eplay.video", e.Vimeo = "vimeo.com"
        }(s || (s = {}));
        const u = ["utm_source", "utm_campaign", "utm_medium", "utm_content", "utm_term"];
        class c {
            static getLeadIdFromSearchParams(e) {
                var t, r;
                const n = e.get("utm_source");
                return null !== (r = null === (t = null == n ? void 0 : n.split(c.LEAD_ID_SEPARATOR)) || void 0 === t ? void 0 : t[1]) && void 0 !== r ? r : null
            }
            static getLeadIdFromStorage() {
                var e, t, r, n, l;
                const i = null !== (n = null !== (r = null !== (t = null !== (e = localStorage.getItem("lead")) && void 0 !== e ? e : localStorage.getItem("lead-google")) && void 0 !== t ? t : localStorage.getItem("lead-kwai")) && void 0 !== r ? r : localStorage.getItem("lead-tiktok")) && void 0 !== n ? n : localStorage.getItem("lead-taboola");
                if (!i) return null;
                const a = JSON.parse(i);
                return null !== (l = null == a ? void 0 : a._id) && void 0 !== l ? l : null
            }
            static addUtmParametersToUrl(e) {
                const t = c.urlWithoutParams(e),
                    r = c.paramsFromUrl(e),
                    n = c.getUtmParameters(),
                    l = new URLSearchParams;
                r.forEach(((e, t) => l.append(t, e))), n.forEach(((e, t) => l.append(t, e)));
                const i = c.urlParametersWithoutDuplicates(l),
                    o = c.simplifyParametersIfNecessary(t, i),
                    s = a.replacePlusSignal ? o.toString().split("+").join("%20") : o.toString(),
                    u = -1 === t.indexOf("?") ? "?" : "&";
                return `${t}${u}${s}`
            }
            static urlWithoutParams(e) {
                return e.split("?")[0]
            }
            static paramsFromUrl(e) {
                if (!e) return new URLSearchParams;
                const t = e instanceof URL ? e.href : e;
                if (!t.includes("?")) return new URLSearchParams;
                const r = t.split("?");
                if (r.length <= 1) return new URLSearchParams;
                const n = r[1];
                return new URLSearchParams(n)
            }
            static urlParametersWithoutDuplicates(e) {
                const t = Array.from(e.keys()),
                    r = new Map;
                t.forEach((t => {
                    const n = e.getAll(t);
                    r.set(t, n[n.length - 1])
                }));
                const n = new URLSearchParams;
                return r.forEach(((e, t) => {
                    n.append(t, e)
                })), n
            }
            static getUtmParameters() {
                var e, t, r, n, l, o, s, u, d, v;
                const p = new URLSearchParams(window.location.search);

                function f(e) {
                    const t = p.get(e);
                    if (null != t && "null" !== t && "undefined" !== t && "" !== t) return t;
                    const r = localStorage.getItem(e);
                    if (!r) return "";
                    const n = localStorage.getItem(m(e));
                    return !n || new Date(n) < new Date ? (localStorage.removeItem(e), localStorage.removeItem(m(e)), "") : r
                }

                function _(e, t) {
                    return e.join(t)
                }

                function g(e) {
                    const t = c.getLeadIdFromStorage();
                    return t ? e.includes(c.LEAD_ID_SEPARATOR) ? e : `${e}${c.LEAD_ID_SEPARATOR}${t}` : e
                }
                const S = f("utm_term"),
                    h = f("keyword");
                let R = S;
                const A = null == S ? void 0 : S.includes(`${c.GOOGLE_KEYWORD_SEPARATOR}${h}`);
                h && !A && (R = null != S ? `${S}${c.GOOGLE_KEYWORD_SEPARATOR}${h}` : `${c.GOOGLE_KEYWORD_SEPARATOR}${h}`);
                let b = f("utm_content"),
                    I = f("utm_medium"),
                    w = f("utm_campaign"),
                    y = g(f("utm_source"));
                const P = f("gclid"),
                    C = f("gbraid"),
                    E = f("wbraid"),
                    O = f("ttclid"),
                    T = f("tbclid"),
                    U = new URLSearchParams,
                    L = f("cid");
                a.isCartpanda ? U.set("cid", L || Math.round(1e11 * Math.random()).toString()) : L && U.set("cid", L), U.set("utm_source", y), U.set("utm_campaign", w), U.set("utm_medium", I), U.set("utm_content", b), U.set("utm_term", R);
                const k = f("CampaignID"),
                    D = f("adSETID"),
                    $ = f("CreativeID"),
                    j = f("click_id"),
                    x = f("pixel_id"),
                    q = e => null != e && "" !== e;
                if (q(k) && q(D) && q($) && (y = g("kwai"), w = (null == w ? void 0 : w.includes(k)) ? w : k, I = (null == I ? void 0 : I.includes(D)) ? I : D, b = (null == b ? void 0 : b.includes($)) ? b : a.preventClickIdsFallback ? $ : [$, j, x].join(c.CLICK_ID_SEPARATOR), U.set("utm_source", y), U.set("utm_campaign", w), U.set("utm_medium", I), U.set("utm_content", b)), a.isNuvemShop) {
                    const e = e => {
                        var t, r;
                        const n = null !== (r = null === (t = null == e ? void 0 : e.split(c.CLICK_ID_SEPARATOR)) || void 0 === t ? void 0 : t[0]) && void 0 !== r ? r : "";
                        return n.includes("|") ? n.substring(n.lastIndexOf("|") + 1) : n
                    };
                    w = e(w), I = e(I), b = e(b), U.set("utm_campaign", w), U.set("utm_medium", I), U.set("utm_content", b)
                }
                a.isClickBank ? (U.set("aff_sub1", i.UrlRebuilder.removeSpecialCharacteres(y)), U.set("aff_sub2", i.UrlRebuilder.removeSpecialCharacteres(w).replace(/[a-zA-Z_]/g, "").replace(/\|(?=\d{10,}$)(?!.*\|)/, "cKBk")), U.set("aff_sub3", i.UrlRebuilder.removeSpecialCharacteres(I).replace(/[a-zA-Z_]/g, "").replace(/\|(?=\d{10,}$)(?!.*\|)/, "cKBk")), U.set("aff_sub4", i.UrlRebuilder.removeSpecialCharacteres(null !== (t = null === (e = null == b ? void 0 : b.split(c.CLICK_ID_SEPARATOR)) || void 0 === e ? void 0 : e[0]) && void 0 !== t ? t : "").replace(/[a-zA-Z_]/g, "").replace(/\|(?=\d{10,}$)(?!.*\|)/, "cKBk")), U.set("aff_sub5", i.UrlRebuilder.removeSpecialCharacteres(R)), U.set("unique_aff_sub1", i.UrlRebuilder.removeSpecialCharacteres(y)), U.set("unique_aff_sub2", i.UrlRebuilder.removeSpecialCharacteres(w).replace(/[a-zA-Z_]/g, "").replace(/\|(?=\d{10,}$)(?!.*\|)/, "cKBk")), U.set("unique_aff_sub3", i.UrlRebuilder.removeSpecialCharacteres(I).replace(/[a-zA-Z_]/g, "").replace(/\|(?=\d{10,}$)(?!.*\|)/, "cKBk")), U.set("unique_aff_sub4", i.UrlRebuilder.removeSpecialCharacteres(null !== (n = null === (r = null == b ? void 0 : b.split(c.CLICK_ID_SEPARATOR)) || void 0 === r ? void 0 : r[0]) && void 0 !== n ? n : "").replace(/[a-zA-Z_]/g, "").replace(/\|(?=\d{10,}$)(?!.*\|)/, "cKBk")), U.set("unique_aff_sub5", i.UrlRebuilder.removeSpecialCharacteres(R)), U.set("tid", 1e15 * Math.random() + "-utmify"), U.set("extclid", 1e15 * Math.random() + "-utmify")) : a.isEverflow ? (U.set("sub1", i.UrlRebuilder.removeSpecialCharacteres(y)), U.set("sub2", i.UrlRebuilder.removeSpecialCharacteres(I)), U.set("sub3", i.UrlRebuilder.removeSpecialCharacteres(w)), U.set("sub4", i.UrlRebuilder.removeSpecialCharacteres(null !== (o = null === (l = null == b ? void 0 : b.split(c.CLICK_ID_SEPARATOR)) || void 0 === l ? void 0 : l[0]) && void 0 !== o ? o : "")), U.set("sub5", i.UrlRebuilder.removeSpecialCharacteres(R))) : a.preventSubIds || (U.set("subid", i.UrlRebuilder.removeSpecialCharacteres(y)), U.set("subid3", i.UrlRebuilder.removeSpecialCharacteres(I)), U.set("subid4", i.UrlRebuilder.removeSpecialCharacteres(null !== (u = null === (s = null == b ? void 0 : b.split(c.CLICK_ID_SEPARATOR)) || void 0 === s ? void 0 : s[0]) && void 0 !== u ? u : "")), U.set("subid5", i.UrlRebuilder.removeSpecialCharacteres(w)));
                const K = f("src");
                null != K && "" !== K && U.set("src", K);
                const M = [y, w, I, 3 === (null !== (v = null === (d = null == b ? void 0 : b.split(c.CLICK_ID_SEPARATOR)) || void 0 === d ? void 0 : d.length) && void 0 !== v ? v : 0) ? b.split(c.CLICK_ID_SEPARATOR)[0] : b, R],
                    N = M.every((e => "" === e)),
                    W = f("xcod"),
                    H = f("sck");
                if (a.preventXcodSck) W && U.set("xcod", W), H && U.set("sck", H);
                else {
                    const e = _(M, c.UTM_AD_OBJECT_TYPE_SEPARATOR_HOTMART),
                        t = function(e, t, r) {
                            if (e.length <= 255) return e;
                            const n = 4 * r.length,
                                l = Math.floor((255 - n - 12 - 80 - 29) / 5);

                            function i(e, t, r) {
                                function n(e) {
                                    return e.substring(0, l) + "..."
                                }
                                if (!t) return n(e);
                                const i = null != r ? r : "|",
                                    a = e.split(i),
                                    o = a.length > 1 ? a[a.length - 1] : "";
                                return `${n(1===a.length?a[0]:a.slice(0,-1).join(i))}${i}${o}`
                            }
                            const [a, o, s, u, c] = e.split(r);
                            return _([i(a, !0, "jLj"), i(o, !0), i(s, !0), i(u, !0), i(c, !1)], r)
                        }(N ? "" !== W ? W : K : e, 0, c.UTM_AD_OBJECT_TYPE_SEPARATOR_HOTMART);
                    U.set("xcod", t), U.set("sck", t)
                }
                const F = p.get("fbclid");
                null != F && "" !== F && (U.set("fbclid", F), a.preventClickIdsFallback || (b = (null == b ? void 0 : b.includes(c.CLICK_ID_SEPARATOR)) ? b : [b, F, ""].join(c.CLICK_ID_SEPARATOR), U.set("utm_content", b))), null != P && "" !== P && (U.set("gclid", P), a.preventClickIdsFallback || (b = (null == b ? void 0 : b.includes(c.CLICK_ID_SEPARATOR)) ? b : [b, P, ""].join(c.CLICK_ID_SEPARATOR), U.set("utm_content", b))), null != C && "" !== C && U.set("gbraid", C), null != E && "" !== E && U.set("wbraid", E), null != O && "" !== O && (U.set("ttclid", O), a.preventClickIdsFallback || (b = (null == b ? void 0 : b.includes(c.CLICK_ID_SEPARATOR)) ? b : [b, O, ""].join(c.CLICK_ID_SEPARATOR), U.set("utm_content", b))), null != T && "" !== T && (U.set("tbclid", T), a.preventClickIdsFallback || (b = (null == b ? void 0 : b.includes(c.CLICK_ID_SEPARATOR)) ? b : [b, T, ""].join(c.CLICK_ID_SEPARATOR), U.set("utm_content", b)));
                const B = f("utm_id");
                return B && U.set("utm_id", B), (() => {
                    const e = e => null == e || "" === e,
                        t = f("utm_source"),
                        r = f("utm_medium"),
                        n = f("utm_campaign"),
                        l = f("utm_content"),
                        i = f("utm_term"),
                        a = f("gclid"),
                        o = f("gbraid"),
                        s = f("wbraid"),
                        u = f("click_id"),
                        c = f("ttclid"),
                        d = f("tbclid"),
                        m = f("CampaignID"),
                        v = f("xcod"),
                        p = f("src"),
                        _ = U.get("fbclid");
                    return e(t) && e(r) && e(n) && e(l) && e(i) && e(v) && e(p) && e(_) && e(a) && e(o) && e(s) && e(u) && e(c) && e(d) && e(m)
                })() && U.set("utm_source", "organic"), window.utmParams = U, U
            }
            static simplifyParametersIfNecessary(e, t) {
                if (!Object.values(o).some((t => e.includes(t)))) return t;
                const r = new URLSearchParams;
                return t.forEach(((e, t) => {
                    u.includes(t) && r.append(t, e)
                })), r
            }
            static addStripeClientReferenceIdIfNeeded(e) {
                if (!a.isStripe) return e;
                try {
                    const t = new URL(e, window.location.href);
                    if (t.searchParams.get("client_reference_id")) return e;
                    const r = c.getUtmParameters(),
                        n = e => {
                            if (!e) return "";
                            const t = e.split("::")[0];
                            return (t.includes("|") ? t.substring(t.lastIndexOf("|") + 1) : t).replace(/[^A-Za-z0-9_-]/g, "")
                        },
                        l = [n(r.get("utm_source")), n(r.get("utm_medium")), n(r.get("utm_campaign")), n(r.get("utm_content")), n(r.get("utm_term"))];
                    if (l.every((e => !e))) return e;
                    const i = l.join("__").slice(0, 200);
                    return t.searchParams.set("client_reference_id", i), t.toString()
                } catch (t) {
                    return e
                }
            }
        }
        c.UTM_AD_OBJECT_TYPE_SEPARATOR_HOTMART = "hQwK21wXxR", c.LEAD_ID_SEPARATOR = "jLj", c.GOOGLE_KEYWORD_SEPARATOR = "::", c.CLICK_ID_SEPARATOR = "::", window.paramsList = ["utm_source", "utm_campaign", "utm_medium", "utm_content", "utm_term", "xcod", "src"], window.itemExpInDays = 7;
        const d = ["utm_source", "utm_campaign", "utm_medium", "utm_content", "xcod", "sck"];

        function m(e) {
            return `${e}_exp`
        }

        function v() {
            function e(e) {
                document.querySelectorAll("a").forEach((t => {
                    var r, n;
                    if (!(t.href.startsWith("mailto:") || t.href.startsWith("tel:") || t.href.includes("#") || (null === (r = null == a ? void 0 : a.ignoreClasses) || void 0 === r ? void 0 : r.some((e => t.classList.contains(e)))))) {
                        if (l = t.href, ["wa.me/", "api.whatsapp.com/send", "whatsapp:", "link.dispara.ai/", "random.lailla.io/"].some((e => l.includes(e)))) {
                            const e = c.getUtmParameters(),
                                r = i.UrlRebuilder.getAdId(e),
                                l = null !== (n = c.getLeadIdFromSearchParams(e)) && void 0 !== n ? n : c.getLeadIdFromStorage(),
                                a = i.UrlRebuilder.getTrackingSource(e);
                            return t.href = i.UrlRebuilder.randomizePhoneNumberIfNecessary(t.href), void(t.href = i.UrlRebuilder.insertAdIdInWppUrl(t.href, null != r ? r : "", l, a))
                        }
                        var l;
                        if (e && d.every((e => t.href.includes(e)))) return;
                        t.href = c.addUtmParametersToUrl(t.href), t.href = c.addStripeClientReferenceIdIfNeeded(t.href), a.replaceLinks && function(e, t) {
                            var r, n;
                            if ("true" === e.getAttribute("data-replaced-element")) return;
                            if (t && !(null === (r = e[t.property]) || void 0 === r ? void 0 : r.includes(t.value))) return;
                            const l = document.createElement(e.tagName);
                            for (const t of e.attributes) l.setAttribute(t.name, t.value);
                            l.setAttribute("data-replaced-element", "true"), l.innerHTML = e.innerHTML, null === (n = e.parentNode) || void 0 === n || n.replaceChild(l, e)
                        }(t, {
                            property: "href",
                            value: a.replaceLinks
                        })
                    }
                }))
            }

            function t() {
                const e = document.querySelector("vturb-smartplayer");
                if (!e) return;
                const t = c.getUtmParameters(),
                    r = () => {
                        e.injectUrlUpdater(((e, r) => {
                            const n = new URL(e, window.location.href);
                            for (const [e, r] of t.entries()) e && "subid2" !== e && r && n.searchParams.set(e, r);
                            return n.toString()
                        }))
                    };
                e.removeEventListener("player:ready", r), e.addEventListener("player:ready", r)
            }

            function r(e) {
                document.querySelectorAll("form").forEach((t => {
                    var r;
                    e && d.every((e => t.action.includes(e))) || (null === (r = null == a ? void 0 : a.ignoreClasses) || void 0 === r ? void 0 : r.some((e => t.classList.contains(e)))) || (t.action = c.addUtmParametersToUrl(t.action), t.action = c.addStripeClientReferenceIdIfNeeded(t.action), c.getUtmParameters().forEach(((e, r) => {
                        const n = (l = r, t.querySelector(`input[name="${l}"]`));
                        var l;
                        if (n) return void n.setAttribute("value", e);
                        const i = ((e, t) => {
                            const r = document.createElement("input");
                            return r.type = "hidden", r.name = e, r.value = t, r
                        })(r, e);
                        t.appendChild(i)
                    })))
                }))
            }! function() {
                const e = new URLSearchParams(window.location.search);
                window.paramsList.forEach((t => {
                    const r = e.get(t);
                    r && ((e, t) => {
                        localStorage.setItem(e, t);
                        const r = new Date((new Date).getTime() + 24 * window.itemExpInDays * 60 * 60 * 1e3);
                        localStorage.setItem(m(e), r.toISOString())
                    })(t, r)
                }))
            }();
            const n = function() {
                var e, t, r, n, l, i, o, s, u, c, d, m, v, p, f, _, g, S, h, R, A, b;
                const {
                    fixShopifyTheme: I
                } = a, w = null !== (t = null === (e = null === window || void 0 === window ? void 0 : window.BOOMR) || void 0 === e ? void 0 : e.themeName) && void 0 !== t ? t : null === (n = null === (r = null === window || void 0 === window ? void 0 : window.Shopify) || void 0 === r ? void 0 : r.theme) || void 0 === n ? void 0 : n.schema_name, y = null !== (l = null == w ? void 0 : w.includes("Dropmeta")) && void 0 !== l && l, P = null !== (i = null == w ? void 0 : w.includes("Warehouse")) && void 0 !== i && i, C = null !== (o = null == w ? void 0 : w.includes("Classic®")) && void 0 !== o && o, E = null !== (s = null == w ? void 0 : w.includes("Tema Vision")) && void 0 !== s && s, O = null !== (u = null == w ? void 0 : w.includes("Waresabino")) && void 0 !== u && u, T = null !== (c = null == w ? void 0 : w.includes("Dawn")) && void 0 !== c && c, U = null !== (d = null == w ? void 0 : w.includes("Vortex")) && void 0 !== d && d, L = null !== (m = null == w ? void 0 : w.includes("Warepro")) && void 0 !== m && m, k = null !== (v = null == w ? void 0 : w.includes("Wareimadigital")) && void 0 !== v && v, D = null !== (p = null == w ? void 0 : w.includes("Mercado Livre")) && void 0 !== p && p, $ = null !== (f = null == w ? void 0 : w.includes("Tema Evolution®")) && void 0 !== f && f, j = null !== (_ = null == w ? void 0 : w.includes("Evolution Enterprise")) && void 0 !== _ && _, x = null !== (g = null == w ? void 0 : w.includes("Tema Sabino Vision")) && void 0 !== g && g, q = null !== (S = null == w ? void 0 : w.includes("Split")) && void 0 !== S && S, K = null !== (h = null == w ? void 0 : w.includes("WART")) && void 0 !== h && h, M = null !== (R = null == w ? void 0 : w.includes("Vogal")) && void 0 !== R && R, N = null !== (A = null == w ? void 0 : w.includes("Aurohra 2.0")) && void 0 !== A && A, W = null !== (b = null == w ? void 0 : w.includes("RAWART")) && void 0 !== b && b;
                return I || y || P || C || E || O || T || U || L || k || D || $ || W || j || x || q || K || M || N
            }();
            e(), t(),
                function() {
                    const e = window.open;
                    window.open = function(t, r, n) {
                        var l;
                        let i = c.addUtmParametersToUrl(null !== (l = null == t ? void 0 : t.toString()) && void 0 !== l ? l : "");
                        return i = c.addStripeClientReferenceIdIfNeeded(i), e(i, r || "", n || "")
                    }
                }(), n || (r(), function() {
                    const {
                        body: n
                    } = document;
                    new MutationObserver(((n, l) => {
                        const i = e => {
                            if (e.nodeType !== Node.ELEMENT_NODE) return !1;
                            const t = e;
                            return "INPUT" === t.tagName && "hidden" === (null == t ? void 0 : t.type)
                        };
                        n.some((e => Array.from(e.addedNodes).some(i))) || (e(!0), t(), r(!0))
                    })).observe(n, {
                        subtree: !0,
                        childList: !0
                    })
                }(), a.ignoreAllIframes || document.querySelector('link[href="https://api.vturb.com.br"]') || document.querySelectorAll("iframe").forEach((e => {
                    var t;
                    Object.values(s).some((t => e.src.includes(t))) || (null === (t = null == a ? void 0 : a.ignoreClasses) || void 0 === t ? void 0 : t.some((t => e.classList.contains(t)))) || (e.src = c.addUtmParametersToUrl(e.src))
                })))
        }
        const p = () => {
            v(), a.ignoreScriptRetry || (setTimeout(v, 2e3), setTimeout(v, 3e3), setTimeout(v, 5e3), setTimeout(v, 9e3))
        };
        a.fastStart || "complete" === document.readyState ? p() : window.addEventListener("load", p)
    })()
})();