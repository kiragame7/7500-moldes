import { createFileRoute } from "@tanstack/react-router";
import { handleHotmartWebhookRequest } from "@/lib/hotmart-webhook.server";

/**
 * Backwards-compatible alias for the old public URL.
 * It intentionally uses the same Hotmart authentication and processing path.
 */
export const Route = createFileRoute("/api/public/facebook-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => handleHotmartWebhookRequest(request),
    },
  },
});
